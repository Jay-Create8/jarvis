@echo off
chcp 65001 >nul
title JARVIS - alle Superkraefte auf einmal
echo.
echo  ==============================================
echo     JARVIS: Alle Superkraefte mit einem Klick
echo  ==============================================
echo.
echo  Vorher: Handy per USB anschliessen, USB-Debugging an,
echo  JARVIS installiert, auf dem Handy "Debugging erlauben" bestaetigen.
echo.
pause

set P=ch.jarvis.app
where adb >nul 2>nul
if errorlevel 1 (
  echo  FEHLER: adb nicht gefunden. Lade die "SDK Platform-Tools" von Google herunter,
  echo  entpacke sie und lege diese Datei in denselben Ordner wie adb.exe.
  pause
  exit /b
)

adb devices
echo  [1/6] Eingeschraenkte Einstellungen freigeben ...
adb shell appops set %P% ACCESS_RESTRICTED_SETTINGS allow 2>nul

echo  [2/6] Berechtigungen ...
for %%X in (RECORD_AUDIO CAMERA READ_CALENDAR READ_CONTACTS POST_NOTIFICATIONS ACCESS_FINE_LOCATION ACCESS_COARSE_LOCATION ACCESS_BACKGROUND_LOCATION) do (
  adb shell pm grant %P% android.permission.%%X 2>nul
)

echo  [3/6] Blase ueber anderen Apps + puenktliche Erinnerungen ...
adb shell appops set %P% SYSTEM_ALERT_WINDOW allow
adb shell appops set %P% SCHEDULE_EXACT_ALARM allow 2>nul

echo  [4/6] Akku-Optimierung aus ...
adb shell dumpsys deviceidle whitelist +%P%

echo  [5/6] Nachrichten lesen ...
adb shell cmd notification allow_listener %P%/%P%.NotificationWatcher

echo  [6/6] Apps bedienen + Bildschirm sehen ...
echo  (Achtung: ersetzt andere aktive Bedienungshilfen - die kannst du danach wieder einschalten)
adb shell settings put secure enabled_accessibility_services %P%/%P%.ScreenAgent
adb shell settings put secure accessibility_enabled 1

echo.
echo  FERTIG! Oeffne JARVIS und tippe auf "Hey Jarvis" an.
echo.
pause
