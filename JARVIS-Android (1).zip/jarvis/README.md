# 🤖 J.A.R.V.I.S. für Android

Dein eigener KI-Assistent: hört zu, redet zurück, plant mit, merkt sich Dinge und steuert dein Handy.
Das Gehirn ist **Google Gemini (Gratis-Stufe)**.

## Was er kann

| Bereich | Beispiele |
|---|---|
| 🎙️ Sprache | Tipp auf den Reaktor und sprich. Er antwortet mit Stimme. **Gesprächsmodus** = er hört nach jeder Antwort automatisch wieder zu |
| 📋 Planung | "Plane meinen Tag", "Ich muss bis Freitag Mathe lernen", "Was steht heute an?" |
| ⏰ Erinnerungen | "Erinnere mich in 20 Minuten an die Pizza", "Stell einen Wecker auf 6:45" |
| 📱 Handy | Apps öffnen, Taschenlampe, Lautstärke, Timer, Navigation, Musik, Einstellungen, Akku |
| 💬 Kontakte | "Schreib Mama dass ich später komme" (SMS wird nur vorbereitet, **du** tippst Senden) |
| 🧠 Gedächtnis | Er merkt sich Dinge über dich (Einstellungen ⚙️ zeigt alles und lässt dich löschen) |
| 🌅 Briefing | Beim ersten Öffnen am Tag: kurze Begrüssung + Termine + ein Vorschlag |
| 👂 **"Hey Jarvis"** | Wake-Word, auch bei ausgeschaltetem Bildschirm. Läuft **offline & gratis** direkt auf dem Handy |
| 💭 Blase | Ruft du ihn aus einer anderen App, erscheint oben eine kleine JARVIS-Blase mit Status und Antwort |
| 🔁 Neustart-fest | Erinnerungen überleben einen Handy-Neustart |
| ☀️ **Auto-Briefing** | Jeden Morgen zur Wunschzeit: Wetter, Termine, Aufgaben, ein Tipp – als Benachrichtigung oder laut |
| 🌍 **Internetwissen** | "Wer hat gestern gewonnen?", "Hat die Migros noch offen?" – echte Google-Recherche |
| 🌦️ **Wetter** | "Brauch ich heute einen Schirm?" – Standort-Wetter, Stunden & 3 Tage |
| 📬 **Nachrichten** | "Was gibt's Neues?" liest WhatsApp & Co. vor, "Antworte Lea: bin gleich da" schickt direkt |
| 📢 **Ansagen** | Neue Chat-Nachrichten werden auf Wunsch laut angesagt |
| 🦾 **Apps bedienen** | "Öffne YouTube und such nach Lofi" – JARVIS liest den Bildschirm, tippt, schreibt, scrollt |
| 📷 **Sehen** | Foto machen → "Was ist das?", "Hilf mir bei dieser Aufgabe" |
| 👁️ **Bildschirm sehen** | "Hey Jarvis, was ist das?" – er schaut selbst auf deinen Bildschirm (auch Kamera-Sucher, Insta, Spiele). Kein Screenshot in der Galerie |
| 🎯 **Markieren** | "Wo ist der Senden-Knopf?", "Markiere die Fehler" – leuchtender Rahmen direkt auf deinem Bildschirm, über jeder App |
| 📸 **Unsichtbare Kamera** | Du bist im Chat und fragst "Was sieht die Kamera?" – er fotografiert im Hintergrund und antwortet |
| 📍 **Orts-Erinnerungen** | "Erinnere mich an Milch, wenn ich beim Coop bin" |

## 1. Gratis-API-Key holen 🔑
1. Geh auf **aistudio.google.com** und melde dich mit einem Google-Konto an
2. Klick auf **"Get API key" → "Create API key"**
3. Key kopieren – den trägst du später in der App unter ⚙️ ein

> Hinweis: In der Gratis-Stufe darf Google deine Anfragen zur Verbesserung nutzen. Erzähl JARVIS also nichts super Geheimes. 😉

## 2. APK bauen – Weg A: GitHub (ohne PC-Programme) ☁️
1. Gratis-Konto auf **github.com** machen
2. Neues Repository erstellen → "uploading an existing file" → **alle Dateien aus diesem Ordner** hochladen (inkl. `.github`-Ordner!)
3. Tab **Actions** öffnen → der Build läuft automatisch (ca. 5 Min)
4. Fertigen Lauf anklicken → unten bei **Artifacts** `JARVIS-apk` runterladen → entpacken → `app-debug.apk` aufs Handy
5. Auf dem Handy öffnen → "Installation aus unbekannten Quellen" erlauben → installieren

Tipp: Der `.github`-Ordner ist versteckt. Am einfachsten: GitHub Desktop oder im Browser "Add file → Create new file" mit dem Namen `.github/workflows/build.yml` und den Inhalt reinkopieren.

## 2. APK bauen – Weg B: Android Studio 💻
1. **Android Studio** installieren (developer.android.com/studio)
2. "Open" → diesen Ordner wählen → warten, bis Gradle fertig ist
3. Handy per USB verbinden (Entwickleroptionen + USB-Debugging an) → grüner ▶️-Knopf

## 3. Einrichten
1. App öffnen → Berechtigungen erlauben (Mikrofon, Kalender, Kontakte, Benachrichtigungen)
2. ⚙️ → API-Key einfügen, Namen eintragen → Speichern
3. Los geht's! 🚀

## 4. "Hey Jarvis" einschalten 👂
1. Unten in der App auf **👂 "Jarvis" aus** tippen → wird zu **an**. Oben in der Leiste steht jetzt "JARVIS hört zu".
2. Sag deutlich **"Hey Jarvis"** (englisch ausgesprochen, "Hey Dschar-wis") → kurzer Piep + Vibration → jetzt deinen Befehl sagen.
3. In ⚙️ unbedingt die zwei Sachen erlauben, damit er alles kann:
   - **Blase über anderen Apps** → er kann auch im Hintergrund Apps öffnen, Wecker stellen usw.
   - **Akku-Optimierung aus** → Android killt ihn sonst nach einer Weile
4. Reagiert er zu selten → Empfindlichkeit hoch. Reagiert er aus Versehen → runter.

Gut zu wissen:
- Das Wort "Jarvis" allein reicht meist nicht, das Modell ist auf **"Hey Jarvis"** trainiert.
- Nach einem Handy-Neustart erlaubt Android kein Mikrofon im Hintergrund – es kommt eine Benachrichtigung, einmal antippen genügt.
- Bei manchen Herstellern (Xiaomi, Huawei, Oppo …) zusätzlich in den App-Einstellungen "Autostart" erlauben.
- Startet die Offline-Erkennung auf einem Handy nicht, schaltet JARVIS automatisch auf eine Notlösung über Google um (braucht mehr Akku).

## 5. Superkräfte freischalten 🦾

### 🚀 Weg 1: Ein Knopf in der App (empfohlen)
Beim ersten Start (oder oben auf **🦾**) erscheint **"Alles einrichten"**. Ein Tipp auf **🚀 Alles einrichten** –
JARVIS springt automatisch zu jeder Freigabe, du tippst nur "Erlauben" und gehst zurück, er macht selbst weiter.
Am Ende siehst du eine Checkliste ✅. Fehlt noch was: einfach den Punkt antippen.

> Android erlaubt keiner App, sich diese Rechte selbst zu geben (Schutz vor Spionage-Apps).
> Darum braucht jede einen Tipp von dir – aber du musst nichts mehr suchen.

### 💻 Weg 2: Wirklich ALLES auf einmal (mit PC)
1. "SDK Platform-Tools" von Google herunterladen und entpacken
2. Handy per USB anschliessen, Entwickleroptionen → **USB-Debugging** an
3. Im Ordner `einrichten/` doppelklicken:
   - Windows: `einrichten-windows.bat` (in den Platform-Tools-Ordner legen)
   - Mac/Linux: `./einrichten-mac-linux.sh`
4. Fertig – alle Superkräfte sind an, ohne eine einzige Einstellung am Handy. 🎉

### Weg 3: Einzeln von Hand

In ⚙️ → **Superkräfte** jede einzeln antippen und erlauben:
- **Nachrichten lesen & beantworten** → in der Liste "JARVIS" einschalten
- **Apps bedienen** → Bedienungshilfen → Installierte Apps → "JARVIS" → an
- **Kamera** → erlauben. Für die unsichtbare Kamera im Hintergrund muss **"Hey Jarvis" an** sein (Android erlaubt Kamera im Hintergrund nur über diesen Dienst). Beim Fotografieren leuchtet oben der grüne Kamera-Punkt – das ist Android-Pflicht.
- **Bildschirm sehen** → kommt automatisch mit "Apps bedienen" (ab Android 11). Geschützte Apps (Banking, Netflix …) bleiben schwarz.
- **Standort** → zuerst "Bei Nutzung", dann nochmal tippen → "Immer erlauben" (nur für Orts-Erinnerungen nötig)
- **Morgen-Briefing** → Schalter an, Uhrzeit wählen, Speichern

⚠️ **Ist ein Schalter ausgegraut** ("Eingeschränkte Einstellung")? Das macht Android 13+ bei Apps, die nicht aus dem Play Store kommen:
"ℹ️ App-Info öffnen" → oben rechts **⋮** → **"Eingeschränkte Einstellungen zulassen"** → danach nochmal versuchen.

**Sicherheit 🔒** JARVIS bedient keine Bank-, Bezahl- oder Passwort-Apps, macht keine Käufe/Zahlungen,
gibt keine Passwörter ein und fragt nach, bevor er eine Nachricht abschickt, die du nicht selbst diktiert hast.
Trotzdem: Die "Apps bedienen"-Superkraft ist mächtig – schalte sie aus, wenn du sie nicht brauchst.

**Als Assistent per Tastendruck:** Einstellungen → Apps → Standard-Apps → Digitaler Assistent → JARVIS
(klappt nicht auf jedem Handy, dann einfach das App-Icon nutzen).

## Wenn was nicht geht 🔧
- **"API-Problem, stimmt das Modell?"** → in ⚙️ ein anderes Modell eintragen, z.B. `gemini-flash-lite-latest` oder den Namen, den AI Studio aktuell als kostenlos anzeigt
- **"Gratis-Limit erreicht"** → kurz warten, die Gratis-Stufe hat Anfragen pro Minute/Tag
- **Spracherkennung geht nicht** → Google-App installieren/aktualisieren
- **Erinnerungen kommen spät** → Einstellungen → Apps → JARVIS → "Wecker & Erinnerungen" erlauben, Akku-Optimierung ausschalten
- **"Hey Jarvis" geht nicht** → Mikrofon-Berechtigung prüfen, Akku-Optimierung aus, Empfindlichkeit hoch
- **Internetsuche meldet Fehler** → das gewählte Gemini-Modell unterstützt evtl. keine Google-Suche, anderes Flash-Modell eintragen
- **Briefing kommt nicht** → Akku-Optimierung aus, "Wecker & Erinnerungen" erlauben
- **Antworten auf Nachrichten klappt nicht** → nicht jede App bietet "Antworten" in der Benachrichtigung; dann macht JARVIS es über "Apps bedienen"

## Aufbau
- `JarvisBrain.kt` – redet mit Gemini, führt Werkzeug-Aufrufe in einer Schleife aus
- `Tools.kt` – alle Handy-Fähigkeiten (hier neue hinzufügen!)
- `Jarvis.kt` – das zentrale "Bewusstsein", läuft auch ohne geöffnete App
- `WakeService.kt` – Hintergrund-Dienst, der auf "Hey Jarvis" hört
- `WakeWordDetector.kt` – Offline-Erkennung (openWakeWord-Modelle in `app/src/main/assets`)
- `Overlay.kt` – die schwebende JARVIS-Blase
- `Briefing.kt` – automatisches Morgen-Briefing
- `Web.kt` – Internet-Recherche & Wetter
- `NotificationWatcher.kt` – Nachrichten lesen, beantworten, ansagen
- `ScreenAgent.kt` – andere Apps bedienen (Bedienungshilfe)
- `PlaceReminders.kt` – Orts-Erinnerungen
- `CameraEye.kt` – unsichtbare Kamera im Hintergrund
- `Highlighter.kt` – leuchtende Markierungen auf dem Bildschirm
- `Voice.kt` – Spracherkennung + Sprachausgabe
- `Store.kt` – Gedächtnis, Aufgaben, Einstellungen (lokal auf dem Handy)
- `Ui.kt` / `MainActivity.kt` – Oberfläche mit Arc-Reactor

## Lizenzen
- Wetterdaten: [Open-Meteo](https://open-meteo.com) (gratis, ohne Key)
- Wake-Word-Modelle von [openWakeWord](https://github.com/dscripka/openWakeWord): Code Apache 2.0,
  vortrainierte Modelle **CC BY-NC-SA 4.0** (nur nicht-kommerziell – für dein eigenes Handy also perfekt,
  aber nicht in einer App verkaufen).
