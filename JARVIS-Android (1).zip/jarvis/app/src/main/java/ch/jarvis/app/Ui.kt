package ch.jarvis.app

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Cyan = Color(0xFF29E6FF)
private val Bg = Color(0xFF02060D)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JarvisScreen(a: MainActivity) {
    var showSettings by remember { mutableStateOf(false) }
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(Jarvis.messages.size) {
        if (Jarvis.messages.isNotEmpty()) listState.animateScrollToItem(Jarvis.messages.size - 1)
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Bg, surface = Color(0xFF0B1A28))) {
        Column(
            Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(Bg, Color(0xFF071A2B))))
                .safeDrawingPadding()
                .padding(horizontal = 12.dp)
        ) {
            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("J.A.R.V.I.S.", color = Cyan, fontSize = 22.sp, fontWeight = FontWeight.Bold,
                    letterSpacing = 4.sp, modifier = Modifier.weight(1f))
                TextButton(onClick = { Jarvis.toggleMute() }) { Text(if (Jarvis.muted) "🔇" else "🔊", fontSize = 20.sp) }
                TextButton(onClick = { a.showSetup = true }) { Text("🦾", fontSize = 20.sp) }
                TextButton(onClick = { showSettings = true }) { Text("⚙️", fontSize = 20.sp) }
            }

            LazyColumn(
                state = listState,
                modifier = Modifier.weight(1f).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(Jarvis.messages) { m -> Bubble(m) }
            }

            Reactor(Jarvis.phase, Jarvis.level) { Jarvis.toggleListening() }
            Text(Jarvis.status, color = Cyan.copy(alpha = 0.85f), fontSize = 13.sp,
                modifier = Modifier.align(Alignment.CenterHorizontally))

            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically) {
                FilterChip(selected = Jarvis.convoMode, onClick = { Jarvis.setConvo(!Jarvis.convoMode) },
                    label = { Text("🔁 Gesprächsmodus") })
                FilterChip(selected = false, onClick = { Jarvis.handleInput(DAYPLAN_PROMPT) },
                    label = { Text("📋 Tag planen") })
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = Jarvis.wakeActive, onClick = { a.setWake(!Jarvis.wakeActive) },
                    label = { Text(if (Jarvis.wakeActive) "👂 \"Jarvis\" an" else "👂 \"Jarvis\" aus") })
                if (Jarvis.wakeInfo.isNotBlank()) {
                    Text(Jarvis.wakeInfo, color = Color.White.copy(alpha = 0.6f), fontSize = 11.sp, maxLines = 2)
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 6.dp)) {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Schreib JARVIS …") },
                    maxLines = 4,
                )
                TextButton(onClick = { a.takePhoto(input); input = "" }) {
                    Text("📷", fontSize = 20.sp)
                }
                TextButton(onClick = { Jarvis.handleInput(input); input = "" }) {
                    Text("➤", fontSize = 24.sp, color = Cyan)
                }
            }
        }

        if (showSettings) SettingsDialog(a) { showSettings = false }
        if (a.showSetup) SetupDialog(a)
    }
}

@Composable
private fun Bubble(m: ChatMsg) {
    val shape = RoundedCornerShape(14.dp)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.user) Arrangement.End else Arrangement.Start) {
        Text(
            m.text, color = Color.White, fontSize = 15.sp,
            modifier = Modifier
                .widthIn(max = 300.dp)
                .background(if (m.user) Color(0xFF1B3A57) else Color(0xFF0E2233), shape)
                .border(1.dp, Cyan.copy(alpha = if (m.user) 0.2f else 0.5f), shape)
                .padding(10.dp)
        )
    }
}

@Composable
private fun Reactor(phase: Phase, level: Float, onClick: () -> Unit) {
    val inf = rememberInfiniteTransition(label = "reactor")
    val thinking = phase == Phase.THINKING
    val pulse by inf.animateFloat(0.92f, 1.08f,
        infiniteRepeatable(tween(if (thinking) 400 else 1600), RepeatMode.Reverse), label = "pulse")
    val rot by inf.animateFloat(0f, 360f,
        infiniteRepeatable(tween(if (thinking) 1200 else 7000, easing = LinearEasing)), label = "rot")
    val lvl by animateFloatAsState(level, label = "lvl")
    val color = when (phase) {
        Phase.LISTENING -> Color(0xFFFF4D6D)
        Phase.SPEAKING -> Color(0xFF7CFFB2)
        else -> Cyan
    }

    Box(Modifier.fillMaxWidth().height(150.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(132.dp).clip(CircleShape).clickable(onClick = onClick)) {
            val r = size.minDimension / 2
            val s = pulse + lvl * 0.3f
            drawCircle(Brush.radialGradient(listOf(color.copy(alpha = 0.5f), Color.Transparent), radius = r), radius = r)
            drawCircle(color.copy(alpha = 0.6f), radius = r * 0.95f, style = Stroke(2f))
            rotate(rot) {
                for (i in 0 until 8) {
                    drawArc(color, startAngle = i * 45f, sweepAngle = 28f, useCenter = false,
                        topLeft = Offset(size.width * 0.14f, size.height * 0.14f),
                        size = Size(size.width * 0.72f, size.height * 0.72f),
                        style = Stroke(width = 7f, cap = StrokeCap.Round))
                }
            }
            drawCircle(color, radius = r * 0.32f * s)
            drawCircle(Color.White.copy(alpha = 0.85f), radius = r * 0.15f * s)
        }
    }
}

@Composable
private fun SettingsDialog(a: MainActivity, onClose: () -> Unit) {
    val store = Jarvis.store
    var key by remember { mutableStateOf(store.apiKey) }
    var model by remember { mutableStateOf(store.model) }
    var name by remember { mutableStateOf(store.userName) }
    var sens by remember { mutableFloatStateOf(store.wakeSensitivity) }
    val facts = remember { store.facts() }
    val overlayOk = remember { a.hasOverlay() }
    val notifOk = remember { a.hasNotificationAccess() }
    val screenOk = remember { a.hasScreenControl() }
    val camOk = remember { a.hasCamera() }
    val locState = remember { a.locationState() }
    var briefOn by remember { mutableStateOf(store.briefingEnabled) }
    var briefHour by remember { mutableIntStateOf(store.briefingHour) }
    var briefMin by remember { mutableIntStateOf(store.briefingMinute) }
    var briefSpeak by remember { mutableStateOf(store.briefingSpeak) }
    var announce by remember { mutableStateOf(store.announceMessages) }
    val batteryOk = remember { a.ignoresBatteryOptimizations() }

    AlertDialog(
        onDismissRequest = onClose,
        confirmButton = { TextButton(onClick = {
            a.saveSettings(key, model, name, sens)
            a.setBriefing(briefOn, briefHour, briefMin, briefSpeak)
            store.announceMessages = announce
            onClose()
        }) { Text("Speichern") } },
        dismissButton = { TextButton(onClick = onClose) { Text("Abbrechen") } },
        title = { Text("⚙️ Einstellungen") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text("🧠 Gehirn", fontWeight = FontWeight.Bold)
                OutlinedTextField(key, { key = it }, label = { Text("Gemini API-Key") }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation())
                Text("Gratis holen: aistudio.google.com → \"Get API key\"", fontSize = 12.sp)
                Spacer(Modifier.height(6.dp))
                OutlinedTextField(model, { model = it }, label = { Text("KI-Modell") }, singleLine = true)
                Spacer(Modifier.height(6.dp))
                OutlinedTextField(name, { name = it }, label = { Text("Wie soll ich dich nennen?") }, singleLine = true)

                Spacer(Modifier.height(14.dp))
                Text("👂 \"Hey JARVIS\"", fontWeight = FontWeight.Bold)
                Text("Läuft komplett offline auf deinem Handy. Sag \"Hey Jarvis\" und warte kurz auf den Piep.",
                    fontSize = 12.sp)
                Text("Empfindlichkeit: ${(sens * 100).toInt()} %", fontSize = 13.sp)
                Slider(value = sens, onValueChange = { sens = it }, valueRange = 0.2f..0.8f)
                Text("Höher = reagiert leichter, aber auch öfter aus Versehen.", fontSize = 12.sp)
                TextButton(onClick = { a.openOverlaySettings() }) {
                    Text(if (overlayOk) "✅ Blase über anderen Apps erlaubt" else "⚠️ Blase über anderen Apps erlauben")
                }
                TextButton(onClick = { a.openBatterySettings() }) {
                    Text(if (batteryOk) "✅ Akku-Optimierung aus" else "⚠️ Akku-Optimierung ausschalten")
                }

                Spacer(Modifier.height(14.dp))
                Text("☀️ Morgen-Briefing", fontWeight = FontWeight.Bold)
                SwitchRow("Jeden Tag automatisch", briefOn) { briefOn = it }
                if (briefOn) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        TextButton(onClick = { briefHour = (briefHour + 23) % 24 }) { Text("−") }
                        Text("%02d:%02d".format(briefHour, briefMin), fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        TextButton(onClick = { briefHour = (briefHour + 1) % 24 }) { Text("+") }
                        TextButton(onClick = { briefMin = (briefMin + 15) % 60 }) { Text("+15 Min") }
                    }
                    SwitchRow("Laut vorlesen", briefSpeak) { briefSpeak = it }
                }

                Spacer(Modifier.height(14.dp))
                Text("🦾 Superkräfte", fontWeight = FontWeight.Bold)
                Button(onClick = { onClose(); a.showSetup = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("🦾 Alles auf einmal einrichten")
                }
                Text("Oder einzeln:", fontSize = 12.sp)
                Text("Jede einzeln erlauben. Ist ein Schalter ausgegraut: zuerst unten \"App-Info\" → ⋮ → " +
                    "\"Eingeschränkte Einstellungen zulassen\".", fontSize = 12.sp)
                TextButton(onClick = { a.openNotificationAccess() }) {
                    Text(if (notifOk) "✅ Nachrichten lesen & beantworten" else "⚠️ Nachrichten lesen & beantworten")
                }
                SwitchRow("📢 Neue Nachrichten laut ansagen", announce) { announce = it }
                TextButton(onClick = { a.openAccessibility() }) {
                    Text(if (screenOk) "✅ Apps bedienen (Bedienungshilfe)" else "⚠️ Apps bedienen → \"JARVIS\" einschalten")
                }
                Text("👁️ \"Was ist das?\" (Bildschirm sehen) nutzt die Bedienungshilfe, Android 11+.", fontSize = 12.sp)
                TextButton(onClick = { a.requestCamera() }) {
                    Text(if (camOk) "✅ Kamera (auch im Hintergrund bei \"Hey Jarvis\" an)" else "⚠️ Kamera erlauben")
                }
                TextButton(onClick = { a.requestLocation() }) {
                    Text(when (locState) {
                        2 -> "✅ Standort (Wetter & Orts-Erinnerungen)"
                        1 -> "⚠️ Standort \"Immer erlauben\" für Orts-Erinnerungen"
                        else -> "⚠️ Standort erlauben"
                    })
                }
                TextButton(onClick = { a.openAppInfo() }) { Text("ℹ️ App-Info öffnen") }

                Spacer(Modifier.height(10.dp))
                Text("🧠 Gedächtnis (${facts.size})", fontWeight = FontWeight.Bold)
                if (facts.isEmpty()) Text("Noch nichts gemerkt.", fontSize = 12.sp)
                facts.forEach { Text("• $it", fontSize = 12.sp) }
                Row {
                    TextButton(onClick = { Jarvis.clearMemory(); onClose() }) { Text("Gedächtnis löschen") }
                    TextButton(onClick = { Jarvis.newChat(); onClose() }) { Text("Neuer Chat") }
                }
            }
        },
    )
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, fontSize = 14.sp, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

/** Ein-Knopf-Einrichtung: Checkliste aller Superkräfte, führt automatisch durch alles. */
@Composable
private fun SetupDialog(a: MainActivity) {
    @Suppress("UNUSED_VARIABLE") val tick = a.setupTick // neu zeichnen, wenn du aus den Einstellungen zurückkommst
    val items = a.setupItems()
    val done = items.count { it.done }
    AlertDialog(
        onDismissRequest = { a.closeSetup() },
        title = { Text("🦾 Alles einrichten") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text(
                    if (done == items.size) "Alles bereit! 🎉" else
                        "Ein Knopf – ich führe dich automatisch durch alles. Du tippst nur jeweils \"Erlauben\" " +
                            "und gehst zurück, den Rest mache ich.",
                    fontSize = 13.sp,
                )
                Spacer(Modifier.height(8.dp))
                Text("$done von ${items.size} erledigt", fontWeight = FontWeight.Bold, color = Cyan)
                Spacer(Modifier.height(4.dp))
                items.forEach { item ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable(enabled = !item.done) { a.runSetupStep(item.id) }
                            .padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(if (item.done) "✅" else "⬜", fontSize = 18.sp)
                        Spacer(Modifier.width(8.dp))
                        Text(item.label, fontSize = 14.sp,
                            color = if (item.done) Color.White.copy(alpha = 0.6f) else Color.White)
                    }
                }
                if (a.setupHint.isNotBlank()) {
                    Spacer(Modifier.height(8.dp))
                    Text(a.setupHint, fontSize = 13.sp, color = Cyan)
                }
                TextButton(onClick = { a.openAppInfo() }) { Text("ℹ️ App-Info (bei ausgegrauten Schaltern)") }
            }
        },
        confirmButton = {
            if (done < items.size) {
                Button(onClick = { a.startSetup() }, enabled = !a.setupRunning) {
                    Text(if (a.setupRunning) "Läuft … ⏳" else "🚀 Alles einrichten")
                }
            }
        },
        dismissButton = { TextButton(onClick = { a.closeSetup() }) { Text(if (done == items.size) "Fertig" else "Später") } },
    )
}
