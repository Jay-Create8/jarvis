package ch.jarvis.app

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import java.util.UUID

/** Ohren (Spracherkennung) und Stimme (Sprachausgabe) von JARVIS. */
class Voice(
    private val act: Context,
    private val onResult: (String) -> Unit,
    private val onLevel: (Float) -> Unit,
    private val onListenEnd: (String?) -> Unit,
) {
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var ttsFailed = false
    private var pending: Pair<String, () -> Unit>? = null
    private val callbacks = HashMap<String, () -> Unit>()
    private val main = Handler(Looper.getMainLooper())

    init {
        tts = TextToSpeech(act) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.GERMAN
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) = finish(utteranceId)
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) = finish(utteranceId)
                })
                ttsReady = true
            } else {
                ttsFailed = true
            }
            main.post { pending?.let { (text, done) -> pending = null; speak(text, done) } }
        }
    }

    private fun finish(id: String?) {
        main.post { callbacks.remove(id)?.invoke() }
    }

    fun speak(text: String, onDone: () -> Unit) {
        if (ttsFailed) { onDone(); return }
        if (!ttsReady) { pending = text to onDone; return }
        val clean = cleanForSpeech(text).take(TextToSpeech.getMaxSpeechInputLength() - 1)
        if (clean.isBlank()) { onDone(); return }
        val id = UUID.randomUUID().toString()
        callbacks[id] = onDone
        tts?.speak(clean, TextToSpeech.QUEUE_FLUSH, null, id)
    }

    fun stopSpeaking() {
        pending = null
        callbacks.clear()
        tts?.stop()
    }

    private fun cleanForSpeech(t: String): String = t
        .replace(Regex("[*#_`>]"), "")
        .replace(Regex("[\\x{1F000}-\\x{1FFFF}\\x{2600}-\\x{27BF}\\x{2B00}-\\x{2BFF}\\x{FE0F}\\x{200D}]"), "")
        .replace(Regex("\\s+"), " ")
        .trim()

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) = onLevel(((rmsdB + 2f) / 12f).coerceIn(0f, 1f))
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() { onLevel(0f) }
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onError(error: Int) {
            onLevel(0f)
            onListenEnd(when (error) {
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Hab nichts verstanden 🤔"
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Mikrofon-Berechtigung fehlt 🎙️"
                SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Kein Internet für die Spracherkennung 📶"
                else -> "Spracherkennung hat gehakt ($error)"
            })
        }

        override fun onResults(results: Bundle?) {
            onLevel(0f)
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (text.isNullOrBlank()) {
                onListenEnd("Hab nichts verstanden 🤔")
            } else {
                onListenEnd(null)
                onResult(text)
            }
        }
    }

    fun listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(act)) {
            onListenEnd("Spracherkennung nicht verfügbar 😕 (Google-App installiert?)")
            return
        }
        stopSpeaking()
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(act).also { it.setRecognitionListener(listener) }
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "de-DE")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        recognizer?.startListening(i)
    }

    fun stopListening() {
        recognizer?.cancel()
        onLevel(0f)
    }

    fun destroy() {
        recognizer?.destroy()
        recognizer = null
        tts?.shutdown()
    }
}
