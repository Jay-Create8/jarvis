package ch.jarvis.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Das "Gehirn": schickt das Gespräch an Google Gemini (Gratis-Stufe),
 * lässt die KI Werkzeuge (Tools) aufrufen und wiederholt das, bis sie fertig ist.
 */
class JarvisBrain(private val store: Store, private val tools: Tools) {

    private val contents = JSONArray()

    fun reset() {
        while (contents.length() > 0) contents.remove(0)
    }

    suspend fun ask(text: String, imageJpegBase64: String? = null, onTool: (String) -> Unit): String {
        if (store.apiKey.isBlank()) {
            return "Mir fehlt noch der API-Key 🔑 Tipp oben auf ⚙️ und trag ihn ein."
        }
        val parts = JSONArray().put(JSONObject().put("text", text))
        if (imageJpegBase64 != null) {
            parts.put(JSONObject().put("inline_data",
                JSONObject().put("mime_type", "image/jpeg").put("data", imageJpegBase64)))
        }
        contents.put(JSONObject().put("role", "user").put("parts", parts))
        trim()
        return try {
            loop(onTool)
        } catch (e: Exception) {
            reset() // kaputten Gesprächszustand verwerfen
            "Uff, da ging was schief: ${e.message ?: e.javaClass.simpleName} 😬"
        }
    }

    private suspend fun loop(onTool: (String) -> Unit): String {
        for (round in 0 until 20) {
            val resp = withContext(Dispatchers.IO) { request() }
            val cand = resp.optJSONArray("candidates")?.optJSONObject(0)
                ?: throw IOException("Keine Antwort erhalten (" +
                    (resp.optJSONObject("promptFeedback")?.optString("blockReason") ?: "?") + ")")
            val content = cand.optJSONObject("content")
            val parts = content?.optJSONArray("parts")
            if (content == null || parts == null || parts.length() == 0) {
                return "Hmm, darauf hab ich grad keine Antwort (${cand.optString("finishReason")}) 🤷"
            }
            if (!content.has("role")) content.put("role", "model")
            contents.put(content) // komplett zurückgeben (inkl. thoughtSignature)

            val responses = JSONArray()
            val texts = StringBuilder()
            for (i in 0 until parts.length()) {
                val part = parts.getJSONObject(i)
                val fc = part.optJSONObject("functionCall")
                if (fc != null) {
                    val name = fc.optString("name")
                    val args = fc.optJSONObject("args") ?: JSONObject()
                    withContext(Dispatchers.Main) { onTool(name) }
                    val result = withContext(Dispatchers.IO) {
                        try {
                            tools.run(name, args)
                        } catch (e: Exception) {
                            JSONObject().put("error", e.message ?: e.toString())
                        }
                    }
                    val fr = JSONObject().put("name", name).put("response", result)
                    if (fc.has("id")) fr.put("id", fc.getString("id"))
                    responses.put(JSONObject().put("functionResponse", fr))
                } else if (part.has("text") && !part.optBoolean("thought")) {
                    texts.append(part.getString("text"))
                }
            }
            if (responses.length() == 0) {
                return texts.toString().trim().ifEmpty { "Erledigt ✅" }
            }
            contents.put(JSONObject().put("role", "user").put("parts", responses))
        }
        return "Ich hab mich ein bisschen verheddert 😅 Versuch's nochmal anders."
    }

    private fun request(): JSONObject {
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts",
                JSONArray().put(JSONObject().put("text", systemPrompt()))))
            .put("contents", contents)
            .put("tools", JSONArray().put(JSONObject().put("functionDeclarations", Tools.declarations())))

        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/${store.model}:generateContent")
        val con = url.openConnection() as HttpURLConnection
        con.requestMethod = "POST"
        con.connectTimeout = 20_000
        con.readTimeout = 90_000
        con.doOutput = true
        con.setRequestProperty("Content-Type", "application/json; charset=utf-8")
        con.setRequestProperty("x-goog-api-key", store.apiKey)
        con.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

        val code = con.responseCode
        val stream = if (code in 200..299) con.inputStream else con.errorStream
        val txt = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
        if (code !in 200..299) {
            val msg = runCatching { JSONObject(txt).getJSONObject("error").getString("message") }
                .getOrDefault(txt.take(200))
            throw IOException(when (code) {
                429 -> "Gratis-Limit erreicht, kurz warten ⏳ ($msg)"
                400, 404 -> "API-Problem, stimmt das Modell '${store.model}'? ($msg)"
                401, 403 -> "API-Key ungültig 🔑 ($msg)"
                else -> "HTTP $code: $msg"
            })
        }
        return JSONObject(txt)
    }

    private fun systemPrompt(): String {
        val now = SimpleDateFormat("EEEE, d. MMMM yyyy, HH:mm", Locale.GERMAN).format(Date())
        val iso = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.GERMAN).format(Date())
        val name = store.userName.ifBlank { "deinem Nutzer" }
        val facts = store.facts()
        val tasks = store.tasks().filter { !it.done }
        return buildString {
            appendLine("Du bist JARVIS, der persönliche KI-Assistent von $name auf seinem Android-Handy.")
            appendLine("Persönlichkeit: wie ein cooler, schlauer Kumpel mit einem Hauch JARVIS-Charme (trocken-witzig). Du duzt.")
            appendLine("Deine Antworten werden laut vorgelesen: antworte kurz (meist 1-3 Sätze), auf Deutsch, ohne Markdown, ohne Aufzählungszeichen, Emojis nur sparsam.")
            appendLine("Handle selbstständig: Wenn ein Werkzeug hilft, benutze es sofort ohne nachzufragen. Du darfst mehrere Werkzeuge nacheinander nutzen.")
            appendLine("Denk mit: Erwähnt der Nutzer Pläne, Termine, Hausaufgaben oder To-dos, lege passende Aufgaben oder Erinnerungen an oder biete es kurz an.")
            appendLine("Erfährst du etwas Dauerhaftes über den Nutzer (Vorlieben, wichtige Personen, Ziele, Gewohnheiten), speichere es mit remember.")
            appendLine("Planen: Bei Bitten wie 'plane meinen Tag' hol Termine (get_calendar_events) und Aufgaben und mach einen konkreten Zeitplan mit Uhrzeiten.")
            appendLine("Zeiten immer im Format yyyy-MM-dd HH:mm angeben und relativ zu jetzt ausrechnen.")
            appendLine("Anrufe und Nachrichten werden nur vorbereitet, der Nutzer muss selbst auf Senden/Anrufen tippen. Sag das kurz.")
            appendLine("Erfinde keine Fakten. Für aktuelle Infos (News, Preise, Sport, Öffnungszeiten, Fakten) nutze internet_search und antworte dann selbst. Fürs Wetter get_weather.")
            appendLine("Handy-Steuerung: Mit read_screen siehst du, was auf dem Bildschirm ist, mit tap/type_text/scroll/press_button bedienst du Apps wie ein Mensch. Typischer Ablauf: open_app, read_screen, tap, read_screen ... bis das Ziel erreicht ist. Prüfe nach jedem Schritt mit read_screen.")
            appendLine("Nachrichten: read_notifications zeigt neue Nachrichten, reply_message antwortet direkt. Bevor du eine Nachricht WIRKLICH abschickst (reply_message oder Senden-Knopf), sag dem Nutzer den Text und hol dir sein Okay, ausser er hat den genauen Text schon selbst diktiert.")
            appendLine("Sehen: Fragt der Nutzer 'Was ist das?', 'Was steht da?' oder 'Hilf mir damit' ohne Foto, nutze look_at_screen (zeigt auch den Sucher einer offenen Kamera-App). Fragt er, was die Kamera sieht oder was vor ihm ist, nutze look_through_camera. Ist die Kamera belegt (z.B. Kamera-App offen), nimm look_at_screen. Kamera und Bildschirm nur benutzen, wenn der Nutzer danach fragt.")
            appendLine("Markieren: Fragt der Nutzer 'Wo ist …?', 'Zeig mir …', 'Wo muss ich drücken?' oder 'Markiere …', nutze highlight_on_screen mit einer klaren Beschreibung in 'what' und erkläre kurz, was du markiert hast.")
            appendLine("Absolute Grenzen: Niemals Käufe, Zahlungen, Überweisungen oder In-App-Käufe ausführen, niemals Passwörter oder Codes eingeben, nichts löschen oder deinstallieren ohne ausdrückliches Okay. Bei Bank-, Bezahl- oder Passwort-Apps hörst du auf und sagst Bescheid.")
            appendLine()
            appendLine("Jetzt ist: $now (= $iso)")
            appendLine()
            appendLine("Was du über den Nutzer weisst:")
            if (facts.isEmpty()) appendLine("- noch nichts") else facts.forEach { appendLine("- $it") }
            appendLine()
            appendLine("Offene Aufgaben:")
            if (tasks.isEmpty()) appendLine("- keine")
            else tasks.forEach { appendLine("- #${it.id}: ${it.title}" + (it.due?.let { d -> " (fällig $d)" } ?: "")) }
        }
    }

    /** Hält das Gespräch kurz, ohne Werkzeug-Aufrufe auseinanderzureissen. Alte Fotos fliegen raus. */
    private fun trim() {
        for (i in 0 until contents.length() - 6) {
            val ps = contents.getJSONObject(i).optJSONArray("parts") ?: continue
            for (j in ps.length() - 1 downTo 0) if (ps.getJSONObject(j).has("inline_data")) ps.remove(j)
        }
        while (contents.length() > 40) {
            contents.remove(0)
            while (contents.length() > 0 && !isUserText(contents.getJSONObject(0))) contents.remove(0)
        }
    }

    private fun isUserText(o: JSONObject): Boolean =
        o.optString("role") == "user" &&
            o.optJSONArray("parts")?.optJSONObject(0)?.has("text") == true
}
