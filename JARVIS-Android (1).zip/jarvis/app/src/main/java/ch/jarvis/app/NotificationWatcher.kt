package ch.jarvis.app

import android.app.Notification
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Liest eingehende Benachrichtigungen (WhatsApp, Insta, SMS, Mail …), damit JARVIS sie
 * vorlesen und direkt beantworten kann.
 */
class NotificationWatcher : NotificationListenerService() {

    data class Entry(
        val key: String,
        val pkg: String,
        val app: String,
        val title: String,
        val text: String,
        val time: Long,
        val reply: Notification.Action?,
    )

    companion object {
        private val entries = ArrayDeque<Entry>()
        private val lock = Any()
        private val main = Handler(Looper.getMainLooper())
        private val fmt = SimpleDateFormat("HH:mm", Locale.GERMAN)

        fun isEnabled(ctx: Context): Boolean =
            Settings.Secure.getString(ctx.contentResolver, "enabled_notification_listeners")
                ?.contains(ctx.packageName) == true

        fun list(app: String?, limit: Int = 20): JSONObject {
            val items = synchronized(lock) { entries.toList() }
                .filter { app.isNullOrBlank() || it.app.contains(app, true) || it.pkg.contains(app, true) }
                .sortedByDescending { it.time }
                .take(limit)
            return JSONObject().put("messages", JSONArray(items.map {
                JSONObject().put("app", it.app).put("from", it.title).put("text", it.text)
                    .put("time", fmt.format(Date(it.time))).put("can_reply", it.reply != null)
            }))
        }

        /** Antwortet über die "Antworten"-Funktion der Benachrichtigung (klappt z.B. bei WhatsApp, Telegram, SMS). */
        fun reply(ctx: Context, to: String, text: String): JSONObject {
            val e = synchronized(lock) { entries.toList() }
                .filter { it.reply != null && it.title.contains(to, ignoreCase = true) }
                .maxByOrNull { it.time }
                ?: return JSONObject().put("ok", false)
                    .put("error", "Keine beantwortbare Nachricht von '$to' gefunden. Alternative: App öffnen und per Bildschirm-Steuerung schreiben.")
            val action = e.reply!!
            val inputs = action.remoteInputs ?: return JSONObject().put("ok", false).put("error", "Antworten nicht möglich")
            val intent = Intent()
            val results = Bundle()
            inputs.forEach { results.putCharSequence(it.resultKey, text) }
            RemoteInput.addResultsToIntent(inputs, intent, results)
            return try {
                action.actionIntent.send(ctx, 0, intent)
                synchronized(lock) { entries.removeAll { it.key == e.key } }
                JSONObject().put("ok", true).put("result", "Antwort an ${e.title} (${e.app}) gesendet")
            } catch (ex: Exception) {
                JSONObject().put("ok", false).put("error", "Senden fehlgeschlagen: ${ex.message}")
            }
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName || sbn.isOngoing) return
        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val ex = n.extras
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = (ex.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: ex.getCharSequence(Notification.EXTRA_TEXT))
            ?.toString().orEmpty()
        if (title.isBlank() && text.isBlank()) return
        val app = runCatching {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString()
        }.getOrDefault(sbn.packageName)
        val reply = n.actions?.firstOrNull { a -> a.remoteInputs?.any { it.allowFreeFormInput } == true }
        val entry = Entry(sbn.key, sbn.packageName, app, title, text.take(500), sbn.postTime, reply)
        synchronized(lock) {
            entries.removeAll { it.key == entry.key }
            entries.addLast(entry)
            while (entries.size > 80) entries.removeFirst()
        }

        // Neue Chat-Nachrichten laut ansagen (wenn eingeschaltet)
        if (reply != null) {
            main.post {
                Jarvis.init(this)
                if (Jarvis.store.announceMessages && !Jarvis.uiVisible) {
                    Jarvis.announce("Nachricht von $title auf $app: ${text.take(200)}")
                }
            }
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        synchronized(lock) { entries.removeAll { it.key == sbn.key } }
    }
}
