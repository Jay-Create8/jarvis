package ch.jarvis.app

import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView

/**
 * Kleine schwebende JARVIS-Blase über anderen Apps (wie bei Siri/Google).
 * Zeigt Status + Antwort, wenn du ihn per "Jarvis!" im Hintergrund rufst.
 */
class Overlay(private val ctx: Context) {
    private var view: TextView? = null
    private val wm get() = ctx.getSystemService(WindowManager::class.java)

    fun show(text: String) {
        if (!Settings.canDrawOverlays(ctx)) return
        val v = view ?: createView() ?: return
        v.text = "🤖  $text"
    }

    private fun createView(): TextView? {
        val density = ctx.resources.displayMetrics.density
        val tv = TextView(ctx).apply {
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 15f
            maxLines = 8
            maxWidth = (ctx.resources.displayMetrics.widthPixels * 0.9f).toInt()
            setPadding((18 * density).toInt(), (12 * density).toInt(), (18 * density).toInt(), (12 * density).toInt())
            background = GradientDrawable().apply {
                cornerRadius = 22 * density
                setColor(0xF0071A2B.toInt())
                setStroke((2 * density).toInt(), 0xFF29E6FF.toInt())
            }
            setOnClickListener {
                hide()
                ctx.startActivity(Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = (48 * density).toInt()
        }
        return try {
            wm.addView(tv, lp)
            view = tv
            tv
        } catch (e: Exception) {
            null
        }
    }

    fun hide() {
        view?.let { runCatching { wm.removeView(it) } }
        view = null
    }
}
