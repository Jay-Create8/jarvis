package ch.jarvis.app

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.MediaStore
import androidx.core.content.FileProvider
import java.io.File

/**
 * 🛠️ JARVIS-Werkstatt: alles, was JARVIS für dich baut – Mini-Apps, Spiele, Rechner (HTML),
 * Texte, Listen, Pläne (TXT/MD/CSV). Liegt im App-Ordner "creations".
 */
object Creations {

    private val ALLOWED = setOf("html", "txt", "md", "csv", "json")

    fun dir(ctx: Context) = File(ctx.filesDir, "creations").apply { mkdirs() }

    /** Sicherer Dateiname mit passender Endung. */
    fun fileFor(ctx: Context, name: String, defaultExt: String): File {
        var base = name.trim().replace(Regex("[^A-Za-z0-9äöüÄÖÜß _.-]"), "").replace(' ', '_').take(60)
        if (base.isBlank()) base = "jarvis_${System.currentTimeMillis()}"
        val ext = base.substringAfterLast('.', "").lowercase()
        val finalName = if (ext in ALLOWED) base else "$base.$defaultExt"
        return File(dir(ctx), finalName)
    }

    fun save(ctx: Context, name: String, content: String, defaultExt: String): File {
        val f = fileFor(ctx, name, defaultExt)
        f.writeText(content, Charsets.UTF_8)
        return f
    }

    /** Datei per Name finden (auch ohne Endung, gross/klein egal). */
    fun find(ctx: Context, name: String): File? {
        val files = list(ctx)
        val q = name.trim().lowercase().replace(' ', '_')
        return files.firstOrNull { it.name.lowercase() == q }
            ?: files.firstOrNull { it.nameWithoutExtension.lowercase() == q }
            ?: files.firstOrNull { it.name.lowercase().contains(q) }
    }

    fun list(ctx: Context): List<File> =
        dir(ctx).listFiles()?.filter { it.isFile }?.sortedByDescending { it.lastModified() }.orEmpty()

    fun isApp(path: String) = path.lowercase().endsWith(".html")

    fun icon(path: String) = when (path.substringAfterLast('.').lowercase()) {
        "html" -> "🎮"
        "csv" -> "📊"
        "md" -> "📝"
        else -> "📄"
    }

    fun openIntent(ctx: Context, path: String): Intent =
        Intent(ctx, ViewerActivity::class.java)
            .putExtra(ViewerActivity.EXTRA_PATH, path)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    fun share(ctx: Context, path: String) {
        val f = File(path)
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", f)
        val type = when (f.extension.lowercase()) {
            "html" -> "text/html"
            "csv" -> "text/csv"
            else -> "text/plain"
        }
        val send = Intent(Intent.ACTION_SEND).setType(type)
            .putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(Intent.createChooser(send, "Teilen …").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    /** Kopie in den Download-Ordner (Download/JARVIS). */
    fun exportToDownloads(ctx: Context, path: String): Boolean {
        if (Build.VERSION.SDK_INT < 29) return false
        val f = File(path)
        return runCatching {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, f.name)
                put(MediaStore.Downloads.RELATIVE_PATH, "Download/JARVIS")
            }
            val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return false
            ctx.contentResolver.openOutputStream(uri)?.use { out -> f.inputStream().use { it.copyTo(out) } }
            true
        }.getOrDefault(false)
    }

    fun delete(path: String) {
        File(path).delete()
    }
}
