package ch.jarvis.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlarmManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.PowerManager
import android.provider.Settings
import android.util.Base64
import androidx.core.content.FileProvider
import java.io.ByteArrayOutputStream
import java.io.File
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.mutableStateListOf
import androidx.lifecycle.lifecycleScope
import android.widget.Toast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.time.LocalDate

private const val BRIEFING_PROMPT =
    "[Systemstart: der Nutzer hat gerade die App zum ersten Mal heute geöffnet] " +
        "Begrüsse ihn kurz passend zur Tageszeit und gib ein Mini-Briefing: hol dir die heutigen Termine " +
        "mit get_calendar_events und schau auf die offenen Aufgaben. Mach dann genau EINEN proaktiven Vorschlag. Maximal 3 Sätze."

const val DAYPLAN_PROMPT =
    "Plane meinen restlichen Tag: schau dir meine Termine und offenen Aufgaben an und mach mir einen konkreten Zeitplan mit Uhrzeiten."

class MainActivity : ComponentActivity() {

    private var pendingWakeStart = false

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { granted ->
            if (pendingWakeStart && granted[Manifest.permission.RECORD_AUDIO] == true) {
                pendingWakeStart = false
                startWakeService()
            } else if (granted[Manifest.permission.CAMERA] == true && Jarvis.wakeActive) {
                restartWake() // damit der Hintergrund-Dienst die Kamera nutzen darf
            }
            if (setupRunning) nextLater() else setupTick++
        }

    // ---------- 📷🖼️ Bilder anhängen ----------
    /** Bilder, die an die nächste Nachricht angehängt werden (Pfade). */
    val pendingImages = mutableStateListOf<String>()
    private var photoUri: Uri? = null

    private fun attach(uris: List<Uri>) {
        lifecycleScope.launch {
            val paths = withContext(Dispatchers.IO) { uris.mapNotNull { ChatImages.fromUri(this@MainActivity, it) } }
            paths.forEach { if (pendingImages.size < 4) pendingImages.add(it) }
            if (paths.size < uris.size) Toast.makeText(this@MainActivity, "Ein Bild konnte nicht geladen werden 😕", Toast.LENGTH_SHORT).show()
        }
    }

    private val cameraLauncher =
        registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
            val uri = photoUri
            if (ok && uri != null) attach(listOf(uri))
        }

    private val galleryLauncher =
        registerForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(4)) { uris ->
            if (uris.isNotEmpty()) attach(uris)
        }

    fun takePhoto() {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            permLauncher.launch(arrayOf(Manifest.permission.CAMERA))
            return
        }
        val dir = File(cacheDir, "photos").apply { mkdirs() }
        val file = File(dir, "jarvis_${System.currentTimeMillis()}.jpg")
        val uri = FileProvider.getUriForFile(this, "$packageName.files", file)
        photoUri = uri
        try {
            cameraLauncher.launch(uri)
        } catch (e: Exception) {
            Jarvis.addMsg(ChatMsg(false, "Keine Kamera-App gefunden 📷😕"))
        }
    }

    fun pickImages() {
        try {
            galleryLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        } catch (e: Exception) {
            Toast.makeText(this, "Keine Galerie gefunden 😕", Toast.LENGTH_SHORT).show()
        }
    }

    fun removePending(path: String) {
        pendingImages.remove(path)
    }

    /** Text + angehängte Bilder an JARVIS schicken. @return true, wenn verschickt */
    fun send(text: String): Boolean {
        if (text.isBlank() && pendingImages.isEmpty()) return false
        val ok = Jarvis.handleInput(text, images = pendingImages.toList())
        if (ok) pendingImages.clear()
        else Toast.makeText(this, "Moment, ich denke noch nach … ⏳", Toast.LENGTH_SHORT).show()
        return ok
    }

    fun openCreation(path: String) {
        runCatching { startActivity(Creations.openIntent(this, path)) }
            .onFailure { Toast.makeText(this, "Konnte es nicht öffnen 😕", Toast.LENGTH_SHORT).show() }
    }

    fun saveImage(path: String) {
        val ok = ChatImages.exportToGallery(this, path)
        Toast.makeText(this, if (ok) "In der Galerie gespeichert (Bilder/JARVIS) ✅" else "Speichern hat nicht geklappt 😕",
            Toast.LENGTH_SHORT).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Jarvis.init(this)
        Jarvis.askMicPermission = { permLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO)) }
        if (!Jarvis.store.setupShown) showSetup = true
        setContent { JarvisScreen(this@MainActivity) }

        if (Jarvis.store.wakeEnabled && !Jarvis.wakeActive && hasMic()) startWakeService()
        Briefing.schedule(this)
        Proactive.schedule(this)
        if (intent?.action == Intent.ACTION_ASSIST) Jarvis.startListening()
        else if (savedInstanceState == null) maybeBriefing()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == Intent.ACTION_ASSIST) Jarvis.startListening()
    }

    override fun onStart() {
        super.onStart()
        Jarvis.onUiVisible(true)
    }

    override fun onResume() {
        super.onResume()
        setupTick++
        if (awaitingReturn) {
            awaitingReturn = false
            nextLater(500)
        }
    }

    override fun onStop() {
        Jarvis.onUiVisible(false)
        super.onStop()
    }

    private fun hasMic() = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun requestPerms() {
        val wanted = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_CALENDAR,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.CAMERA,
        )
        if (Build.VERSION.SDK_INT >= 33) wanted.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = wanted.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) permLauncher.launch(missing.toTypedArray())
    }

    private fun maybeBriefing() {
        if (Jarvis.store.apiKey.isBlank()) {
            if (Jarvis.messages.isNotEmpty()) return
            Jarvis.addMsg(ChatMsg(false,
                "Hey! 👋 Ich bin JARVIS. Tipp oben auf ⚙️ und trag deinen kostenlosen Gemini-API-Key ein, dann leg ich los."))
            return
        }
        val today = LocalDate.now().toString()
        if (Jarvis.store.lastBriefing != today) {
            Jarvis.store.lastBriefing = today
            Jarvis.handleInput(BRIEFING_PROMPT, hidden = true)
        }
    }

    // ---------- "Hey JARVIS" ----------

    fun setWake(on: Boolean) {
        Jarvis.store.wakeEnabled = on
        if (on) {
            if (!hasMic()) {
                pendingWakeStart = true
                permLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
                return
            }
            startWakeService()
        } else {
            stopService(Intent(this, WakeService::class.java))
        }
    }

    /** Startet den Dienst neu, z.B. nach einer geänderten Empfindlichkeit. */
    fun restartWake() {
        if (!Jarvis.store.wakeEnabled) return
        stopService(Intent(this, WakeService::class.java))
        startWakeService()
    }

    private fun startWakeService() {
        try {
            startForegroundService(Intent(this, WakeService::class.java))
        } catch (e: Exception) {
            Jarvis.wakeInfo = "Konnte nicht starten: ${e.message}"
        }
    }

    fun saveSettings(key: String, model: String, name: String, sensitivity: Float) {
        val firstKey = Jarvis.store.apiKey.isBlank() && key.isNotBlank()
        val wakeChanged = sensitivity != Jarvis.store.wakeSensitivity
        Jarvis.saveSettings(key, model, name, sensitivity)
        if (wakeChanged) restartWake()
        if (firstKey) {
            Jarvis.store.lastBriefing = ""
            maybeBriefing()
        }
    }

    // ---------- 🦾 Superkräfte ----------

    fun hasNotificationAccess() = NotificationWatcher.isEnabled(this)

    fun openNotificationAccess() {
        // ab Android 11 direkt zum JARVIS-Schalter
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_DETAIL_SETTINGS).putExtra(
                    Settings.EXTRA_NOTIFICATION_LISTENER_COMPONENT_NAME,
                    ComponentName(this, NotificationWatcher::class.java).flattenToString()))
                return
            } catch (_: Exception) {}
        }
        startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
    }

    fun openFullScreenSettings() {
        if (Build.VERSION.SDK_INT >= 34) {
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:$packageName")))
                return
            } catch (_: Exception) {}
        }
        openAppInfo()
    }

    fun canExactAlarms(): Boolean =
        Build.VERSION.SDK_INT < 31 || getSystemService(AlarmManager::class.java).canScheduleExactAlarms()

    fun openAlarmSettings() {
        if (Build.VERSION.SDK_INT >= 31) {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
            } catch (_: Exception) { openAppInfo() }
        }
    }

    fun hasScreenControl() = ScreenAgent.instance != null

    fun hasCamera() = checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    fun requestCamera() = permLauncher.launch(arrayOf(Manifest.permission.CAMERA))

    fun openAccessibility() {
        // markiert JARVIS in der Liste (klappt bei vielen Handys)
        val key = ComponentName(this, ScreenAgent::class.java).flattenToString()
        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            .putExtra(":settings:fragment_args_key", key)
            .putExtra(":settings:show_fragment_args", Bundle().apply { putString(":settings:fragment_args_key", key) }))
    }

    /** Bei "Eingeschränkte Einstellungen" (Android 13+) muss man sie hier zuerst freigeben. */
    fun openAppInfo() {
        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
    }

    fun locationState(): Int {
        val fine = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!fine) return 0
        return if (PlaceReminders.hasPermission(this)) 2 else 1
    }

    fun requestLocation() {
        when (locationState()) {
            0 -> permLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
            1 -> if (Build.VERSION.SDK_INT >= 29) permLauncher.launch(arrayOf(Manifest.permission.ACCESS_BACKGROUND_LOCATION))
        }
    }

    fun setProactive(enabled: Boolean, eveningHour: Int) {
        Jarvis.store.proactiveEnabled = enabled
        Jarvis.store.eveningHour = eveningHour
        Jarvis.store.eveningMinute = 0
        Proactive.schedule(this)
    }

    fun setBriefing(enabled: Boolean, hour: Int, minute: Int, speak: Boolean) {
        Jarvis.store.briefingEnabled = enabled
        Jarvis.store.briefingHour = hour
        Jarvis.store.briefingMinute = minute
        Jarvis.store.briefingSpeak = speak
        Briefing.schedule(this)
    }

    // ---------- System-Einstellungen für "so gut wie möglich" ----------

    fun hasOverlay() = Settings.canDrawOverlays(this)

    fun openOverlaySettings() {
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }

    fun ignoresBatteryOptimizations(): Boolean =
        getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName)

    @SuppressLint("BatteryLife")
    fun openBatterySettings() {
        try {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        } catch (e: Exception) {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }

    // ---------- 🦾 Ein-Knopf-Einrichtung ----------

    data class SetupItem(val id: String, val label: String, val done: Boolean)

    var showSetup by mutableStateOf(false)
    var setupRunning by mutableStateOf(false)
        private set
    /** Zählt hoch, damit die Checkliste sich neu zeichnet. */
    var setupTick by mutableIntStateOf(0)
        private set
    var setupHint by mutableStateOf("")
        private set
    private val setupTried = mutableSetOf<String>()
    private var awaitingReturn = false

    private fun basicMissing(): List<String> {
        val wanted = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.CAMERA,
            Manifest.permission.READ_CALENDAR,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.SEND_SMS,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
        )
        if (Build.VERSION.SDK_INT >= 33) wanted.add(Manifest.permission.POST_NOTIFICATIONS)
        return wanted.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
    }

    fun setupItems(): List<SetupItem> = listOf(
        SetupItem("perms", "🎙️ Mikrofon, Kamera, Kalender, Kontakte, SMS, Anrufe, Standort", basicMissing().isEmpty()),
        SetupItem("bgloc", "📍 Standort \"Immer\" (Orts-Erinnerungen)", PlaceReminders.hasPermission(this)),
        SetupItem("notif", "📬 Nachrichten lesen & beantworten", hasNotificationAccess()),
        SetupItem("a11y", "🦾 Apps bedienen & Bildschirm sehen", hasScreenControl()),
        SetupItem("overlay", "💭 Blase über anderen Apps", hasOverlay()),
        SetupItem("battery", "🔋 Läuft immer (Akku-Optimierung aus)", ignoresBatteryOptimizations()),
        SetupItem("alarms", "⏰ Pünktliche Erinnerungen", canExactAlarms()),
        SetupItem("call", "📞 JARVIS darf dich anrufen", JarvisCall.canRingFullScreen(this)),
        SetupItem("wake", "👂 \"Hey Jarvis\" + Morgen-Briefing", Jarvis.wakeActive && Jarvis.store.briefingEnabled),
    )

    fun startSetup() {
        Jarvis.store.setupShown = true
        setupRunning = true
        setupTried.clear()
        nextSetupStep()
    }

    fun closeSetup() {
        Jarvis.store.setupShown = true
        setupRunning = false
        awaitingReturn = false
        showSetup = false
    }

    private fun nextLater(ms: Long = 300) {
        window.decorView.postDelayed({ nextSetupStep() }, ms)
    }

    private fun nextSetupStep() {
        setupTick++
        if (!setupRunning) return
        val next = setupItems().firstOrNull { !it.done && it.id !in setupTried }
        if (next == null) {
            setupRunning = false
            val open = setupItems().count { !it.done }
            setupHint = if (open == 0) {
                Jarvis.addMsg(ChatMsg(false, "Alle Superkräfte aktiviert 🦾🎉 Sag einfach \"Hey Jarvis\"!"))
                "Alles eingerichtet! 🎉 JARVIS hat jetzt alle Superkräfte."
            } else {
                "Fast fertig! $open Punkt(e) fehlen noch – tipp drauf, um sie nachzuholen."
            }
            return
        }
        setupTried += next.id
        runSetupStep(next.id)
    }

    /** Führt einen einzelnen Schritt aus (auch zum Nachholen per Antippen). */
    fun runSetupStep(id: String) {
        val greyHint = "\n\nIst der Schalter ausgegraut? Zurück → \"ℹ️ App-Info\" → oben rechts ⋮ → " +
            "\"Eingeschränkte Einstellungen zulassen\" → dann den Punkt nochmal antippen."
        setupHint = when (id) {
            "perms" -> "Tippe bei jeder Frage auf \"Zulassen\" bzw. \"Bei Nutzung der App\"."
            "bgloc" -> "Wähle \"Immer zulassen\" und geh dann zurück."
            "notif" -> "Schalte \"JARVIS\" ein und bestätige. Danach einfach zurück – ich mach weiter." + greyHint
            "a11y" -> "Tippe auf \"JARVIS\" (evtl. unter \"Installierte Apps\") → einschalten → Zulassen. Dann zurück." + greyHint
            "overlay" -> "Schalte \"Über anderen Apps einblenden\" ein, dann zurück."
            "battery" -> "Tippe auf \"Zulassen\" (oder \"Nicht optimieren\")."
            "alarms" -> "Schalte \"Wecker & Erinnerungen\" ein, dann zurück."
            "call" -> "Schalte \"Vollbild-Benachrichtigungen\" ein, damit JARVIS dich anrufen kann. Dann zurück."
            else -> "Schalte \"Hey Jarvis\" und das Morgen-Briefing ein …"
        }
        when (id) {
            "perms" -> basicMissing().let { if (it.isEmpty()) nextLater() else permLauncher.launch(it.toTypedArray()) }
            "bgloc" -> if (Build.VERSION.SDK_INT >= 29) {
                permLauncher.launch(arrayOf(Manifest.permission.ACCESS_BACKGROUND_LOCATION))
            } else nextLater()
            "notif" -> { awaitingReturn = true; openNotificationAccess() }
            "a11y" -> { awaitingReturn = true; openAccessibility() }
            "overlay" -> { awaitingReturn = true; openOverlaySettings() }
            "battery" -> { awaitingReturn = true; openBatterySettings() }
            "alarms" -> { awaitingReturn = true; openAlarmSettings() }
            "call" -> { awaitingReturn = true; openFullScreenSettings() }
            "wake" -> {
                if (!Jarvis.wakeActive) setWake(true)
                if (!Jarvis.store.briefingEnabled) {
                    setBriefing(true, Jarvis.store.briefingHour, Jarvis.store.briefingMinute, Jarvis.store.briefingSpeak)
                }
                nextLater(1500)
            }
        }
    }
}
