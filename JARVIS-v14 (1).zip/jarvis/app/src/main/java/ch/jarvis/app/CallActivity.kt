package ch.jarvis.app

import android.content.Intent
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

/** Der Vollbild-Anruf von JARVIS – klingelt auch auf dem Sperrbildschirm. */
class CallActivity : ComponentActivity() {

    private var ringtone: Ringtone? = null
    private var vibrator: Vibrator? = null
    private val handler = Handler(Looper.getMainLooper())

    var reason by mutableStateOf("")
        private set
    var answered by mutableStateOf(false)
        private set
    var callStart by mutableLongStateOf(0L)
        private set

    private val timeout = Runnable {
        if (!answered) {
            JarvisCall.missed(this, reason)
            finish()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Jarvis.init(this)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        reason = intent?.getStringExtra(JarvisCall.EXTRA_REASON) ?: "Ich wollte mich kurz melden"
        startRinging()
        handler.postDelayed(timeout, 45_000)
        setContent { CallScreen(this@CallActivity) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        intent.getStringExtra(JarvisCall.EXTRA_REASON)?.let { reason = it }
    }

    override fun onStart() {
        super.onStart()
        Jarvis.onUiVisible(true)
    }

    override fun onStop() {
        Jarvis.onUiVisible(false)
        super.onStop()
    }

    private fun startRinging() {
        runCatching {
            val uri = RingtoneManager.getActualDefaultRingtoneUri(this, RingtoneManager.TYPE_RINGTONE)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            ringtone = RingtoneManager.getRingtone(this, uri)?.apply {
                if (Build.VERSION.SDK_INT >= 28) isLooping = true
                play()
            }
        }
        runCatching {
            @Suppress("DEPRECATION")
            vibrator = getSystemService(Vibrator::class.java)
            vibrator?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 800, 700), 0))
        }
    }

    private fun stopRinging() {
        runCatching { ringtone?.stop() }
        runCatching { vibrator?.cancel() }
        ringtone = null
    }

    fun accept() {
        stopRinging()
        handler.removeCallbacks(timeout)
        JarvisCall.dismissNotification(this)
        answered = true
        callStart = System.currentTimeMillis()
        Jarvis.startCall(reason)
    }

    fun decline() {
        stopRinging()
        handler.removeCallbacks(timeout)
        JarvisCall.dismissNotification(this)
        finish()
    }

    fun hangUp() {
        Jarvis.endCall()
        finish()
    }

    override fun onDestroy() {
        stopRinging()
        handler.removeCallbacks(timeout)
        if (answered && Jarvis.callActive) Jarvis.endCall()
        super.onDestroy()
    }
}

@Composable
private fun CallScreen(a: CallActivity) {
    var seconds by remember { mutableLongStateOf(0L) }
    LaunchedEffect(a.answered) {
        while (a.answered) {
            seconds = (System.currentTimeMillis() - a.callStart) / 1000
            delay(1000)
        }
    }
    Column(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF02060D), Color(0xFF06213A), Color(0xFF02060D))))
            .safeDrawingPadding()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(Modifier.height(32.dp))
        Text(
            if (a.answered) "Im Gespräch · %d:%02d".format(seconds / 60, seconds % 60) else "📞 Eingehender Anruf",
            color = JarvisColors.Cyan.copy(alpha = 0.8f), fontSize = 16.sp,
        )
        Spacer(Modifier.height(8.dp))
        Text("J.A.R.V.I.S.", color = Color.White, fontSize = 36.sp, fontWeight = FontWeight.Bold, letterSpacing = 6.sp)
        Spacer(Modifier.height(12.dp))
        Text(a.reason, color = Color.White.copy(alpha = 0.75f), fontSize = 16.sp, textAlign = TextAlign.Center)

        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            Reactor(if (a.answered) Jarvis.phase else Phase.THINKING, Jarvis.level) {
                if (a.answered) Jarvis.toggleListening()
            }
        }

        if (a.answered) {
            Text(Jarvis.status, color = JarvisColors.Cyan, fontSize = 14.sp, textAlign = TextAlign.Center)
            Spacer(Modifier.height(24.dp))
            CallButton("Auflegen", Color(0xFFE53950), "✕") { a.hangUp() }
        } else {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                CallButton("Ablehnen", Color(0xFFE53950), "✕") { a.decline() }
                CallButton("Annehmen", Color(0xFF2ECC71), "📞") { a.accept() }
            }
        }
        Spacer(Modifier.height(32.dp))
    }
}

@Composable
private fun CallButton(label: String, color: Color, icon: String, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(76.dp).clip(CircleShape).background(color).clickable(onClick = onClick),
            contentAlignment = Alignment.Center,
        ) {
            Text(icon, fontSize = 30.sp, color = Color.White)
        }
        Spacer(Modifier.height(8.dp))
        Text(label, color = Color.White, fontSize = 14.sp)
    }
}
