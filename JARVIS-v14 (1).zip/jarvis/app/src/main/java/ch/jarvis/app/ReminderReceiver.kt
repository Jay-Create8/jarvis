package ch.jarvis.app

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

/** Zeigt eine Erinnerung als Benachrichtigung an, wenn die Zeit gekommen ist. */
class ReminderReceiver : BroadcastReceiver() {

    companion object {
        private fun pending(ctx: Context, id: Int, text: String?, call: Boolean = false): PendingIntent =
            PendingIntent.getBroadcast(
                ctx, id,
                Intent(ctx, ReminderReceiver::class.java).putExtra("text", text).putExtra("id", id).putExtra("call", call),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            )

        fun schedule(ctx: Context, r: Store.Reminder) = scheduleAt(ctx, r.time, pending(ctx, r.id, r.text, r.call))

        /** Möglichst exakt planen; ohne Erlaubnis für exakte Wecker etwas ungenauer. */
        fun scheduleAt(ctx: Context, time: Long, pi: PendingIntent) {
            val am = ctx.getSystemService(AlarmManager::class.java)
            try {
                if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, time, pi)
                } else {
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, time, pi)
                }
            } catch (e: SecurityException) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, time, pi)
            }
        }

        fun cancel(ctx: Context, id: Int) {
            ctx.getSystemService(AlarmManager::class.java).cancel(pending(ctx, id, null))
        }
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        Jarvis.init(ctx)
        val id = intent.getIntExtra("id", 1)
        val text = intent.getStringExtra("text") ?: "Erinnerung"
        Jarvis.store.removeReminder(id)
        // Wichtige Erinnerung? Dann ruft JARVIS an.
        if (intent.getBooleanExtra("call", false)) JarvisCall.ring(ctx, "Erinnerung: $text")
        if (!Jarvis.canNotify()) return
        val n = Notification.Builder(ctx, Jarvis.CH_REMINDER)
            .setSmallIcon(R.drawable.ic_notify)
            .setContentTitle("🤖 JARVIS erinnert dich")
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setContentIntent(Jarvis.openAppIntent())
            .setAutoCancel(true)
            .build()
        ctx.getSystemService(NotificationManager::class.java).notify(id, n)
    }
}

/** Nach einem Handy-Neustart: Erinnerungen neu planen und an "Hey JARVIS" erinnern. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        Jarvis.init(ctx)
        val now = System.currentTimeMillis()
        Jarvis.store.reminders().forEach { r ->
            if (r.time > now) ReminderReceiver.schedule(ctx, r) else Jarvis.store.removeReminder(r.id)
        }
        Briefing.schedule(ctx)
        Proactive.schedule(ctx)
        PlaceReminders.restoreAll(ctx)
        // Android erlaubt nach dem Start kein Mikrofon im Hintergrund -> einmal antippen
        if (Jarvis.store.wakeEnabled && Jarvis.canNotify()) {
            val n = Notification.Builder(ctx, Jarvis.CH_WAKE)
                .setSmallIcon(R.drawable.ic_notify)
                .setContentTitle("👂 \"Hey JARVIS\" aktivieren")
                .setContentText("Kurz antippen, dann hört JARVIS wieder zu.")
                .setContentIntent(Jarvis.openAppIntent())
                .setAutoCancel(true)
                .build()
            ctx.getSystemService(NotificationManager::class.java).notify(9, n)
        }
    }
}
