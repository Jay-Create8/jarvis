package ch.jarvis.app

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Base64
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.UUID

/** Bilder im Chat: speichern, verkleinern, für die KI umwandeln, in die Galerie exportieren. */
object ChatImages {

    private const val MAX_SIDE = 1280

    private fun dir(ctx: Context) = File(ctx.filesDir, "chat_images").apply { mkdirs() }

    /** Verkleinert ein Bild (max. 1280 px) und speichert es als JPEG im App-Ordner. */
    fun save(ctx: Context, bmp: Bitmap): String {
        val scale = MAX_SIDE.toFloat() / maxOf(bmp.width, bmp.height)
        val small = if (scale < 1f) {
            Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt().coerceAtLeast(1),
                (bmp.height * scale).toInt().coerceAtLeast(1), true)
        } else bmp
        val f = File(dir(ctx), UUID.randomUUID().toString() + ".jpg")
        f.outputStream().use { small.compress(Bitmap.CompressFormat.JPEG, 85, it) }
        return f.absolutePath
    }

    /** Bild aus Galerie/Kamera (Uri) übernehmen. */
    fun fromUri(ctx: Context, uri: Uri): String? = runCatching {
        decodeScaled({ ctx.contentResolver.openInputStream(uri) }, MAX_SIDE)?.let { save(ctx, it) }
    }.getOrNull()

    /** Bild aus heruntergeladenen Bytes übernehmen (z.B. aus der Bildersuche). */
    fun fromBytes(ctx: Context, bytes: ByteArray): String? = runCatching {
        decodeScaled({ bytes.inputStream() }, MAX_SIDE)?.let { save(ctx, it) }
    }.getOrNull()

    /** Für die KI: JPEG als Base64. */
    fun base64(path: String): String? = runCatching {
        Base64.encodeToString(File(path).readBytes(), Base64.NO_WRAP)
    }.getOrNull()

    /** Kleines Vorschaubild für den Chat laden. */
    fun thumbnail(path: String, maxSide: Int): Bitmap? = runCatching {
        decodeScaled({ File(path).inputStream() }, maxSide)
    }.getOrNull()

    private fun decodeScaled(open: () -> java.io.InputStream?, maxSide: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        open()?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= maxSide) sample *= 2
        return open()?.use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample }) }
    }

    /** Bild in die Handy-Galerie (Ordner "Pictures/JARVIS") kopieren. */
    fun exportToGallery(ctx: Context, path: String): Boolean {
        if (Build.VERSION.SDK_INT < 29) return false
        return runCatching {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "JARVIS_${System.currentTimeMillis()}.jpg")
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/JARVIS")
            }
            val uri = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: return false
            ctx.contentResolver.openOutputStream(uri)?.use { out -> File(path).inputStream().use { it.copyTo(out) } }
            true
        }.getOrDefault(false)
    }

    /** Alle Chat-Bilder löschen (bei "Neuer Chat"). */
    fun clearAll(ctx: Context) {
        dir(ctx).listFiles()?.forEach { it.delete() }
    }

    /** Für Kompatibilität mit Base64-Fotos: Bitmap → JPEG-Bytes. */
    fun jpegBytes(bmp: Bitmap): ByteArray = ByteArrayOutputStream().also {
        bmp.compress(Bitmap.CompressFormat.JPEG, 85, it)
    }.toByteArray()
}
