package ch.jarvis.app

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import java.nio.FloatBuffer

/**
 * Offline-Erkennung von "Hey Jarvis" mit openWakeWord (läuft komplett auf dem Handy, gratis).
 *
 * Ablauf pro 80-ms-Häppchen Audio (1280 Samples @ 16 kHz):
 *   Audio → Mel-Spektrogramm (8 Frames) → Sprach-Embedding (96 Werte) → "Hey Jarvis"-Modell (Wert 0..1)
 */
class WakeWordDetector(ctx: Context, private val onDetected: () -> Unit) {

    companion object {
        private const val SR = 16_000
        private const val CHUNK = 1280
        private const val CONTEXT = 480 // 3 * 160 Samples Vorlauf für das Mel-Spektrogramm
        private const val MEL_WINDOW = 76
        private const val FEATURES = 16
    }

    private val env = OrtEnvironment.getEnvironment()
    private val melModel: OrtSession
    private val embModel: OrtSession
    private val wwModel: OrtSession

    /** 0..1, höher = reagiert leichter */
    @Volatile var sensitivity = 0.5f
    @Volatile var lastScore = 0f
        private set

    private var thread: Thread? = null
    @Volatile private var running = false

    // Puffer
    private val raw = FloatArray(CHUNK + CONTEXT)
    private val mel = ArrayDeque<FloatArray>()
    private val feats = ArrayDeque<FloatArray>()
    private var cooldownChunks = 0

    init {
        val opts = OrtSession.SessionOptions().apply { setIntraOpNumThreads(1) }
        fun load(name: String) = env.createSession(ctx.assets.open(name).use { it.readBytes() }, opts)
        melModel = load("melspectrogram.onnx")
        embModel = load("embedding_model.onnx")
        wwModel = load("hey_jarvis_v0.1.onnx")
        resetBuffers()
    }

    private fun resetBuffers() {
        raw.fill(0f)
        mel.clear()
        repeat(MEL_WINDOW) { mel.addLast(FloatArray(32) { 1f }) }
        feats.clear()
    }

    @SuppressLint("MissingPermission") // wird vom Dienst vorher geprüft
    fun start(): Boolean {
        if (running) return true
        val minBuf = AudioRecord.getMinBufferSize(SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = try {
            AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, SR, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, CHUNK * 2 * 4))
        } catch (e: Exception) {
            return false
        }
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release()
            return false
        }
        try {
            rec.startRecording()
        } catch (e: Exception) {
            rec.release()
            return false
        }
        resetBuffers()
        running = true
        thread = Thread({
            val pcm = ShortArray(CHUNK)
            try {
                while (running) {
                    var got = 0
                    while (got < CHUNK && running) {
                        val n = rec.read(pcm, got, CHUNK - got)
                        if (n < 0) { running = false; break }
                        got += n
                    }
                    if (!running) break
                    if (process(pcm)) onDetected()
                }
            } catch (_: Exception) {
            } finally {
                runCatching { rec.stop() }
                rec.release()
            }
        }, "jarvis-wakeword").also { it.start() }
        return true
    }

    fun stop() {
        running = false
        thread?.join(1000)
        thread = null
    }

    fun close() {
        stop()
        runCatching { melModel.close(); embModel.close(); wwModel.close() }
    }

    /** @return true, wenn "Hey Jarvis" erkannt wurde */
    private fun process(pcm: ShortArray): Boolean {
        // 1) Audio-Puffer weiterschieben
        System.arraycopy(raw, CHUNK, raw, 0, CONTEXT)
        for (i in 0 until CHUNK) raw[CONTEXT + i] = pcm[i].toFloat()

        // 2) Mel-Spektrogramm
        val melOut = run(melModel, "input", raw, longArrayOf(1, raw.size.toLong()))
        val frames = melOut.size / 32
        for (f in 0 until frames) {
            mel.addLast(FloatArray(32) { melOut[f * 32 + it] / 10f + 2f })
        }
        while (mel.size > MEL_WINDOW) mel.removeFirst()

        // 3) Sprach-Embedding aus den letzten 76 Mel-Frames
        val melFlat = FloatArray(MEL_WINDOW * 32)
        mel.forEachIndexed { i, row -> System.arraycopy(row, 0, melFlat, i * 32, 32) }
        val emb = run(embModel, "input_1", melFlat, longArrayOf(1, MEL_WINDOW.toLong(), 32, 1))
        feats.addLast(emb.copyOf(96))
        while (feats.size > FEATURES) feats.removeFirst()
        if (feats.size < FEATURES) return false

        // 4) "Hey Jarvis"-Wahrscheinlichkeit
        val featFlat = FloatArray(FEATURES * 96)
        feats.forEachIndexed { i, row -> System.arraycopy(row, 0, featFlat, i * 96, 96) }
        val score = run(wwModel, "x.1", featFlat, longArrayOf(1, FEATURES.toLong(), 96))[0]
        lastScore = score

        if (cooldownChunks > 0) { cooldownChunks--; return false }
        val threshold = (1f - sensitivity).coerceIn(0.1f, 0.9f)
        if (score >= threshold) {
            cooldownChunks = 25 // ~2 Sekunden Ruhe nach einem Treffer
            feats.clear()
            return true
        }
        return false
    }

    private fun run(session: OrtSession, input: String, data: FloatArray, shape: LongArray): FloatArray =
        OnnxTensor.createTensor(env, FloatBuffer.wrap(data), shape).use { tensor ->
            session.run(mapOf(input to tensor)).use { result ->
                val fb = (result.get(0) as OnnxTensor).floatBuffer
                val out = FloatArray(fb.remaining())
                fb.get(out)
                out
            }
        }
}
