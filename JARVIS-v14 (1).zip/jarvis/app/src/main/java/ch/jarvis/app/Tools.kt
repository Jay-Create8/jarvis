package ch.jarvis.app

import android.Manifest
import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.SearchManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.provider.MediaStore
import android.provider.Settings
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

/** Alle Dinge, die JARVIS auf dem Handy wirklich TUN kann. */
class Tools(private val act: Context, private val store: Store) {

    private data class P(val name: String, val type: String, val desc: String)

    companion object {
        private fun fn(name: String, desc: String, params: List<P> = emptyList(), required: List<String> = emptyList()): JSONObject {
            val o = JSONObject().put("name", name).put("description", desc)
            if (params.isNotEmpty()) {
                val props = JSONObject()
                params.forEach { props.put(it.name, JSONObject().put("type", it.type).put("description", it.desc)) }
                o.put("parameters", JSONObject().put("type", "object").put("properties", props)
                    .put("required", JSONArray(required)))
            }
            return o
        }

        private const val DT = "Datum+Zeit im Format yyyy-MM-dd HH:mm"

        fun declarations(): JSONArray = JSONArray(listOf(
            fn("add_task", "Neue Aufgabe/To-do anlegen.",
                listOf(P("title", "string", "Was zu tun ist"), P("due", "string", "Optional fällig am, $DT")), listOf("title")),
            fn("list_tasks", "Aufgaben auflisten.",
                listOf(P("include_done", "boolean", "Auch erledigte zeigen"))),
            fn("complete_task", "Aufgabe als erledigt markieren.", listOf(P("id", "integer", "Aufgaben-ID")), listOf("id")),
            fn("delete_task", "Aufgabe löschen.", listOf(P("id", "integer", "Aufgaben-ID")), listOf("id")),
            fn("remember", "Dauerhaften Fakt über den Nutzer merken.", listOf(P("fact", "string", "Der Fakt, kurz")), listOf("fact")),
            fn("forget", "Gemerkte Fakten zu einem Stichwort löschen.", listOf(P("about", "string", "Stichwort")), listOf("about")),
            fn("set_reminder", "Erinnerung zu einem Zeitpunkt planen. Bei wichtigen Dingen (Termin, Abfahrt, Medikament, Prüfung, Wecken) call=true: dann ruft JARVIS zusätzlich an.",
                listOf(P("text", "string", "Woran erinnert wird"), P("datetime", "string", DT),
                    P("call", "boolean", "true = JARVIS ruft dazu an")), listOf("text", "datetime")),
            fn("add_call_trigger", "Regel: JARVIS ruft an, sobald eine Nachricht von einer bestimmten Person kommt und/oder ein Stichwort enthält. Z.B. 'Ruf mich an, wenn Lea schreibt'.",
                listOf(P("from", "string", "Name des Absenders/Chats (leer = egal)"), P("keyword", "string", "Stichwort im Text (leer = egal)"))),
            fn("list_call_triggers", "Anruf-Regeln auflisten."),
            fn("remove_call_trigger", "Anruf-Regel löschen.", listOf(P("id", "integer", "ID")), listOf("id")),
            fn("list_reminders", "Geplante Erinnerungen auflisten."),
            fn("cancel_reminder", "Erinnerung löschen.", listOf(P("id", "integer", "Erinnerungs-ID")), listOf("id")),
            fn("internet_search", "Aktuelle Infos im Internet recherchieren (News, Sport, Preise, Öffnungszeiten, Fakten). Gibt eine Antwort mit Quellen zurück.",
                listOf(P("query", "string", "Was genau gesucht wird")), listOf("query")),
            fn("get_weather", "Wetter jetzt, die nächsten Stunden und 3 Tage.",
                listOf(P("place", "string", "Ort; leer = aktueller Standort"))),
            fn("get_location", "Wo ist der Nutzer gerade (Adresse)?"),
            fn("read_notifications", "Neue Nachrichten/Benachrichtigungen lesen (WhatsApp, SMS, Insta, Mail …).",
                listOf(P("app", "string", "Optional nur von dieser App, z.B. WhatsApp"))),
            fn("reply_message", "Direkt auf eine Nachricht antworten (über die Benachrichtigung). SENDET WIRKLICH.",
                listOf(P("to", "string", "Name des Chats/Absenders"), P("text", "string", "Antworttext")), listOf("to", "text")),
            fn("look_at_screen", "Schaut sich an, was GERADE auf dem Bildschirm zu sehen ist (auch Kamera-Sucher, Fotos, Videos, Spiele, Webseiten) und beantwortet eine Frage dazu. Für 'Was ist das?', 'Was steht da?', 'Hilf mir hiermit'.",
                listOf(P("question", "string", "Was der Nutzer wissen will")), listOf("question")),
            fn("look_through_camera", "Macht unsichtbar im Hintergrund ein Foto mit der Handy-Kamera (ohne Kamera-App) und beantwortet eine Frage dazu. Für 'Was sieht die Kamera?', 'Was ist vor mir?', 'Wie seh ich aus?' (dann front).",
                listOf(P("question", "string", "Was der Nutzer wissen will"), P("camera", "string", "back (Standard) oder front (Selfie)")), listOf("question")),
            fn("show_images", "Schickt Bilder in den Chat, damit der Nutzer sie sieht: per Bildersuche (query, am besten englisch) und/oder von Webseiten bzw. direkten Bild-Links (urls, z.B. die page_url aus internet_search). Für 'zeig mir…', 'wie sieht … aus', 'Bild von…'.",
                listOf(P("query", "string", "Suchbegriff für die Bildersuche, z.B. 'snow leopard' oder 'Glarus Switzerland'"),
                    P("urls", "string", "Optional: Webseiten- oder Bild-URLs, durch Leerzeichen getrennt"),
                    P("count", "integer", "Wie viele Bilder (1-6, Standard 3)"),
                    P("caption", "string", "Optional: kurze Bildunterschrift"))),
            fn("guide_me", "ANLEITUNGS-MODUS: Führt den Nutzer Schritt für Schritt zu einem Ziel – schaut auf den Bildschirm, markiert genau den nächsten Knopf, sagt an was zu tun ist, wartet bis der Nutzer es gemacht hat, und wiederholt das bis zum Ziel. Immer benutzen, wenn der Nutzer etwas SELBST machen will/soll ('zeig mir wie', 'führ mich', 'wie geht…') oder du es nicht selbst machen darfst (Passwort, Bestätigung, Kauf).",
                listOf(P("goal", "string", "Das Ziel in einem Satz, z.B. 'Dunkelmodus einschalten' oder 'Fehlermeldung bei Google beheben'")), listOf("goal")),
            fn("highlight_on_screen", "Markiert etwas auf dem Bildschirm mit einem leuchtenden Rahmen (über jeder App). Für 'Wo ist …?', 'Zeig mir …', 'Markiere …'. Entweder 'what' beschreiben (funktioniert mit allem, auch Bildern/Kamera) oder 'element' aus read_screen angeben.",
                listOf(P("what", "string", "Was markiert werden soll, z.B. 'der Senden-Knopf' oder 'alle Rechtschreibfehler'"),
                    P("element", "integer", "Optional: Nummer aus read_screen"),
                    P("label", "string", "Optional: Beschriftung am Rahmen"),
                    P("seconds", "integer", "Wie lange sichtbar (Standard 8)"))),
            fn("clear_highlights", "Entfernt alle Markierungen vom Bildschirm."),
            fn("read_screen", "Liest, was gerade auf dem Bildschirm ist. Liefert nummerierte Elemente [n] zum Antippen."),
            fn("tap", "Tippt auf ein Element vom Bildschirm.",
                listOf(P("element", "integer", "Nummer aus read_screen"), P("text", "string", "Oder: sichtbarer Text des Knopfs"))),
            fn("long_press", "Langes Drücken auf ein Element.", listOf(P("element", "integer", "Nummer aus read_screen")), listOf("element")),
            fn("type_text", "Schreibt Text in ein Eingabefeld.",
                listOf(P("text", "string", "Der Text"), P("element", "integer", "Nummer des Felds aus read_screen")), listOf("text")),
            fn("scroll", "Scrollt den Bildschirm.",
                listOf(P("direction", "string", "down oder up"), P("element", "integer", "Optional: Nummer der scrollbaren Liste")), listOf("direction")),
            fn("press_button", "System-Knopf drücken.",
                listOf(P("button", "string", "back, home, recents, previous_app (zurück zur vorherigen App), notifications, quick_settings, lock oder screenshot")), listOf("button")),
            fn("say", "Sagt SOFORT etwas laut (auch mitten in einer Aufgabe), z.B. die Anweisung im Anleitungs-Modus: 'Tippe jetzt auf den markierten Knopf'.",
                listOf(P("text", "string", "Was gesagt werden soll, kurz")), listOf("text")),
            fn("wait_for_screen_change", "Wartet, bis der Nutzer etwas auf dem Bildschirm macht (tippt, schreibt, App wechselt). Für den Anleitungs-Modus nach jeder Markierung.",
                listOf(P("timeout_seconds", "integer", "Max. Wartezeit, Standard 45"))),
            fn("call_me", "JARVIS ruft den Nutzer an: Vollbild-Anruf mit Klingelton, auch bei gesperrtem Handy. Sofort oder zu einer Zeit. Für Weckrufe, wichtige Erinnerungen oder wenn der Nutzer 'ruf mich an' sagt.",
                listOf(P("reason", "string", "Warum JARVIS anruft"), P("datetime", "string", "Optional: wann, $DT; leer = sofort")), listOf("reason")),
            fn("wait", "Kurz warten, bis eine App geladen hat.", listOf(P("seconds", "integer", "1-5")), listOf("seconds")),
            fn("set_location_reminder", "Erinnerung, die auslöst, sobald der Nutzer an einem Ort ankommt.",
                listOf(P("text", "string", "Woran erinnern"), P("place", "string", "Ort, Geschäft oder Adresse, z.B. 'Coop Glarus'")), listOf("text", "place")),
            fn("list_location_reminders", "Orts-Erinnerungen auflisten."),
            fn("cancel_location_reminder", "Orts-Erinnerung löschen.", listOf(P("id", "string", "ID")), listOf("id")),
            fn("set_briefing", "Automatisches tägliches Morgen-Briefing ein-/ausschalten oder Uhrzeit ändern.",
                listOf(P("enabled", "boolean", "an/aus"), P("time", "string", "Uhrzeit HH:mm"), P("speak", "boolean", "laut vorlesen?")), listOf("enabled")),
            fn("set_proactive", "Mitdenken ein/aus (JARVIS schaut von selbst nach und ruft bei Wichtigem an) und Uhrzeit des Abend-Checks.",
                listOf(P("enabled", "boolean", "an/aus"), P("evening_hour", "integer", "Stunde des Abend-Checks 0-23")), listOf("enabled")),
            fn("announce_messages", "Neue Chat-Nachrichten automatisch laut ansagen ein/aus.",
                listOf(P("enabled", "boolean", "an/aus")), listOf("enabled")),
            fn("set_alarm", "Wecker in der Uhr-App stellen.",
                listOf(P("hour", "integer", "Stunde 0-23"), P("minute", "integer", "Minute 0-59"), P("label", "string", "Bezeichnung")), listOf("hour")),
            fn("set_timer", "Countdown-Timer stellen.",
                listOf(P("seconds", "integer", "Dauer in Sekunden"), P("label", "string", "Bezeichnung")), listOf("seconds")),
            fn("open_app", "Eine installierte App öffnen.", listOf(P("name", "string", "App-Name, z.B. Spotify")), listOf("name")),
            fn("web_search", "Google-Suche im Browser öffnen.", listOf(P("query", "string", "Suchbegriff")), listOf("query")),
            fn("open_url", "Webseite öffnen.", listOf(P("url", "string", "URL")), listOf("url")),
            fn("navigate", "Navigation/Route in Google Maps starten.",
                listOf(P("destination", "string", "Ziel"), P("mode", "string", "driving, walking oder bicycling")), listOf("destination")),
            fn("find_contact", "Kontakt im Adressbuch suchen.", listOf(P("name", "string", "Name")), listOf("name")),
            fn("update_plan", "Bei Aufgaben mit mehreren Schritten: Plan als Checkliste im Chat zeigen/aktualisieren. ZUERST aufrufen (done=0), dann nach JEDEM erledigten Schritt wieder mit höherem done.",
                listOf(P("title", "string", "Kurzer Titel der Aufgabe"), P("steps", "string", "Alle Schritte, einer pro Zeile"),
                    P("done", "integer", "Wie viele Schritte schon erledigt sind")), listOf("steps", "done")),
            fn("build_app", "BAUT eine echte Mini-App/Spiel/Rechner/Quiz/Lernkarten/Website als EINE komplette HTML-Datei (HTML+CSS+JS inline, keine externen Links/Bibliotheken, handyfreundlich, schönes dunkles Design). Wird gespeichert und als Karte im Chat gezeigt, Nutzer kann sie öffnen und spielen. Gleicher Name = überschreiben (für Änderungen).",
                listOf(P("name", "string", "Kurzer Name, z.B. Snake"), P("html", "string", "Kompletter HTML-Code, beginnt mit <!doctype html>")), listOf("name", "html")),
            fn("create_file", "Erstellt ein Dokument (Text, Liste, Plan, Notizen, Tabelle) und zeigt es als Karte im Chat.",
                listOf(P("name", "string", "Dateiname"), P("content", "string", "Kompletter Inhalt"),
                    P("format", "string", "txt (Standard), md oder csv")), listOf("name", "content")),
            fn("read_file", "Liest eine selbst gebaute App/Datei (um sie zu ändern oder zu prüfen).", listOf(P("name", "string", "Name")), listOf("name")),
            fn("list_files", "Listet alles, was JARVIS schon gebaut/erstellt hat."),
            fn("open_file", "Öffnet eine gebaute App/Datei zum Anschauen bzw. Spielen.", listOf(P("name", "string", "Name")), listOf("name")),
            fn("share_file", "Teilen-Menü für eine gebaute Datei öffnen (z.B. an Freunde schicken).", listOf(P("name", "string", "Name")), listOf("name")),
            fn("save_to_downloads", "Kopiert eine gebaute Datei in den Download-Ordner (Download/JARVIS).", listOf(P("name", "string", "Name")), listOf("name")),
            fn("call", "Ruft WIRKLICH an (Anruf startet sofort, wenn erlaubt – sonst öffnet sich die Wähltastatur). Nur wenn der Nutzer klar anrufen will.",
                listOf(P("target", "string", "Telefonnummer oder Kontaktname")), listOf("target")),
            fn("send_message", "Schickt eine Nachricht WIRKLICH ab – per WhatsApp (öffnet den Chat und tippt selbst auf Senden) oder SMS (direkt im Hintergrund). Vorher Text bestätigen lassen, ausser der Nutzer hat ihn genau diktiert.",
                listOf(P("to", "string", "Kontaktname oder Nummer"), P("text", "string", "Nachricht"),
                    P("app", "string", "whatsapp (Standard) oder sms")), listOf("to", "text")),
            fn("send_sms", "SMS nur vorbereiten (Nutzer drückt selbst Senden). Zum echten Senden send_message nutzen.",
                listOf(P("target", "string", "Nummer oder Kontaktname"), P("text", "string", "Nachricht")), listOf("target", "text")),
            fn("share_text", "Text über eine App teilen, z.B. WhatsApp (Nutzer wählt Empfänger und sendet).",
                listOf(P("text", "string", "Text"), P("app", "string", "Optional: whatsapp, telegram oder leer für Auswahl")), listOf("text")),
            fn("flashlight", "Taschenlampe an/aus.", listOf(P("on", "boolean", "true = an")), listOf("on")),
            fn("set_volume", "Medien-Lautstärke setzen.", listOf(P("percent", "integer", "0-100")), listOf("percent")),
            fn("battery_status", "Akkustand abfragen."),
            fn("get_calendar_events", "Termine aus dem Kalender lesen, ab heute.",
                listOf(P("days", "integer", "Wie viele Tage ab heute (1 = nur heute)"))),
            fn("add_calendar_event", "Kalendertermin anlegen (Kalender-App öffnet sich zum Bestätigen).",
                listOf(P("title", "string", "Titel"), P("start", "string", DT), P("duration_minutes", "integer", "Dauer"),
                    P("location", "string", "Ort")), listOf("title", "start")),
            fn("play_music", "Musik abspielen (Song, Künstler oder Playlist).", listOf(P("query", "string", "Was abspielen")), listOf("query")),
            fn("open_settings", "Einstellungs-Seite öffnen.",
                listOf(P("page", "string", "wifi, bluetooth, display, sound, battery, apps oder general")), listOf("page")),
        ))

        fun label(name: String): String = when (name) {
            "internet_search" -> "Suche im Internet …"
            "look_at_screen" -> "Schaue mir den Bildschirm an … 👁️"
            "highlight_on_screen" -> "Markiere … 🎯"
            "guide_me" -> "Führe dich Schritt für Schritt … 🧭"
            "show_images" -> "Suche Bilder … 🖼️"
            "update_plan" -> "Plane die Schritte … 📋"
            "build_app" -> "Baue … 🛠️"
            "create_file" -> "Schreibe Datei … 📄"
            "read_file", "list_files" -> "Schaue in die Werkstatt …"
            "wait_for_screen_change" -> "Warte auf dich … 👆"
            "call_me" -> "Plane Anruf … 📞"
            "look_through_camera" -> "Schaue durch die Kamera … 📸"
            "get_weather" -> "Checke das Wetter …"
            "read_notifications" -> "Lese Nachrichten …"
            "reply_message" -> "Sende Antwort …"
            "read_screen" -> "Schaue auf den Bildschirm …"
            "tap", "long_press" -> "Tippe …"
            "type_text" -> "Schreibe …"
            "scroll" -> "Scrolle …"
            "set_location_reminder" -> "Plane Orts-Erinnerung …"
            "set_briefing" -> "Stelle Briefing ein …"
            "add_task" -> "Lege Aufgabe an …"
            "list_tasks" -> "Schaue Aufgaben an …"
            "complete_task" -> "Hake Aufgabe ab …"
            "remember" -> "Merke mir das …"
            "set_reminder" -> "Plane Erinnerung …"
            "set_alarm" -> "Stelle Wecker …"
            "set_timer" -> "Stelle Timer …"
            "open_app" -> "Öffne App …"
            "web_search" -> "Suche im Web …"
            "navigate" -> "Starte Navigation …"
            "get_calendar_events" -> "Checke Kalender …"
            "play_music" -> "Starte Musik …"
            else -> "Arbeite dran …"
        }
    }

    private val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.GERMAN)

    private fun ok(msg: String) = JSONObject().put("ok", true).put("result", msg)
    private fun err(msg: String) = JSONObject().put("ok", false).put("error", msg)
    private fun has(perm: String) = act.checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED

    /**
     * Startet eine andere App. Im Hintergrund erlaubt Android das nur mit sichtbarer
     * JARVIS-Blase ("Über anderen Apps anzeigen") – sonst gibt's eine Tipp-Benachrichtigung.
     */
    private fun start(i: Intent, msg: String): JSONObject {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val canLaunch = Jarvis.uiVisible || Settings.canDrawOverlays(act)
        if (!canLaunch) {
            if (!Jarvis.canNotify()) return err("Handy ist gesperrt/App im Hintergrund, Öffnen nicht möglich")
            val pi = PendingIntent.getActivity(act, 1, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val n = Notification.Builder(act, Jarvis.CH_REPLY)
                .setSmallIcon(R.drawable.ic_notify)
                .setContentTitle("🤖 Tippen zum Ausführen")
                .setContentText(msg)
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build()
            act.getSystemService(NotificationManager::class.java).notify(Jarvis.TAP_NOTIFICATION_ID, n)
            return ok("$msg (als Benachrichtigung bereit, Nutzer muss draufdrücken)")
        }
        return try {
            act.startActivity(i); ok(msg)
        } catch (e: ActivityNotFoundException) {
            err("Keine passende App auf dem Handy gefunden")
        } catch (e: SecurityException) {
            err("Nicht erlaubt: ${e.message}")
        }
    }

    private fun parseDate(s: String): Date? =
        listOf("yyyy-MM-dd HH:mm", "yyyy-MM-dd'T'HH:mm", "yyyy-MM-dd'T'HH:mm:ss", "yyyy-MM-dd").firstNotNullOfOrNull {
            runCatching { SimpleDateFormat(it, Locale.GERMAN).apply { isLenient = false }.parse(s.trim()) }.getOrNull()
        }

    fun run(name: String, a: JSONObject): JSONObject = runTool(name, a)

    private fun runTool(name: String, a: JSONObject): JSONObject { return when (name) {
        "add_task" -> {
            val t = store.addTask(a.getString("title"), a.optString("due").ifBlank { null })
            ok("Aufgabe #${t.id} angelegt")
        }
        "list_tasks" -> JSONObject().put("tasks",
            JSONArray(store.tasks().filter { a.optBoolean("include_done") || !it.done }.map { it.toJson() }))
        "complete_task" -> if (store.setDone(a.getLong("id"))) ok("erledigt") else err("Aufgabe nicht gefunden")
        "delete_task" -> if (store.deleteTask(a.getLong("id"))) ok("gelöscht") else err("Aufgabe nicht gefunden")
        "remember" -> { store.addFact(a.getString("fact")); ok("gemerkt") }
        "forget" -> ok("${store.removeFacts(a.getString("about"))} Einträge gelöscht")
        "set_reminder" -> setReminder(a.getString("text"), a.getString("datetime"), a.optBoolean("call"))
        "add_call_trigger" -> {
            val from = a.optString("from")
            val kw = a.optString("keyword")
            if (from.isBlank() && kw.isBlank()) return err("Gib eine Person oder ein Stichwort an")
            if (!NotificationWatcher.isEnabled(act)) {
                store.addCallTrigger(from, kw)
                ok("Regel gespeichert – aber 'Nachrichten lesen' ist noch aus (🦾 Alles einrichten), sonst merke ich nichts")
            } else {
                val t = store.addCallTrigger(from, kw)
                ok("Regel #${t.id}: Ich rufe an bei Nachrichten" + (if (from.isNotBlank()) " von $from" else "") +
                    (if (kw.isNotBlank()) " mit '$kw'" else ""))
            }
        }
        "list_call_triggers" -> JSONObject().put("triggers", JSONArray(store.callTriggers().map {
            JSONObject().put("id", it.id).put("from", it.from).put("keyword", it.keyword)
        })).put("calls_on_urgent_words", store.callOnUrgent)
        "remove_call_trigger" -> if (store.removeCallTrigger(a.getInt("id"))) ok("gelöscht") else err("nicht gefunden")
        "list_reminders" -> JSONObject().put("reminders", JSONArray(store.reminders()
            .filter { it.time > System.currentTimeMillis() }.sortedBy { it.time }
            .map { JSONObject().put("id", it.id).put("text", it.text).put("time", fmt.format(Date(it.time))) }))
        "cancel_reminder" -> {
            val id = a.getInt("id")
            ReminderReceiver.cancel(act, id); store.removeReminder(id); ok("Erinnerung gelöscht")
        }
        "internet_search" -> Web.internetSearch(store, a.getString("query"))
        "get_weather" -> Web.weather(act, a.optString("place").ifBlank { null })
        "get_location" -> location()
        "read_notifications" -> if (!NotificationWatcher.isEnabled(act))
            err("Nachrichten-Zugriff ist aus. Der Nutzer muss ihn in JARVIS ⚙️ → Superkräfte einschalten.")
            else NotificationWatcher.list(a.optString("app").ifBlank { null })
        "reply_message" -> NotificationWatcher.reply(act, a.getString("to"), a.getString("text"))
        "look_at_screen" -> {
            Jarvis.hideOverlayForCapture()
            val bmp = ScreenAgent.captureScreen()
            Web.describeImage(store, CameraEye.encode(bmp), a.getString("question"), "dem Bildschirm des Handys")
        }
        "look_through_camera" -> {
            val front = a.optString("camera").lowercase().startsWith("f")
            val bmp = CameraEye.capture(act, front)
            Web.describeImage(store, CameraEye.encode(bmp), a.getString("question"),
                if (front) "der Selfie-Kamera" else "der Rückkamera des Handys")
        }
        "guide_me" -> Guide.run(store, a.getString("goal"))
        "show_images" -> ImageSearch.show(act, a.optString("query").ifBlank { null }, a.optString("urls").ifBlank { null },
            a.optInt("count", 3), a.optString("caption").ifBlank { null })
        "highlight_on_screen" -> highlight(a)
        "say" -> { Jarvis.sayNow(a.getString("text")); ok("gesagt") }
        "wait_for_screen_change" -> ScreenAgent.waitForChange(a.optInt("timeout_seconds", 45))
        "call_me" -> {
            val reason = a.getString("reason")
            val dt = a.optString("datetime")
            if (dt.isBlank()) {
                JarvisCall.ring(act, reason)
                ok("Anruf startet in ein paar Sekunden")
            } else {
                val date = parseDate(dt) ?: return err("Datum unklar, bitte $DT")
                if (date.time < System.currentTimeMillis()) return err("Dieser Zeitpunkt liegt in der Vergangenheit")
                JarvisCall.schedule(act, date.time, reason)
                ok("Anruf geplant für ${fmt.format(date)}")
            }
        }
        "clear_highlights" -> { Jarvis.clearHighlights(); ok("Markierungen entfernt") }
        "read_screen" -> ScreenAgent.readScreen()
        "tap" -> ScreenAgent.tap(if (a.has("element")) a.getInt("element") else null, a.optString("text").ifBlank { null })
        "long_press" -> ScreenAgent.longPress(a.getInt("element"))
        "type_text" -> ScreenAgent.type(if (a.has("element")) a.getInt("element") else null, a.getString("text"))
        "scroll" -> ScreenAgent.scroll(if (a.has("element")) a.getInt("element") else null, a.optString("direction") != "up")
        "press_button" -> ScreenAgent.press(a.getString("button"))
        "wait" -> { Thread.sleep(a.optInt("seconds", 2).coerceIn(1, 5) * 1000L); ok("gewartet") }
        "set_location_reminder" -> locationReminder(a.getString("text"), a.getString("place"))
        "list_location_reminders" -> JSONObject().put("reminders", JSONArray(store.placeReminders().map {
            JSONObject().put("id", it.id).put("text", it.text).put("place", it.place)
        }))
        "cancel_location_reminder" -> {
            val id = a.getString("id")
            PlaceReminders.unregister(act, id); store.removePlaceReminder(id); ok("gelöscht")
        }
        "set_briefing" -> {
            store.briefingEnabled = a.getBoolean("enabled")
            a.optString("time").takeIf { it.matches(Regex("\\d{1,2}:\\d{2}")) }?.split(":")?.let {
                store.briefingHour = it[0].toInt(); store.briefingMinute = it[1].toInt()
            }
            if (a.has("speak")) store.briefingSpeak = a.getBoolean("speak")
            Briefing.schedule(act)
            ok(if (store.briefingEnabled) "Briefing täglich um %02d:%02d".format(store.briefingHour, store.briefingMinute) else "Briefing aus")
        }
        "set_proactive" -> {
            store.proactiveEnabled = a.getBoolean("enabled")
            if (a.has("evening_hour")) { store.eveningHour = a.getInt("evening_hour"); store.eveningMinute = 0 }
            Proactive.schedule(act)
            ok(if (store.proactiveEnabled) "Mitdenken an, Abend-Check um %02d:00".format(store.eveningHour) else "Mitdenken aus")
        }
        "announce_messages" -> {
            store.announceMessages = a.getBoolean("enabled")
            if (store.announceMessages && !NotificationWatcher.isEnabled(act))
                ok("eingeschaltet, aber Nachrichten-Zugriff fehlt noch (⚙️ → Superkräfte)")
            else ok(if (store.announceMessages) "Ansagen an" else "Ansagen aus")
        }
        "set_alarm" -> start(Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, a.getInt("hour"))
            .putExtra(AlarmClock.EXTRA_MINUTES, a.optInt("minute", 0))
            .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label").ifBlank { "JARVIS" })
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true), "Wecker gestellt")
        "set_timer" -> start(Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, a.getInt("seconds"))
            .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label").ifBlank { "JARVIS" })
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true), "Timer läuft")
        "open_app" -> openApp(a.getString("name"))
        "web_search" -> start(Intent(Intent.ACTION_VIEW,
            Uri.parse("https://www.google.com/search?q=" + Uri.encode(a.getString("query")))), "Suche geöffnet")
        "open_url" -> {
            var u = a.getString("url").trim()
            if (!u.startsWith("http")) u = "https://$u"
            start(Intent(Intent.ACTION_VIEW, Uri.parse(u)), "Seite geöffnet")
        }
        "navigate" -> {
            val dest = a.getString("destination")
            val mode = when (a.optString("mode")) { "walking" -> "w"; "bicycling" -> "b"; else -> "d" }
            val r = start(Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=${Uri.encode(dest)}&mode=$mode")), "Navigation gestartet")
            if (r.optBoolean("ok")) r
            else start(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(dest))), "Karte geöffnet")
        }
        "find_contact" -> {
            if (!has(Manifest.permission.READ_CONTACTS)) err("Kontakte-Berechtigung fehlt")
            else JSONObject().put("contacts", JSONArray(contacts(a.getString("name")).map {
                JSONObject().put("name", it.first).put("number", it.second)
            }))
        }
        "call" -> {
            val num = resolveNumber(a.getString("target"))
            if (num == null) err("Keine Nummer gefunden (Kontakte-Berechtigung?)")
            else if (has(Manifest.permission.CALL_PHONE))
                start(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(num))), "Anruf an $num gestartet")
            else start(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(num))), "Wähltastatur mit $num geöffnet (Anruf-Berechtigung fehlt), Nutzer muss auf Anrufen drücken")
        }
        "update_plan" -> {
            val steps = a.getString("steps").lines().map { it.trim().trimStart('-', '*', '•', ' ').trim() }.filter { it.isNotBlank() }
            val done = a.optInt("done", 0).coerceIn(0, steps.size)
            val title = a.optString("title").ifBlank { "Plan" }
            val text = buildString {
                append("📋 ").append(title).append("  (").append(done).append('/').append(steps.size).append(")\n")
                steps.forEachIndexed { i, st ->
                    append(when { i < done -> "✅ "; i == done -> "⏳ "; else -> "⬜ " }).append(st).append('\n')
                }
            }.trimEnd()
            Jarvis.upsertMsg(ChatMsg(false, text, id = "plan-${Jarvis.runId}"))
            if (done < steps.size) Jarvis.progress("Schritt ${done + 1}/${steps.size}: ${steps[done]}")
            ok(if (done >= steps.size) "Plan komplett erledigt" else "Plan aktualisiert, jetzt Schritt ${done + 1}: ${steps[done]}")
        }
        "build_app" -> {
            var html = a.getString("html").trim()
            if (html.startsWith("```")) html = html.removePrefix("```html").removePrefix("```").removeSuffix("```").trim()
            if (!html.contains("<", true) || html.length < 50) err("Das ist kein vollständiger HTML-Code")
            else {
                val f = Creations.save(act, a.getString("name"), html, "html")
                Jarvis.addMsg(ChatMsg(false, "🎮 ${f.nameWithoutExtension.replace('_', ' ')} ist fertig!", file = f.absolutePath))
                ok("Gebaut und gespeichert als ${f.name} (${html.length} Zeichen). Karte im Chat, Nutzer kann sie öffnen. Mit open_file direkt öffnen.")
            }
        }
        "create_file" -> {
            val ext = when (a.optString("format").lowercase()) { "md" -> "md"; "csv" -> "csv"; else -> "txt" }
            val f = Creations.save(act, a.getString("name"), a.getString("content"), ext)
            Jarvis.addMsg(ChatMsg(false, "${Creations.icon(f.path)} ${f.name} erstellt", file = f.absolutePath))
            ok("Datei ${f.name} erstellt und im Chat gezeigt")
        }
        "read_file" -> {
            val f = Creations.find(act, a.getString("name"))
            if (f == null) err("Nicht gefunden. Vorhanden: " + Creations.list(act).joinToString { it.name })
            else JSONObject().put("name", f.name).put("content", f.readText().take(60000))
        }
        "list_files" -> JSONObject().put("files", JSONArray(Creations.list(act).map {
            JSONObject().put("name", it.name).put("kb", it.length() / 1024).put("changed", fmt.format(Date(it.lastModified())))
        }))
        "open_file" -> {
            val f = Creations.find(act, a.getString("name"))
            if (f == null) err("Nicht gefunden") else start(Creations.openIntent(act, f.absolutePath), "${f.name} geöffnet")
        }
        "share_file" -> {
            val f = Creations.find(act, a.getString("name"))
            if (f == null) err("Nicht gefunden")
            else runCatching { Creations.share(act, f.absolutePath); ok("Teilen-Menü für ${f.name} offen") }.getOrElse { err("Teilen ging nicht: ${it.message}") }
        }
        "save_to_downloads" -> {
            val f = Creations.find(act, a.getString("name"))
            if (f == null) err("Nicht gefunden")
            else if (Creations.exportToDownloads(act, f.absolutePath)) ok("In Download/JARVIS gespeichert")
            else err("Speichern ging nicht (braucht Android 10+)")
        }
        "send_message" -> sendMessage(a.getString("to"), a.getString("text"), a.optString("app").ifBlank { "whatsapp" })
        "send_sms" -> {
            val num = resolveNumber(a.getString("target"))
            if (num == null) err("Keine Nummer gefunden (Kontakte-Berechtigung?)")
            else start(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(num)))
                .putExtra("sms_body", a.getString("text")), "SMS an $num vorbereitet, Nutzer muss senden")
        }
        "share_text" -> {
            val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, a.getString("text"))
            when (a.optString("app").lowercase()) {
                "whatsapp" -> start(i.setPackage("com.whatsapp"), "WhatsApp geöffnet")
                "telegram" -> start(i.setPackage("org.telegram.messenger"), "Telegram geöffnet")
                else -> start(Intent.createChooser(i, "Teilen mit …"), "Teilen-Menü geöffnet")
            }
        }
        "flashlight" -> torch(a.getBoolean("on"))
        "set_volume" -> {
            val am = act.getSystemService(AudioManager::class.java)
            val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            val pct = a.getInt("percent").coerceIn(0, 100)
            am.setStreamVolume(AudioManager.STREAM_MUSIC, (max * pct / 100.0).roundToInt(), AudioManager.FLAG_SHOW_UI)
            ok("Lautstärke auf $pct%")
        }
        "battery_status" -> {
            val bm = act.getSystemService(BatteryManager::class.java)
            JSONObject().put("percent", bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY))
                .put("charging", bm.isCharging)
        }
        "get_calendar_events" -> calendarEvents(a.optInt("days", 1))
        "add_calendar_event" -> {
            val startDate = parseDate(a.getString("start")) ?: return err("Datum unklar, bitte $DT")
            val dur = a.optInt("duration_minutes", 60)
            start(Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI)
                .putExtra(CalendarContract.Events.TITLE, a.getString("title"))
                .putExtra(CalendarContract.Events.EVENT_LOCATION, a.optString("location"))
                .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, startDate.time)
                .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, startDate.time + dur * 60_000L),
                "Kalender zum Bestätigen geöffnet")
        }
        "play_music" -> start(Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
            .putExtra(SearchManager.QUERY, a.getString("query"))
            .putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*"), "Musik gestartet")
        "open_settings" -> start(Intent(when (a.optString("page").lowercase()) {
            "wifi" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "display" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound" -> Settings.ACTION_SOUND_SETTINGS
            "battery" -> Intent.ACTION_POWER_USAGE_SUMMARY
            "apps" -> Settings.ACTION_APPLICATION_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }), "Einstellungen geöffnet")
        else -> err("Unbekanntes Werkzeug: $name")
    } }

    private fun highlight(a: JSONObject): JSONObject {
        if (!Settings.canDrawOverlays(act)) {
            return err("Zum Markieren braucht JARVIS 'Blase über anderen Apps' (🦾 Alles einrichten).")
        }
        val seconds = a.optInt("seconds", 8)
        val marks = mutableListOf<Highlighter.Mark>()
        if (a.has("element")) {
            val r = ScreenAgent.boundsOf(a.getInt("element")) ?: return err("Element nicht gefunden – erst read_screen aufrufen")
            marks.add(Highlighter.Mark(android.graphics.RectF(r), a.optString("label")))
        } else {
            val what = a.optString("what").ifBlank { return err("Sag mir, was ich markieren soll") }
            Jarvis.hideOverlayForCapture()
            val bmp = ScreenAgent.captureScreen()
            val w = bmp.width.toFloat()
            val h = bmp.height.toFloat()
            Web.findBoxes(store, CameraEye.encode(bmp), what).forEach { (b, label) ->
                marks.add(Highlighter.Mark(android.graphics.RectF(
                    (b[1] / 1000.0 * w).toFloat(), (b[0] / 1000.0 * h).toFloat(),
                    (b[3] / 1000.0 * w).toFloat(), (b[2] / 1000.0 * h).toFloat(),
                ), a.optString("label").ifBlank { label }))
            }
            if (marks.isEmpty()) return ok("Nichts gefunden: '$what' ist gerade nicht auf dem Bildschirm zu sehen")
        }
        return if (Jarvis.highlight(marks, seconds)) ok("${marks.size} Stelle(n) markiert")
        else err("Markieren hat nicht geklappt")
    }

    private fun location(): JSONObject {
        val loc = Web.lastLocation(act) ?: return err("Standort unbekannt – Standort-Berechtigung in ⚙️ erlauben")
        @Suppress("DEPRECATION")
        val addr = runCatching {
            android.location.Geocoder(act, Locale.GERMAN).getFromLocation(loc.latitude, loc.longitude, 1)?.firstOrNull()
        }.getOrNull()
        return JSONObject().put("lat", loc.latitude).put("lon", loc.longitude)
            .put("address", addr?.getAddressLine(0) ?: "unbekannt")
            .put("age_minutes", (System.currentTimeMillis() - loc.time) / 60_000)
    }

    private fun locationReminder(text: String, place: String): JSONObject {
        if (!PlaceReminders.hasPermission(act)) {
            return err("Dafür braucht JARVIS Standort 'immer erlauben'. Der Nutzer kann das in ⚙️ → Superkräfte einschalten.")
        }
        val (lat, lon, label) = PlaceReminders.resolve(act, place) ?: return err("Ort '$place' nicht gefunden")
        val r = Store.PlaceReminder("p" + System.currentTimeMillis(), text, label, lat, lon)
        store.addPlaceReminder(r)
        PlaceReminders.register(act, r)
        return ok("Orts-Erinnerung gesetzt für: $label")
    }

    private fun setReminder(text: String, dt: String, call: Boolean): JSONObject {
        val date = parseDate(dt) ?: return err("Datum unklar, bitte $DT")
        if (date.time < System.currentTimeMillis()) return err("Dieser Zeitpunkt liegt in der Vergangenheit")
        val r = Store.Reminder(store.nextReminderId(), text, date.time, call)
        store.addReminder(r)
        ReminderReceiver.schedule(act, r)
        return ok("Erinnerung für ${fmt.format(date)} geplant" + if (call) " – mit Anruf 📞" else "")
    }

    private fun openApp(name: String): JSONObject {
        val pm = act.packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val labeled = apps.map { it to it.loadLabel(pm).toString() }
        val q = name.trim().lowercase()
        val hit = labeled.firstOrNull { it.second.lowercase() == q }
            ?: labeled.firstOrNull { it.second.lowercase().contains(q) }
            ?: labeled.firstOrNull { it.second.length > 2 && q.contains(it.second.lowercase()) }
            ?: return err("App '$name' nicht gefunden")
                .put("installed_apps", JSONArray(labeled.map { it.second }.sorted().take(80)))
        val launch = pm.getLaunchIntentForPackage(hit.first.activityInfo.packageName)
            ?: return err("${hit.second} lässt sich nicht starten")
        return start(launch, "${hit.second} geöffnet")
    }

    private fun contacts(name: String): List<Pair<String, String>> {
        val out = mutableListOf<Pair<String, String>>()
        act.contentResolver.query(Phone.CONTENT_URI, arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER),
            "${Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$name%"), null)?.use { c ->
            while (c.moveToNext() && out.size < 10) out.add((c.getString(0) ?: "") to (c.getString(1) ?: ""))
        }
        return out.distinctBy { it.second.replace(" ", "") }
    }

    /** Nummer ins internationale Format ohne + (für WhatsApp), Standard-Land Schweiz. */
    private fun intlNumber(raw: String): String {
        var n = raw.filter { it.isDigit() || it == '+' }
        n = when {
            n.startsWith("+") -> n.drop(1)
            n.startsWith("00") -> n.drop(2)
            n.startsWith("0") -> "41" + n.drop(1)
            else -> n
        }
        return n
    }

    @Suppress("DEPRECATION")
    private fun sendMessage(to: String, text: String, app: String): JSONObject {
        val num = resolveNumber(to) ?: return err("Keine Nummer für '$to' gefunden (Kontakte-Berechtigung?)")
        if (app.lowercase().startsWith("sms")) {
            if (!has(Manifest.permission.SEND_SMS)) {
                return err("SMS-Senden ist nicht erlaubt (🦾 Alles einrichten). Alternativ send_sms zum Vorbereiten.")
            }
            val sms = if (Build.VERSION.SDK_INT >= 31) act.getSystemService(android.telephony.SmsManager::class.java)
            else android.telephony.SmsManager.getDefault()
            sms.sendMultipartTextMessage(num, null, sms.divideMessage(text), null, null)
            return ok("SMS an $to ($num) gesendet ✅")
        }
        // WhatsApp: Chat mit fertigem Text öffnen, dann selbst auf Senden tippen
        val pkg = listOf("com.whatsapp", "com.whatsapp.w4b").firstOrNull {
            runCatching { act.packageManager.getPackageInfo(it, 0) }.isSuccess
        } ?: return err("WhatsApp ist nicht installiert")
        val open = start(Intent(Intent.ACTION_VIEW,
            Uri.parse("https://api.whatsapp.com/send?phone=${intlNumber(num)}&text=${Uri.encode(text)}")).setPackage(pkg),
            "WhatsApp-Chat geöffnet")
        if (!open.optBoolean("ok")) return open
        if (ScreenAgent.instance == null) {
            return ok("Chat mit $to ist offen und der Text steht drin – Nutzer muss nur noch auf Senden tippen " +
                "('Apps bedienen' ist aus, darum kann ich nicht selbst tippen)")
        }
        val sent = ScreenAgent.clickWhenVisible(
            listOf("$pkg:id/send", "$pkg:id/send_btn"), listOf("Senden", "Send"), 8_000,
        )
        if (!sent) return err("Chat ist offen, aber ich finde den Senden-Knopf nicht – schau mit look_at_screen nach")
        Thread.sleep(400)
        ScreenAgent.press("previous_app")
        return ok("WhatsApp an $to gesendet ✅")
    }

    private fun resolveNumber(target: String): String? {
        if (target.none { it.isLetter() }) return target.trim()
        if (!has(Manifest.permission.READ_CONTACTS)) return null
        return contacts(target.trim()).firstOrNull()?.second
    }

    private fun torch(on: Boolean): JSONObject {
        val cm = act.getSystemService(CameraManager::class.java)
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return err("Keine Taschenlampe gefunden")
        cm.setTorchMode(id, on)
        return ok(if (on) "Taschenlampe an" else "Taschenlampe aus")
    }

    private fun calendarEvents(days: Int): JSONObject {
        if (!has(Manifest.permission.READ_CALENDAR)) return err("Kalender-Berechtigung fehlt")
        val begin = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0)
        }.timeInMillis
        val end = begin + days.coerceIn(1, 31) * 86_400_000L
        val proj = arrayOf(
            CalendarContract.Instances.TITLE, CalendarContract.Instances.BEGIN, CalendarContract.Instances.END,
            CalendarContract.Instances.EVENT_LOCATION, CalendarContract.Instances.ALL_DAY,
        )
        val list = mutableListOf<Pair<Long, JSONObject>>()
        CalendarContract.Instances.query(act.contentResolver, proj, begin, end)?.use { c ->
            while (c.moveToNext() && list.size < 60) {
                val s = c.getLong(1)
                list.add(s to JSONObject()
                    .put("title", c.getString(0) ?: "")
                    .put("start", fmt.format(Date(s)))
                    .put("end", fmt.format(Date(c.getLong(2))))
                    .put("location", c.getString(3) ?: "")
                    .put("all_day", c.getInt(4) == 1))
            }
        }
        return JSONObject().put("events", JSONArray(list.sortedBy { it.first }.map { it.second }))
    }
}
