package ch.jarvis.app

import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * Spricht mit Google Gemini – robust:
 *  - bei Überlastung (503) automatisch kurz warten und nochmal versuchen
 *  - klappt's dann immer noch nicht (oder Gratis-Limit erreicht), auf ein anderes Modell ausweichen
 */
object Gemini {

    /** Ausweich-Modelle, falls das eingestellte gerade überlastet ist (jedes hat sein eigenes Gratis-Limit). */
    private val FALLBACKS = listOf(
        "gemini-flash-latest", "gemini-flash-lite-latest", "gemini-2.5-flash", "gemini-2.5-flash-lite",
    )

    /** Modelle, die gerade ihr Limit erreicht haben oder überlastet sind, eine Weile überspringen (spart Wartezeit). */
    private val coolDown = java.util.concurrent.ConcurrentHashMap<String, Long>()

    private fun available(model: String) = (coolDown[model] ?: 0L) < System.currentTimeMillis()

    internal class HttpFail(val code: Int, msg: String) : IOException(msg)

    fun generate(store: Store, body: JSONObject): JSONObject {
        val all = (listOf(store.model) + FALLBACKS).distinct()
        val models = all.filter { available(it) }.ifEmpty { all }
        var last: HttpFail? = null
        for (model in models) {
            for (attempt in 1..2) {
                try {
                    return JSONObject(post(store, model, body))
                } catch (e: HttpFail) {
                    last = e
                    when (e.code) {
                        401, 403 -> throw IOException("API-Key ungültig 🔑 (${e.message})")
                        500, 502, 503, 504 -> {
                            if (attempt == 1) {
                                Thread.sleep(1500) // kurz durchatmen, dann nochmal
                            } else {
                                coolDown[model] = System.currentTimeMillis() + 2 * 60_000L
                                break // immer noch überlastet → nächstes Modell
                            }
                        }
                        429 -> {
                            coolDown[model] = System.currentTimeMillis() + 10 * 60_000L
                            break
                        }
                        else -> break // 429 (Limit), 404 (Modell gibt's nicht), 400 → nächstes Modell
                    }
                }
            }
        }
        val e = last ?: throw IOException("Keine Antwort von Google")
        throw IOException(when (e.code) {
            429 -> "Gratis-Limit für heute erreicht ⏳ Versuch's später nochmal."
            500, 502, 503, 504 -> "Google ist gerade überlastet 😵 Versuch's in ein paar Minuten nochmal."
            400, 404 -> "API-Problem, stimmt das Modell '${store.model}'? (${e.message})"
            else -> "HTTP ${e.code}: ${e.message}"
        })
    }

    internal fun post(store: Store, model: String, body: JSONObject): String {
        val con = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .openConnection() as HttpURLConnection
        con.requestMethod = "POST"
        con.connectTimeout = 20_000
        con.readTimeout = 90_000
        con.doOutput = true
        con.setRequestProperty("Content-Type", "application/json; charset=utf-8")
        con.setRequestProperty("x-goog-api-key", store.apiKey)
        con.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = con.responseCode
        val txt = (if (code in 200..299) con.inputStream else con.errorStream)
            ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
        if (code !in 200..299) {
            val msg = runCatching { JSONObject(txt).getJSONObject("error").getString("message") }
                .getOrDefault(txt.take(200))
            throw HttpFail(code, msg)
        }
        return txt
    }
}
