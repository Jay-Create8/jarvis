package ch.jarvis.app

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

enum class Phase { IDLE, LISTENING, THINKING, SPEAKING }

/**
 * Eine Chat-Nachricht. [images] = Pfade zu Bildern (angehängt vom Nutzer oder von JARVIS geschickt),
 * [file] = von JARVIS gebaute Datei/App, [id] = zum Aktualisieren (z.B. Fortschritts-Plan).
 */
data class ChatMsg(
    val user: Boolean,
    val text: String,
    val images: List<String> = emptyList(),
    val file: String? = null,
    val id: String? = null,
)

/**
 * Das zentrale JARVIS-"Bewusstsein". Lebt unabhängig von der Oberfläche,
 * damit er auch per "Jarvis!" im Hintergrund arbeiten kann.
 */
object Jarvis {

    /** Damit der Wake-Word-Dienst das Mikrofon freigibt, solange JARVIS selbst zuhört. */
    interface WakeHooks {
        fun pauseWake()
        fun resumeWake()
    }

    const val CH_REMINDER = "jarvis"
    const val CH_WAKE = "jarvis_wake"
    const val CH_REPLY = "jarvis_reply"
    const val CH_CALL = "jarvis_call"
    private const val REPLY_NOTIFICATION_ID = 7
    const val TAP_NOTIFICATION_ID = 8

    lateinit var app: Context
        private set
    lateinit var store: Store
        private set
    private lateinit var tools: Tools
    private lateinit var brain: JarvisBrain
    private lateinit var voice: Voice
    private lateinit var overlay: Overlay
    private lateinit var highlighter: Highlighter

    private val scope = MainScope()
    private val main = Handler(Looper.getMainLooper())
    private val hideOverlay = Runnable { overlay.hide() }

    val messages = mutableStateListOf<ChatMsg>()
    var phase by mutableStateOf(Phase.IDLE)
        private set
    var status by mutableStateOf("Bereit.")
        private set
    var level by mutableFloatStateOf(0f)
        private set
    var convoMode by mutableStateOf(false)
        private set
    var muted by mutableStateOf(false)
        private set
    var wakeActive by mutableStateOf(false)
    var wakeInfo by mutableStateOf("")
    /** Läuft gerade ein JARVIS-Anruf? Dann hört er nach jeder Antwort automatisch weiter zu. */
    var callActive by mutableStateOf(false)
        private set

    /** Soll die laufende Aufgabe abgebrochen werden? (Stopp-Knopf) */
    @Volatile var cancelRequested = false
        private set
    /** Zählt jede neue Aufgabe hoch – damit jede ihren eigenen Fortschritts-Plan im Chat bekommt. */
    @Volatile var runId = 0
        private set

    /** Ist die App gerade auf dem Bildschirm? */
    var uiVisible = false
    var wakeHooks: WakeHooks? = null
    /** Wird von der Activity gesetzt, um nach der Mikrofon-Berechtigung zu fragen. */
    var askMicPermission: (() -> Unit)? = null

    fun init(ctx: Context) {
        if (::store.isInitialized) return
        app = ctx.applicationContext
        store = Store(app)
        tools = Tools(app, store)
        brain = JarvisBrain(store, tools)
        overlay = Overlay(app)
        highlighter = Highlighter(app)
        convoMode = store.conversationMode
        muted = store.muted
        loadChat()
        voice = Voice(
            app,
            store,
            onResult = { text -> handleInput(text) },
            onLevel = { level = it },
            onListenEnd = { msg ->
                if (phase == Phase.LISTENING) {
                    showStatus(msg ?: "Bereit.")
                    goIdle()
                }
            },
        )
        val nm = app.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_REMINDER, "Erinnerungen", NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(NotificationChannel(CH_WAKE, "\"Hey JARVIS\" Dienst", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_REPLY, "Antworten", NotificationManager.IMPORTANCE_DEFAULT))
        nm.createNotificationChannel(NotificationChannel(CH_CALL, "JARVIS-Anrufe", NotificationManager.IMPORTANCE_HIGH).apply {
            setSound(null, null) // klingeln macht der Anruf-Bildschirm selbst
        })
    }

    // ---------- Zustände ----------

    private fun showStatus(s: String) {
        status = s
        if (!uiVisible && phase != Phase.IDLE) {
            main.removeCallbacks(hideOverlay)
            overlay.show(s)
        }
    }

    private fun goIdle() {
        phase = Phase.IDLE
        level = 0f
        main.removeCallbacks(hideOverlay)
        main.postDelayed(hideOverlay, if (uiVisible) 0 else 6000)
        wakeHooks?.resumeWake()
    }

    // ---------- 💬 Chat-Verlauf ----------

    private fun loadChat() {
        runCatching {
            val arr = JSONArray(store.chatHistory)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val imgs = o.optJSONArray("i")?.let { a -> (0 until a.length()).map { a.getString(it) } }.orEmpty()
                    .filter { File(it).exists() }
                val file = o.optString("f").ifBlank { null }?.takeIf { File(it).exists() }
                messages.add(ChatMsg(o.optBoolean("u"), o.optString("t"), imgs, file))
            }
        }
    }

    private fun saveChat() {
        val arr = JSONArray()
        messages.takeLast(80).forEach { m ->
            arr.put(JSONObject().put("u", m.user).put("t", m.text).put("i", JSONArray(m.images)).put("f", m.file ?: ""))
        }
        store.chatHistory = arr.toString()
    }

    /** Nachricht in den Chat setzen (von jedem Thread aus) und merken. */
    fun addMsg(msg: ChatMsg) {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            main.post { addMsg(msg) }
            return
        }
        messages.add(msg)
        saveChat()
    }

    /** Nachricht mit dieser [id] ersetzen (oder neu anhängen) – für den Fortschritts-Plan. */
    fun upsertMsg(msg: ChatMsg) {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            main.post { upsertMsg(msg) }
            return
        }
        val i = messages.indexOfFirst { it.id != null && it.id == msg.id }
        if (i >= 0) messages[i] = msg else messages.add(msg)
        saveChat()
    }

    /** Fortschritt in der Statuszeile anzeigen (von jedem Thread aus). */
    fun progress(text: String) {
        main.post { if (phase == Phase.THINKING) showStatus(text) }
    }

    /** Laufende Aufgabe stoppen. */
    fun cancel() {
        if (phase != Phase.THINKING) return
        cancelRequested = true
        Guide.cancelled = true
        showStatus("Breche ab … ✋")
    }

    /** JARVIS schickt Bilder in den Chat (z.B. aus der Bildersuche). */
    fun postImages(caption: String, paths: List<String>) {
        if (paths.isNotEmpty()) addMsg(ChatMsg(false, caption, paths))
    }

    // ---------- Aktionen ----------

    /** Für Hintergrund-Aufgaben (z.B. Briefing): fragt das Gehirn, ohne die Oberfläche umzuschalten. */
    suspend fun askQuietly(prompt: String): String {
        val answer = brain.ask(prompt) {}
        addMsg(ChatMsg(false, answer))
        return answer
    }

    /**
     * Mitdenken im Hintergrund: JARVIS prüft selbst und ruft nur an, wenn's wichtig ist.
     * Die Antwort "OK" (= nichts los) landet nicht im Chat.
     */
    suspend fun thinkInBackground(prompt: String) {
        val answer = brain.ask(prompt) {}
        val quiet = answer.trim().trimEnd('.', '!').equals("OK", ignoreCase = true)
        if (!quiet) addMsg(ChatMsg(false, "🧠 $answer"))
    }

    /** Sagt etwas laut an (z.B. neue Nachricht), aber nur wenn JARVIS gerade nichts anderes macht. */
    fun announce(text: String) {
        if (muted || phase != Phase.IDLE) return
        wakeHooks?.pauseWake()
        phase = Phase.SPEAKING
        voice.speak(text) { goIdle() }
    }

    /**
     * Nachricht an JARVIS. [images] = Pfade zu angehängten Bildern.
     * @return false, wenn JARVIS gerade beschäftigt ist (dann bleibt die Eingabe stehen)
     */
    fun handleInput(text: String, hidden: Boolean = false, images: List<String> = emptyList()): Boolean {
        val shown = text.trim()
        val t = shown.ifEmpty {
            when {
                images.size > 1 -> "Schau dir die Bilder an und hilf mir damit."
                images.isNotEmpty() -> "Was siehst du auf dem Bild? Hilf mir damit."
                else -> ""
            }
        }
        if (t.isEmpty() || phase == Phase.THINKING) return false
        if (!hidden) addMsg(ChatMsg(true, shown, images))
        cancelRequested = false
        runId++
        voice.stopSpeaking()
        wakeHooks?.pauseWake()
        phase = Phase.THINKING
        showStatus("Denke nach …")
        scope.launch {
            val b64 = withContext(Dispatchers.IO) { images.mapNotNull { ChatImages.base64(it) } }
            val answer = brain.ask(t, b64) { tool -> showStatus("⚙️ " + Tools.label(tool)) }
            addMsg(ChatMsg(false, answer))
            if (!uiVisible) {
                overlay.show(answer)
                postReplyNotification(answer)
            }
            status = "Bereit."
            if (!muted) {
                phase = Phase.SPEAKING
                voice.speak(answer) {
                    if (convoMode || callActive) startListening() else goIdle()
                }
            } else {
                if (convoMode || callActive) startListening() else goIdle()
            }
        }
        return true
    }

    /**
     * Spricht sofort etwas aus, auch mitten in einer Aufgabe (z.B. Anleitungs-Schritte).
     * Blockiert bis fertig gesprochen – nur aus Hintergrund-Threads aufrufen.
     */
    fun sayNow(text: String) {
        main.post { if (!uiVisible) overlay.show(text) }
        if (muted) return
        val latch = java.util.concurrent.CountDownLatch(1)
        main.post { voice.speak(text) { latch.countDown() } }
        latch.await(30, java.util.concurrent.TimeUnit.SECONDS)
    }

    // ---------- 🗣️ Stimme ----------

    fun phoneVoices(): List<Pair<String, String>> = voice.germanVoices()

    /** Neue Stimmen-Einstellungen sofort übernehmen und kurz Probe sprechen. */
    fun previewVoice() {
        voice.applyPhoneVoice()
        voice.stopSpeaking()
        if (phase != Phase.IDLE && phase != Phase.SPEAKING) return
        wakeHooks?.pauseWake()
        phase = Phase.SPEAKING
        voice.speak("Guten Abend. Ich bin JARVIS, dein persönlicher Assistent. Alle Systeme laufen.") { goIdle() }
    }

    // ---------- 📞 JARVIS-Anruf ----------

    fun startCall(reason: String) {
        voice.stopSpeaking()
        voice.stopListening()
        if (phase != Phase.IDLE) goIdle()
        callActive = true
        handleInput(
            "[Du rufst den Nutzer gerade an und er hat abgenommen. Grund des Anrufs: $reason] " +
                "Begrüsse ihn kurz wie am Telefon, sag warum du anrufst und frag, ob du helfen kannst. Kurz halten.",
            hidden = true,
        )
    }

    fun endCall() {
        callActive = false
        voice.stopSpeaking()
        voice.stopListening()
        status = "Bereit."
        goIdle()
    }

    /** @return false, wenn die Mikrofon-Berechtigung fehlt */
    fun startListening(): Boolean {
        if (app.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            showStatus("Bitte Mikrofon erlauben 🎙️")
            askMicPermission?.invoke()
            if (phase != Phase.IDLE) goIdle()
            return false
        }
        voice.stopSpeaking()
        wakeHooks?.pauseWake()
        phase = Phase.LISTENING
        showStatus("Ich höre … 🎙️")
        voice.listen()
        return true
    }

    fun toggleListening() {
        when (phase) {
            Phase.LISTENING -> { voice.stopListening(); status = "Bereit."; goIdle() }
            Phase.THINKING -> cancel()
            else -> startListening()
        }
    }

    fun toggleMute() {
        muted = !muted
        store.muted = muted
        if (muted && phase == Phase.SPEAKING) {
            voice.stopSpeaking()
            goIdle()
        }
    }

    fun setConvo(on: Boolean) {
        convoMode = on
        store.conversationMode = on
    }

    fun saveSettings(key: String, model: String, name: String, sensitivity: Float) {
        store.apiKey = key
        store.model = model
        store.userName = name
        store.wakeSensitivity = sensitivity
    }

    fun clearMemory() {
        store.clearFacts()
        addMsg(ChatMsg(false, "Gedächtnis gelöscht 🧹"))
    }

    fun newChat() {
        voice.stopSpeaking()
        voice.stopListening()
        brain.reset()
        messages.clear()
        saveChat()
        ChatImages.clearAll(app)
        status = "Bereit."
        goIdle()
    }

    /** Blase kurz ausblenden, damit sie beim Bildschirm-Ansehen nicht im Bild ist. */
    fun hideOverlayForCapture() {
        val latch = java.util.concurrent.CountDownLatch(1)
        main.post { overlay.hide(); highlighter.hide(); latch.countDown() }
        latch.await(1, java.util.concurrent.TimeUnit.SECONDS)
        Thread.sleep(150)
    }

    /** Zeigt leuchtende Rahmen auf dem Bildschirm (aus einem Hintergrund-Thread aufrufbar). */
    fun highlight(marks: List<Highlighter.Mark>, seconds: Int): Boolean {
        val latch = java.util.concurrent.CountDownLatch(1)
        var ok = false
        main.post { ok = highlighter.show(marks, seconds); latch.countDown() }
        latch.await(2, java.util.concurrent.TimeUnit.SECONDS)
        return ok
    }

    fun clearHighlights() {
        main.post { highlighter.hide() }
    }

    private var visibleScreens = 0

    /** Zählt sichtbare JARVIS-Bildschirme (Haupt-App, Anruf), damit beim Wechsel nichts flackert. */
    fun onUiVisible(visible: Boolean) {
        visibleScreens = (visibleScreens + if (visible) 1 else -1).coerceAtLeast(0)
        uiVisible = visibleScreens > 0
        if (visible && Guide.running) Guide.cancelled = true
        if (visible) {
            main.removeCallbacks(hideOverlay)
            overlay.hide()
            app.getSystemService(NotificationManager::class.java).cancel(REPLY_NOTIFICATION_ID)
        }
    }

    // ---------- Benachrichtigungen ----------

    fun openAppIntent(): PendingIntent = PendingIntent.getActivity(
        app, 0, Intent(app, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    fun canNotify(): Boolean = Build.VERSION.SDK_INT < 33 ||
        app.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    private fun postReplyNotification(text: String) {
        if (!canNotify()) return
        val n = Notification.Builder(app, CH_REPLY)
            .setSmallIcon(R.drawable.ic_notify)
            .setContentTitle("🤖 JARVIS")
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setContentIntent(openAppIntent())
            .setAutoCancel(true)
            .build()
        app.getSystemService(NotificationManager::class.java).notify(REPLY_NOTIFICATION_ID, n)
    }
}
