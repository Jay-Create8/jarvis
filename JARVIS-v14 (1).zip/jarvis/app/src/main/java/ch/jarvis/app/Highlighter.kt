package ch.jarvis.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.View
import android.view.WindowManager
import kotlin.math.PI
import kotlin.math.sin

/**
 * Malt leuchtende JARVIS-Rahmen über beliebige Stellen auf dem Bildschirm –
 * über jeder App, z.B. "Zeig mir, wo der Senden-Knopf ist" oder "Markiere den Fehler".
 * Die Rahmen lassen Berührungen durch, du kannst also ganz normal weitertippen.
 */
class Highlighter(private val ctx: Context) {

    data class Mark(val rect: RectF, val label: String)

    private val main = Handler(Looper.getMainLooper())
    private var view: MarkView? = null
    private val autoHide = Runnable { hide() }
    private val wm get() = ctx.getSystemService(WindowManager::class.java)

    /** Muss auf dem Haupt-Thread laufen. */
    fun show(marks: List<Mark>, seconds: Int): Boolean {
        if (!Settings.canDrawOverlays(ctx) || marks.isEmpty()) return false
        hide()
        val v = MarkView(ctx).also { it.marks = marks }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        )
        return try {
            wm.addView(v, lp)
            view = v
            main.removeCallbacks(autoHide)
            main.postDelayed(autoHide, seconds.coerceIn(2, 30) * 1000L)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun hide() {
        main.removeCallbacks(autoHide)
        view?.let { runCatching { wm.removeView(it) } }
        view = null
    }

    private class MarkView(c: Context) : View(c) {
        var marks: List<Mark> = emptyList()
        private val density = c.resources.displayMetrics.density
        private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = 0xFF29E6FF.toInt()
        }
        private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = 0x5529E6FF
        }
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = 0x2229E6FF
        }
        private val labelBg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = 0xEE071A2B.toInt()
        }
        private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFFFFFFFF.toInt()
            textSize = 14 * density
            isFakeBoldText = true
        }
        private val loc = IntArray(2)

        override fun onDraw(canvas: Canvas) {
            getLocationOnScreen(loc)
            val t = (SystemClock.uptimeMillis() % 1200L) / 1200f
            val pulse = 0.5f + 0.5f * sin(t * 2f * PI.toFloat())
            val pad = 6 * density
            val radius = 12 * density
            for (m in marks) {
                val r = RectF(m.rect)
                r.offset(-loc[0].toFloat(), -loc[1].toFloat())
                r.inset(-pad, -pad)
                canvas.drawRoundRect(r, radius, radius, fill)
                glow.strokeWidth = (8 + 10 * pulse) * density
                canvas.drawRoundRect(r, radius, radius, glow)
                stroke.strokeWidth = (2.5f + 1.5f * pulse) * density
                canvas.drawRoundRect(r, radius, radius, stroke)
                if (m.label.isNotBlank()) {
                    val label = "🎯 " + m.label.take(40)
                    val w = text.measureText(label) + 16 * density
                    val h = 26 * density
                    // Beschriftung über dem Rahmen, oder darunter wenn oben kein Platz ist
                    val top = if (r.top - h - 4 * density > 0) r.top - h - 4 * density else r.bottom + 4 * density
                    val left = r.left.coerceIn(0f, (width - w).coerceAtLeast(0f))
                    val box = RectF(left, top, left + w, top + h)
                    canvas.drawRoundRect(box, h / 2, h / 2, labelBg)
                    canvas.drawRoundRect(box, h / 2, h / 2, stroke)
                    canvas.drawText(label, box.left + 8 * density, box.bottom - 8 * density, text)
                }
            }
            postInvalidateOnAnimation() // pulsieren lassen
        }
    }
}
