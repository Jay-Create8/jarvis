package ch.jarvis.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.Handler
import android.os.Looper
import android.util.Base64
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import java.io.ByteArrayOutputStream
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * JARVIS' Augen: macht unsichtbar im Hintergrund ein Foto (ohne Kamera-App),
 * z.B. während du im Chat bist. Android zeigt dabei oben den grünen Kamera-Punkt.
 */
object CameraEye {

    /** Mini-"Lebenszyklus", damit CameraX auch ohne sichtbaren Bildschirm arbeitet. */
    private class Owner : LifecycleOwner {
        val registry = LifecycleRegistry(this)
        override val lifecycle: Lifecycle get() = registry

        fun finish() {
            if (registry.currentState.isAtLeast(Lifecycle.State.CREATED)) {
                registry.currentState = Lifecycle.State.DESTROYED
            }
        }
    }

    /** Macht ein Foto. Blockiert bis zu 15 s – NICHT auf dem Haupt-Thread aufrufen. */
    fun capture(ctx: Context, front: Boolean): Bitmap {
        check(Looper.myLooper() != Looper.getMainLooper()) { "nicht auf dem Haupt-Thread" }
        if (ctx.checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            throw IllegalStateException("Kamera-Berechtigung fehlt (⚙️ → Superkräfte)")
        }
        val latch = CountDownLatch(1)
        var result: Bitmap? = null
        var error: String? = null
        val main = ContextCompat.getMainExecutor(ctx)
        val handler = Handler(Looper.getMainLooper())

        main.execute {
            val owner = Owner()
            val future = ProcessCameraProvider.getInstance(ctx)
            future.addListener({
                var provider: ProcessCameraProvider? = null
                val capture = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                    .build()
                fun done() {
                    runCatching { provider?.unbind(capture) }
                    owner.finish()
                    latch.countDown()
                }
                try {
                    val p = future.get()
                    provider = p
                    val selector = if (front) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
                    owner.registry.currentState = Lifecycle.State.RESUMED
                    p.bindToLifecycle(owner, selector, capture)
                    // kurz warten, damit sich Belichtung und Fokus einstellen
                    handler.postDelayed({
                        capture.takePicture(main, object : ImageCapture.OnImageCapturedCallback() {
                            override fun onCaptureSuccess(image: ImageProxy) {
                                try {
                                    result = rotate(image.toBitmap(), image.imageInfo.rotationDegrees)
                                } catch (e: Exception) {
                                    error = e.message
                                } finally {
                                    image.close()
                                    done()
                                }
                            }

                            override fun onError(exception: ImageCaptureException) {
                                error = exception.message
                                done()
                            }
                        })
                    }, 700)
                } catch (e: Exception) {
                    error = e.message
                    done()
                }
            }, main)
        }

        if (!latch.await(15, TimeUnit.SECONDS)) throw IllegalStateException("Kamera hat nicht geantwortet")
        return result ?: throw IllegalStateException(
            "Kamera nicht verfügbar: ${error ?: "unbekannt"}. Ist sie gerade von einer anderen App belegt? " +
                "Im Hintergrund klappt's nur, wenn \"Hey Jarvis\" eingeschaltet ist.")
    }

    private fun rotate(bmp: Bitmap, degrees: Int): Bitmap {
        if (degrees == 0) return bmp
        val m = Matrix().apply { postRotate(degrees.toFloat()) }
        return Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
    }

    /** Verkleinert auf max. 1024 px und macht JPEG-Base64 für die KI. */
    fun encode(bmp: Bitmap, maxSide: Int = 1024): String {
        val scale = maxSide.toFloat() / maxOf(bmp.width, bmp.height)
        val small = if (scale < 1f) {
            Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true)
        } else bmp
        val out = ByteArrayOutputStream()
        small.compress(Bitmap.CompressFormat.JPEG, 80, out)
        return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }
}
