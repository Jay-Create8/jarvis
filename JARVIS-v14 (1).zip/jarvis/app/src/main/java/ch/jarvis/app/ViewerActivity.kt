package ch.jarvis.app

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File

/** Zeigt, was JARVIS gebaut hat: HTML-Apps/Spiele laufen hier drin, Texte werden schön angezeigt. */
class ViewerActivity : Activity() {

    companion object {
        const val EXTRA_PATH = "path"
    }

    private lateinit var web: WebView
    private var path = ""

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        path = intent.getStringExtra(EXTRA_PATH).orEmpty()
        val file = File(path)
        if (!file.exists()) {
            Toast.makeText(this, "Datei nicht gefunden 😕", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        val density = resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#02060D"))
            fitsSystemWindows = true
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#0A1A2A"))
            setPadding(dp(12), dp(8), dp(8), dp(8))
        }
        fun barButton(label: String, onClick: () -> Unit) = TextView(this).apply {
            text = label
            textSize = 15f
            setTextColor(Color.parseColor("#29E6FF"))
            setPadding(dp(10), dp(8), dp(10), dp(8))
            setOnClickListener { onClick() }
        }
        val title = TextView(this).apply {
            text = "${Creations.icon(path)} ${file.nameWithoutExtension.replace('_', ' ')}"
            textSize = 17f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            maxLines = 1
        }
        bar.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(barButton("📤") { runCatching { Creations.share(this, path) } })
        bar.addView(barButton("💾") {
            val ok = Creations.exportToDownloads(this, path)
            Toast.makeText(this, if (ok) "Gespeichert in Download/JARVIS ✅" else "Speichern hat nicht geklappt 😕",
                Toast.LENGTH_SHORT).show()
        })
        bar.addView(barButton("✕") { finish() })

        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = false
            settings.mediaPlaybackRequiresUserGesture = false
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient() // erlaubt alert()/confirm() in Spielen
            setBackgroundColor(Color.parseColor("#02060D"))
        }
        root.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        val content = file.readText(Charsets.UTF_8)
        val html = if (Creations.isApp(path)) content else textPage(content)
        // Eigene "Adresse", damit Spielstände (localStorage) pro App gespeichert bleiben
        web.loadDataWithBaseURL("https://jarvis.app/${file.nameWithoutExtension}/", html, "text/html", "UTF-8", null)
    }

    private fun textPage(text: String): String {
        val esc = text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        return """<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>body{background:#02060D;color:#E8F6FF;font-family:sans-serif;font-size:16px;line-height:1.55;
padding:16px;white-space:pre-wrap;word-wrap:break-word}</style></head><body>$esc</body></html>"""
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        if (::web.isInitialized) web.destroy()
        super.onDestroy()
    }
}
