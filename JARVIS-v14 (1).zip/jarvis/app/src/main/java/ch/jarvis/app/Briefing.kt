package ch.jarvis.app

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.util.Calendar

/** Automatisches Morgen-Briefing: jeden Tag zur eingestellten Zeit, ohne dass du die App öffnest. */
object Briefing {

    const val PROMPT =
        "[Automatisches Morgen-Briefing, der Nutzer hat die App NICHT geöffnet] " +
            "Mach ein kurzes, motivierendes Briefing für heute: Hol das Wetter (get_weather), die heutigen Termine " +
            "(get_calendar_events) und schau auf offene Aufgaben und fällige Dinge. Gib dann einen konkreten Tipp " +
            "oder Vorschlag für den Tag. Maximal 5 Sätze, locker, ohne Aufzählungszeichen."

    private fun pending(ctx: Context) = PendingIntent.getBroadcast(
        ctx, 4242, Intent(ctx, BriefingReceiver::class.java),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    /** Plant das nächste Briefing (oder löscht es, wenn ausgeschaltet). */
    fun schedule(ctx: Context) {
        val store = Store(ctx)
        val am = ctx.getSystemService(AlarmManager::class.java)
        am.cancel(pending(ctx))
        if (!store.briefingEnabled) return
        val next = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, store.briefingHour)
            set(Calendar.MINUTE, store.briefingMinute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis() + 5_000) add(Calendar.DAY_OF_YEAR, 1)
        }
        ReminderReceiver.scheduleAt(ctx, next.timeInMillis, pending(ctx))
    }
}

class BriefingReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        Jarvis.init(ctx)
        Briefing.schedule(ctx) // gleich das morgige planen
        if (Jarvis.store.apiKey.isBlank()) return
        val result = goAsync()
        CoroutineScope(SupervisorJob() + Dispatchers.Main).launch {
            try {
                val text = withTimeoutOrNull(50_000) { Jarvis.askQuietly(Briefing.PROMPT) }
                    ?: "Guten Morgen! ☀️ Fürs Briefing war das Internet grad zu langsam, frag mich einfach in der App."
                if (Jarvis.canNotify()) {
                    val n = Notification.Builder(ctx, Jarvis.CH_REPLY)
                        .setSmallIcon(R.drawable.ic_notify)
                        .setContentTitle("☀️ Dein JARVIS-Briefing")
                        .setContentText(text)
                        .setStyle(Notification.BigTextStyle().bigText(text))
                        .setContentIntent(Jarvis.openAppIntent())
                        .setAutoCancel(true)
                        .build()
                    withContext(Dispatchers.Default) {
                        ctx.getSystemService(NotificationManager::class.java).notify(4242, n)
                    }
                }
                if (Jarvis.store.briefingSpeak) Jarvis.announce(text)
            } finally {
                result.finish()
            }
        }
    }
}
