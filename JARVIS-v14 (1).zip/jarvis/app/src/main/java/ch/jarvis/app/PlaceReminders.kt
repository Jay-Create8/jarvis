package ch.jarvis.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Geocoder
import android.os.Build
import com.google.android.gms.location.Geofence
import com.google.android.gms.location.GeofencingEvent
import com.google.android.gms.location.GeofencingRequest
import com.google.android.gms.location.LocationServices
import java.util.Locale
import kotlin.math.abs

/** "Erinnere mich an Milch, wenn ich beim Coop bin" – Erinnerungen, die beim Ankommen an einem Ort auslösen. */
object PlaceReminders {

    private fun pending(ctx: Context): PendingIntent = PendingIntent.getBroadcast(
        ctx, 777, Intent(ctx, GeofenceReceiver::class.java),
        PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0),
    )

    fun hasPermission(ctx: Context): Boolean {
        val fine = ctx.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val bg = Build.VERSION.SDK_INT < 29 ||
            ctx.checkSelfPermission(Manifest.permission.ACCESS_BACKGROUND_LOCATION) == PackageManager.PERMISSION_GRANTED
        return fine && bg
    }

    @SuppressLint("MissingPermission")
    fun register(ctx: Context, r: Store.PlaceReminder) {
        if (!hasPermission(ctx)) return
        val fence = Geofence.Builder()
            .setRequestId(r.id)
            .setCircularRegion(r.lat, r.lon, 150f)
            .setExpirationDuration(Geofence.NEVER_EXPIRE)
            .setTransitionTypes(Geofence.GEOFENCE_TRANSITION_ENTER)
            .build()
        val req = GeofencingRequest.Builder().setInitialTrigger(0).addGeofence(fence).build()
        LocationServices.getGeofencingClient(ctx).addGeofences(req, pending(ctx))
    }

    fun unregister(ctx: Context, id: String) {
        runCatching { LocationServices.getGeofencingClient(ctx).removeGeofences(listOf(id)) }
    }

    fun restoreAll(ctx: Context) {
        Store(ctx).placeReminders().forEach { runCatching { register(ctx, it) } }
    }

    /** Sucht den Ort – bevorzugt in deiner Nähe (z.B. "Coop" → der nächste Coop). */
    @Suppress("DEPRECATION")
    fun resolve(ctx: Context, place: String): Triple<Double, Double, String>? {
        val here = Web.lastLocation(ctx)
        if (Geocoder.isPresent()) {
            val g = Geocoder(ctx, Locale.GERMAN)
            val results = runCatching {
                if (here != null) {
                    g.getFromLocationName(place, 8, here.latitude - 0.2, here.longitude - 0.3,
                        here.latitude + 0.2, here.longitude + 0.3)
                } else {
                    g.getFromLocationName(place, 1)
                }
            }.getOrNull().orEmpty()
            val best = if (here != null) {
                results.minByOrNull { abs(it.latitude - here.latitude) + abs(it.longitude - here.longitude) }
            } else results.firstOrNull()
            if (best != null) {
                val label = listOfNotNull(best.featureName, best.thoroughfare, best.locality).distinct().joinToString(", ")
                return Triple(best.latitude, best.longitude, label.ifBlank { place })
            }
        }
        return runCatching { Web.geocodeCity(place) }.getOrNull()
    }
}

class GeofenceReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val event = GeofencingEvent.fromIntent(intent) ?: return
        if (event.hasError()) return
        Jarvis.init(ctx)
        val store = Jarvis.store
        event.triggeringGeofences.orEmpty().forEach { fence ->
            val r = store.placeReminders().firstOrNull { it.id == fence.requestId } ?: return@forEach
            store.removePlaceReminder(r.id)
            PlaceReminders.unregister(ctx, r.id)
            if (Jarvis.canNotify()) {
                val n = Notification.Builder(ctx, Jarvis.CH_REMINDER)
                    .setSmallIcon(R.drawable.ic_notify)
                    .setContentTitle("📍 Du bist bei ${r.place}")
                    .setContentText(r.text)
                    .setStyle(Notification.BigTextStyle().bigText(r.text))
                    .setContentIntent(Jarvis.openAppIntent())
                    .setAutoCancel(true)
                    .build()
                ctx.getSystemService(NotificationManager::class.java).notify(r.id.hashCode(), n)
            }
            Jarvis.announce("Du bist bei ${r.place}. Denk an: ${r.text}")
        }
    }
}
