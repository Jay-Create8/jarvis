package ch.jarvis.app

import android.Manifest
import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/**
 * Hört dauerhaft auf "Jarvis" – auch wenn der Bildschirm aus ist.
 *
 * Modus 1 (Standard): openWakeWord "Hey Jarvis" – offline, gratis, akkuschonend.
 * Modus 2 (Notlösung, falls Modus 1 auf dem Handy nicht startet): Google-Spracherkennung
 *   in Dauerschleife. Braucht mehr Akku, dafür klappt "Jarvis, stell einen Timer" in einem Satz.
 */
class WakeService : Service(), Jarvis.WakeHooks {

    companion object {
        const val ACTION_STOP = "ch.jarvis.app.STOP_WAKE"
        private const val NOTIF_ID = 42
        private val WAKE_REGEX = Regex("\\b(jarvis|jarwis|javis|jervis|charvis|tschawis|dschawis|jarvi)\\b", RegexOption.IGNORE_CASE)
    }

    private val main = Handler(Looper.getMainLooper())
    private var detector: WakeWordDetector? = null
    private var fallback: SpeechRecognizer? = null
    private var useFallback = false
    private var paused = true
    private var ready = false
    private var fallbackErrors = 0
    private val restartFallback = Runnable { listenFallback() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        Jarvis.init(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            Jarvis.store.wakeEnabled = false
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                // Mikrofon für "Hey Jarvis" + Kamera, damit JARVIS auch im Hintergrund schauen darf
                var types = ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                    types = types or ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
                }
                startForeground(NOTIF_ID, notification(), types)
            } else {
                startForeground(NOTIF_ID, notification())
            }
        } catch (e: Exception) {
            // Android verbietet Mikrofon-Dienste, die im Hintergrund gestartet werden
            Jarvis.wakeInfo = "Bitte App öffnen, um \"Hey JARVIS\" zu starten"
            stopSelf()
            return START_NOT_STICKY
        }
        if (!ready) setup()
        return START_STICKY
    }

    private fun notification(): Notification {
        val stop = PendingIntent.getService(
            this, 0, Intent(this, WakeService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE,
        )
        return Notification.Builder(this, Jarvis.CH_WAKE)
            .setSmallIcon(R.drawable.ic_notify)
            .setContentTitle("👂 JARVIS hört zu")
            .setContentText("Sag \"Hey Jarvis\" – ich bin da.")
            .setContentIntent(Jarvis.openAppIntent())
            .addAction(Notification.Action.Builder(null, "Ausschalten", stop).build())
            .setOngoing(true)
            .build()
    }

    private fun setup() {
        ready = true
        Jarvis.wakeHooks = this
        Jarvis.wakeActive = true
        Jarvis.wakeInfo = "Lade Wake-Word …"
        // Modelle laden dauert einen Moment -> nicht auf dem Haupt-Thread
        Thread {
            val result: Any = try {
                WakeWordDetector(applicationContext) { main.post { onWake(null) } }
            } catch (e: Throwable) {
                e
            }
            main.post {
                if (!ready) {
                    (result as? WakeWordDetector)?.close()
                    return@post
                }
                if (result is WakeWordDetector) {
                    result.sensitivity = Jarvis.store.wakeSensitivity
                    detector = result
                    useFallback = false
                    Jarvis.wakeInfo = "Sag \"Hey Jarvis\" ✅ (offline)"
                } else {
                    useFallback = true
                    Jarvis.wakeInfo = "Notlösungs-Modus über Google (${(result as Throwable).message})"
                }
                resumeWake()
            }
        }.start()
    }

    // ---------- Jarvis.WakeHooks ----------

    override fun pauseWake() {
        paused = true
        main.removeCallbacks(restartFallback)
        detector?.stop()
        fallback?.cancel()
    }

    override fun resumeWake() {
        paused = false
        if (!ready || Jarvis.phase != Phase.IDLE) return
        if (useFallback) {
            main.removeCallbacks(restartFallback)
            main.postDelayed(restartFallback, 400)
        } else {
            // kurz warten, bis die Spracherkennung das Mikrofon wirklich losgelassen hat
            main.postDelayed({
                if (!paused && Jarvis.phase == Phase.IDLE) {
                    if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                        Jarvis.wakeInfo = "Mikrofon-Berechtigung fehlt 🎙️"
                    } else if (detector?.start() == false) {
                        Jarvis.wakeInfo = "Mikrofon belegt, versuche es gleich wieder …"
                        main.postDelayed({ if (!paused) resumeWake() }, 3000)
                    } else {
                        Jarvis.wakeInfo = "Sag \"Hey Jarvis\" ✅ (offline)"
                    }
                }
            }, 300)
        }
    }

    // ---------- Aufgeweckt! ----------

    private fun onWake(command: String?) {
        if (paused || Jarvis.phase != Phase.IDLE) return
        pauseWake()
        feedback()
        if (command.isNullOrBlank()) {
            // kurz warten, bis das Mikrofon frei ist, dann zuhören
            main.postDelayed({ Jarvis.startListening() }, 350)
        } else {
            Jarvis.handleInput(command)
        }
    }

    private fun feedback() {
        runCatching {
            val tg = ToneGenerator(AudioManager.STREAM_MUSIC, 70)
            tg.startTone(ToneGenerator.TONE_PROP_BEEP2, 160)
            main.postDelayed({ tg.release() }, 400)
        }
        runCatching {
            @Suppress("DEPRECATION")
            val vib = getSystemService(Vibrator::class.java)
            vib?.vibrate(VibrationEffect.createOneShot(40, VibrationEffect.DEFAULT_AMPLITUDE))
        }
    }

    // ---------- Notlösung: Google-Spracherkennung in Schleife ----------

    private val fallbackListener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onError(error: Int) {
            if (paused) return
            fallbackErrors = if (error == SpeechRecognizer.ERROR_NO_MATCH ||
                error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) 0 else fallbackErrors + 1
            // bei echten Fehlern langsamer neu versuchen, um Akku zu sparen
            val delay = if (fallbackErrors == 0) 200L else (1000L * fallbackErrors).coerceAtMost(15_000L)
            main.postDelayed(restartFallback, delay)
        }

        override fun onResults(results: Bundle?) {
            if (paused) return
            fallbackErrors = 0
            val heard = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
            val hit = heard.firstNotNullOfOrNull { text -> WAKE_REGEX.find(text)?.let { text to it } }
            if (hit != null) {
                val (text, match) = hit
                val command = text.substring(match.range.last + 1).trim(' ', ',', '.', '!', '?')
                onWake(command)
            } else {
                main.postDelayed(restartFallback, 200)
            }
        }
    }

    private fun listenFallback() {
        if (paused || !ready || Jarvis.phase != Phase.IDLE) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Jarvis.wakeInfo = "Keine Spracherkennung verfügbar 😕"
            return
        }
        val rec = fallback ?: SpeechRecognizer.createSpeechRecognizer(this).also {
            it.setRecognitionListener(fallbackListener)
            fallback = it
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "de-DE")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
        }
        rec.startListening(i)
    }

    override fun onDestroy() {
        ready = false
        paused = true
        main.removeCallbacksAndMessages(null)
        if (Jarvis.wakeHooks === this) Jarvis.wakeHooks = null
        Jarvis.wakeActive = false
        Jarvis.wakeInfo = ""
        detector?.close()
        detector = null
        fallback?.destroy()
        fallback = null
        super.onDestroy()
    }
}
