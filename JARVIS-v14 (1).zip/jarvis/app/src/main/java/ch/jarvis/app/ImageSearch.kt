package ch.jarvis.app

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * 🖼️ JARVIS schickt Bilder in den Chat:
 *  - Bildersuche (Openverse + Wikimedia Commons, beide gratis und ohne Key)
 *  - Bilder von Webseiten (z.B. aus den Quellen einer Internetsuche)
 *  - direkte Bild-Links
 */
object ImageSearch {

    private const val UA = "JARVIS-Android/1.0 (personal assistant app)"
    private const val MAX_BYTES = 8 * 1024 * 1024

    private data class Found(val url: String, val title: String)

    private fun open(url: String, accept: String): HttpURLConnection {
        var current = url
        // Weiterleitungen selbst folgen (auch von http zu https)
        repeat(5) {
            val con = URL(current).openConnection() as HttpURLConnection
            con.connectTimeout = 12_000
            con.readTimeout = 20_000
            con.instanceFollowRedirects = false
            con.setRequestProperty("User-Agent", UA)
            con.setRequestProperty("Accept", accept)
            val code = con.responseCode
            if (code in 300..399) {
                val loc = con.getHeaderField("Location") ?: return con
                current = URL(URL(current), loc).toString()
                con.disconnect()
            } else {
                return con
            }
        }
        throw java.io.IOException("Zu viele Weiterleitungen")
    }

    private fun getText(url: String, accept: String = "application/json"): String {
        val con = open(url, accept)
        if (con.responseCode !in 200..299) throw java.io.IOException("HTTP ${con.responseCode}")
        return con.inputStream.bufferedReader(Charsets.UTF_8).use { r ->
            val sb = StringBuilder()
            val buf = CharArray(8192)
            while (sb.length < 600_000) {
                val n = r.read(buf)
                if (n < 0) break
                sb.append(buf, 0, n)
            }
            sb.toString()
        }
    }

    private fun getBytes(url: String): ByteArray? = runCatching {
        val con = open(url, "image/*")
        if (con.responseCode !in 200..299) return null
        val type = con.contentType.orEmpty()
        if (type.isNotBlank() && !type.startsWith("image/")) return null
        con.inputStream.use { input ->
            val out = ByteArrayOutputStream()
            val buf = ByteArray(16_384)
            while (true) {
                val n = input.read(buf)
                if (n < 0) break
                out.write(buf, 0, n)
                if (out.size() > MAX_BYTES) return null
            }
            out.toByteArray()
        }
    }.getOrNull()

    private fun openverse(query: String, n: Int): List<Found> = runCatching {
        val o = JSONObject(getText("https://api.openverse.org/v1/images/?q=${Uri.encode(query)}&page_size=${n * 2}&mature=false"))
        val arr = o.optJSONArray("results") ?: JSONArray()
        (0 until arr.length()).mapNotNull { i ->
            val r = arr.getJSONObject(i)
            val url = r.optString("url").ifBlank { r.optString("thumbnail") }
            if (url.isBlank()) null else Found(url, r.optString("title"))
        }
    }.getOrDefault(emptyList())

    private fun wikimedia(query: String, n: Int): List<Found> = runCatching {
        val api = "https://commons.wikimedia.org/w/api.php?action=query&format=json&generator=search" +
            "&gsrnamespace=6&gsrlimit=${n * 2}&gsrsearch=${Uri.encode("$query filetype:bitmap")}" +
            "&prop=imageinfo&iiprop=url&iiurlwidth=1024"
        val pages = JSONObject(getText(api)).optJSONObject("query")?.optJSONObject("pages") ?: return emptyList()
        val list = mutableListOf<Pair<Int, Found>>()
        pages.keys().forEach { k ->
            val p = pages.getJSONObject(k)
            val info = p.optJSONArray("imageinfo")?.optJSONObject(0) ?: return@forEach
            val url = info.optString("thumburl").ifBlank { info.optString("url") }
            if (url.isNotBlank()) {
                val title = p.optString("title").removePrefix("File:").substringBeforeLast('.')
                list.add(p.optInt("index", 99) to Found(url, title))
            }
        }
        list.sortedBy { it.first }.map { it.second }
    }.getOrDefault(emptyList())

    /** Vorschaubild einer Webseite (og:image / twitter:image). */
    private fun pageImage(pageUrl: String): Found? = runCatching {
        val html = getText(pageUrl, "text/html")
        val patterns = listOf(
            Regex("""<meta[^>]+(?:property|name)=["'](?:og:image|og:image:url|twitter:image)["'][^>]*content=["']([^"']+)["']""", RegexOption.IGNORE_CASE),
            Regex("""<meta[^>]+content=["']([^"']+)["'][^>]*(?:property|name)=["'](?:og:image|og:image:url|twitter:image)["']""", RegexOption.IGNORE_CASE),
        )
        val raw = patterns.firstNotNullOfOrNull { it.find(html)?.groupValues?.get(1) } ?: return null
        val title = Regex("""<title[^>]*>([^<]{1,120})""", RegexOption.IGNORE_CASE).find(html)?.groupValues?.get(1)?.trim().orEmpty()
        Found(URL(URL(pageUrl), raw.replace("&amp;", "&")).toString(), title)
    }.getOrNull()

    /**
     * Holt Bilder und schickt sie in den Chat.
     * @param urls direkte Bild-Links oder Webseiten (durch Leerzeichen/Komma getrennt)
     */
    fun show(ctx: Context, query: String?, urls: String?, count: Int, caption: String?): JSONObject {
        val n = count.coerceIn(1, 6)
        val candidates = mutableListOf<Found>()

        urls.orEmpty().split(Regex("[\\s,]+")).map { it.trim() }.filter { it.startsWith("http") }.forEach { u ->
            val looksLikeImage = Regex("""\.(jpe?g|png|webp|gif|bmp)(\?|$)""", RegexOption.IGNORE_CASE).containsMatchIn(u)
            if (looksLikeImage) candidates.add(Found(u, "")) else pageImage(u)?.let { candidates.add(it) }
        }
        if (!query.isNullOrBlank() && candidates.size < n) {
            candidates += wikimedia(query, n)
            if (candidates.size < n * 2) candidates += openverse(query, n)
        }
        if (candidates.isEmpty()) {
            return JSONObject().put("ok", false).put("error", "Keine Bilder gefunden – versuch einen anderen (englischen) Suchbegriff oder gib page_urls an")
        }

        val paths = mutableListOf<String>()
        val titles = JSONArray()
        for (c in candidates.distinctBy { it.url }) {
            if (paths.size >= n) break
            val bytes = getBytes(c.url) ?: continue
            val path = ChatImages.fromBytes(ctx, bytes) ?: continue
            paths.add(path)
            if (c.title.isNotBlank()) titles.put(c.title)
        }
        if (paths.isEmpty()) {
            return JSONObject().put("ok", false).put("error", "Bilder gefunden, aber keins liess sich laden")
        }
        Jarvis.postImages(caption.orEmpty(), paths)
        return JSONObject().put("ok", true)
            .put("result", "${paths.size} Bild(er) sind jetzt im Chat zu sehen. Beschreib sie nur kurz, nicht nochmal alles.")
            .put("titles", titles)
    }
}
