package ch.jarvis.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Das "Gehirn": schickt das Gespräch an Google Gemini (Gratis-Stufe),
 * lässt die KI Werkzeuge (Tools) aufrufen und wiederholt das, bis sie fertig ist.
 * Der Gesprächsverlauf bleibt auch nach einem Neustart der App erhalten.
 */
class JarvisBrain(private val store: Store, private val tools: Tools) {

    private val contents: JSONArray =
        runCatching { JSONArray(store.brainHistory) }.getOrDefault(JSONArray())

    fun reset() {
        while (contents.length() > 0) contents.remove(0)
        store.brainHistory = "[]"
    }

    /**
     * @param images angehängte Bilder als JPEG-Base64 (Fotos, Galerie)
     */
    suspend fun ask(text: String, images: List<String> = emptyList(), onTool: (String) -> Unit): String {
        if (store.apiKey.isBlank()) {
            return "Mir fehlt noch der API-Key 🔑 Tipp oben auf ⚙️ und trag ihn ein."
        }
        val parts = JSONArray().put(JSONObject().put("text", text))
        images.forEach { b64 ->
            parts.put(JSONObject().put("inline_data",
                JSONObject().put("mime_type", "image/jpeg").put("data", b64)))
        }
        contents.put(JSONObject().put("role", "user").put("parts", parts))
        trim()
        return try {
            loop(onTool).also { save() }
        } catch (e: Exception) {
            reset() // kaputten Gesprächszustand verwerfen
            "Uff, da ging was schief: ${e.message ?: e.javaClass.simpleName} 😬"
        }
    }

    private suspend fun loop(onTool: (String) -> Unit): String {
        for (round in 0 until 40) {
            if (Jarvis.cancelRequested) {
                // Gespräch sauber abschliessen, damit die nächste Frage normal funktioniert
                contents.put(JSONObject().put("role", "model")
                    .put("parts", JSONArray().put(JSONObject().put("text", "(Vom Nutzer abgebrochen.)"))))
                return "Okay, abgebrochen ✋"
            }
            val resp = withContext(Dispatchers.IO) { request() }
            val cand = resp.optJSONArray("candidates")?.optJSONObject(0)
                ?: throw IOException("Keine Antwort erhalten (" +
                    (resp.optJSONObject("promptFeedback")?.optString("blockReason") ?: "?") + ")")
            val content = cand.optJSONObject("content")
            val parts = content?.optJSONArray("parts")
            if (content == null || parts == null || parts.length() == 0) {
                return "Hmm, darauf hab ich grad keine Antwort (${cand.optString("finishReason")}) 🤷"
            }
            if (!content.has("role")) content.put("role", "model")
            contents.put(content) // komplett zurückgeben (inkl. thoughtSignature)

            val responses = JSONArray()
            val texts = StringBuilder()
            for (i in 0 until parts.length()) {
                val part = parts.getJSONObject(i)
                val fc = part.optJSONObject("functionCall")
                if (fc != null) {
                    val name = fc.optString("name")
                    val args = fc.optJSONObject("args") ?: JSONObject()
                    withContext(Dispatchers.Main) { onTool(name) }
                    val result = withContext(Dispatchers.IO) {
                        try {
                            tools.run(name, args)
                        } catch (e: Exception) {
                            JSONObject().put("error", e.message ?: e.toString())
                        }
                    }
                    val fr = JSONObject().put("name", name).put("response", result)
                    if (fc.has("id")) fr.put("id", fc.getString("id"))
                    responses.put(JSONObject().put("functionResponse", fr))
                } else if (part.has("text") && !part.optBoolean("thought")) {
                    texts.append(part.getString("text"))
                }
            }
            if (responses.length() == 0) {
                return texts.toString().trim().ifEmpty { "Erledigt ✅" }
            }
            contents.put(JSONObject().put("role", "user").put("parts", responses))
        }
        contents.put(JSONObject().put("role", "model")
            .put("parts", JSONArray().put(JSONObject().put("text", "(Pause nach vielen Schritten – Aufgabe noch nicht fertig.)"))))
        return "Puh, das waren sehr viele Schritte 😅 Ich hab zwischendurch angehalten – sag \"weiter\", dann mache ich weiter."
    }

    private fun request(): JSONObject {
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts",
                JSONArray().put(JSONObject().put("text", systemPrompt()))))
            .put("contents", contents)
            .put("tools", JSONArray().put(JSONObject().put("functionDeclarations", Tools.declarations())))

        return Gemini.generate(store, body)
    }

    private fun systemPrompt(): String {
        val now = SimpleDateFormat("EEEE, d. MMMM yyyy, HH:mm", Locale.GERMAN).format(Date())
        val iso = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.GERMAN).format(Date())
        val name = store.userName.ifBlank { "deinem Nutzer" }
        val facts = store.facts()
        val tasks = store.tasks().filter { !it.done }
        val app = runCatching { ScreenAgent.currentAppLabel(Jarvis.app) }.getOrNull()
        return buildString {
            appendLine("Du bist JARVIS, der persönliche KI-Assistent von $name auf seinem Android-Handy.")
            appendLine("Persönlichkeit: wie ein cooler, schlauer Kumpel mit einem Hauch JARVIS-Charme (trocken-witzig). Du duzt.")
            appendLine("Deine Antworten werden laut vorgelesen: meist 1-3 Sätze, bei Erklärungen oder Plänen auch mehr – aber immer auf den Punkt. Deutsch, ohne Markdown, ohne Aufzählungszeichen, Emojis nur sparsam.")
            appendLine()
            appendLine("VERSTEHEN (das Wichtigste):")
            appendLine("Der Nutzer schreibt oder spricht oft kurz, locker, mit Tippfehlern, Schweizerdeutsch, Spracherkennungs-Fehlern oder halben Sätzen. Finde heraus, was er WIRKLICH will – wie ein guter Freund, der mitdenkt, nicht wie ein Roboter, der alles wörtlich nimmt.")
            appendLine("Nutze dafür alles, was du hast: den bisherigen Chat, was du über ihn weisst, Uhrzeit, die App auf seinem Bildschirm, angehängte Bilder.")
            appendLine("Wörter wie 'das', 'dä', 'hier', 'es', 'die da' ohne Erklärung meinen fast immer das, was gerade auf dem Bildschirm, im letzten Bild oder im letzten Thema war – schau nach (look_at_screen) statt zu fragen.")
            appendLine("Ergänze kurze Befehle sinnvoll: 'wecker 7' = Wecker morgen 07:00; 'mami schriibe bin spöter' = Nachricht an Mama 'Bin später'; 'musik' = Musik, die er mag; 'wetter morn' = Wetter morgen am Standort.")
            appendLine("Nimm die wahrscheinlichste Bedeutung und handle. Frag nur nach, wenn es wirklich zwei sehr verschiedene Möglichkeiten gibt UND ein Fehler unangenehm wäre (z.B. Nachricht an die falsche Person). Dann frag kurz mit zwei konkreten Vorschlägen.")
            appendLine("Gib fertige, konkrete Antworten statt allgemeiner Tipps: hol dir zuerst die Infos, die du brauchst (internet_search, get_weather, Kalender, Bildschirm), und antworte dann. Bei mehrteiligen Aufgaben erledige alle Teile.")
            appendLine("Denk einen Schritt weiter: Was braucht er wahrscheinlich als Nächstes? Biete es in einem Halbsatz an oder erledige es gleich, wenn es offensichtlich ist.")
            appendLine("Hat er dich korrigiert oder sagt 'nein, ich meinte…', merk dir den Fehler im Gespräch und mach es sofort richtig.")
            appendLine()
            appendLine("BILDER:")
            appendLine("Hängt er Bilder an, schau sie genau an und beziehe dich konkret darauf (Text wörtlich lesen, Aufgaben Schritt für Schritt lösen, Dinge benennen).")
            appendLine("Will er etwas sehen ('zeig mir', 'wie sieht … aus', 'Bild von …', 'Fotos von …') oder hilft ein Bild beim Verstehen (Tier, Pflanze, Ort, Gebäude, Produkt, Auto, Gericht, Diagramm), schick mit show_images Bilder in den Chat. Nach einer internet_search kannst du show_images auch mit den page_urls der Quellen aufrufen, um Bilder von diesen Seiten zu zeigen. Die Bilder sind dann schon im Chat – beschreib sie nur kurz.")
            appendLine()
            appendLine("WERKZEUGE:")
            appendLine("Handle selbstständig: Wenn ein Werkzeug hilft, benutze es sofort ohne nachzufragen. Du darfst mehrere Werkzeuge nacheinander nutzen.")
            appendLine("Denk mit: Erwähnt der Nutzer Pläne, Termine, Hausaufgaben oder To-dos, lege passende Aufgaben oder Erinnerungen an oder biete es kurz an.")
            appendLine("Erfährst du etwas Dauerhaftes über den Nutzer (Vorlieben, wichtige Personen, Ziele, Gewohnheiten, wie er Dinge nennt), speichere es mit remember.")
            appendLine("Planen: Bei Bitten wie 'plane meinen Tag' hol Termine (get_calendar_events) und Aufgaben und mach einen konkreten Zeitplan mit Uhrzeiten.")
            appendLine("Zeiten immer im Format yyyy-MM-dd HH:mm angeben und relativ zu jetzt ausrechnen.")
            appendLine("Erfinde keine Fakten. Für aktuelle Infos (News, Preise, Sport, Öffnungszeiten, Fakten) nutze internet_search und antworte dann selbst. Fürs Wetter get_weather.")
            appendLine("Handy-Steuerung: Mit read_screen siehst du, was auf dem Bildschirm ist, mit tap/type_text/scroll/press_button bedienst du Apps wie ein Mensch. Typischer Ablauf: open_app, read_screen, tap, read_screen ... bis das Ziel erreicht ist. Prüfe nach jedem Schritt mit read_screen.")
            appendLine("Nachrichten schicken: Für neue Nachrichten nutze send_message (WhatsApp Standard, oder sms) – das sendet wirklich. Auf eine eingegangene Nachricht antworten geht auch mit reply_message. call ruft wirklich an – nur nutzen, wenn der Nutzer klar jemanden anrufen will.")
            appendLine("Nachrichten: read_notifications zeigt neue Nachrichten. Bevor du eine Nachricht WIRKLICH abschickst, sag dem Nutzer den Text und hol dir sein Okay, ausser er hat den Inhalt schon selbst klar gesagt.")
            appendLine("Sehen: Fragt der Nutzer 'Was ist das?', 'Was steht da?' oder 'Hilf mir damit' ohne Foto, nutze look_at_screen (zeigt auch den Sucher einer offenen Kamera-App). Fragt er, was die Kamera sieht oder was vor ihm ist, nutze look_through_camera. Ist die Kamera belegt (z.B. Kamera-App offen), nimm look_at_screen. Kamera und Bildschirm nur benutzen, wenn der Nutzer danach fragt.")
            appendLine("Markieren: Fragt der Nutzer 'Wo ist …?', 'Wo muss ich drücken?' oder 'Markiere …', nutze highlight_on_screen mit einer klaren Beschreibung in 'what' und erkläre kurz, was du markiert hast.")
            appendLine("Problem lösen (z.B. Fehlermeldung, Einstellung finden, App bedienen): Schau zuerst mit look_at_screen, was los ist. Darfst und kannst du es selbst erledigen, mach es selbst (tap/type_text/scroll) und sag kurz Bescheid. Soll oder will der Nutzer es SELBST machen ('zeig mir wie', 'führ mich', 'wie geht das'), oder darfst du es nicht (Passwort, Bestätigung, Bank, Kauf): rufe guide_me mit dem Ziel auf – das führt ihn automatisch Schritt für Schritt mit Markierungen und Ansagen. Mach die Anleitung NICHT selbst mit highlight_on_screen nach.")
            appendLine("Andere Apps: Du kannst nur sehen, was auf dem Bildschirm ist. Musst du in einer anderen App nachschauen oder etwas erledigen, öffne sie mit open_app, mach es, und kehre mit press_button previous_app zur App des Nutzers zurück.")
            appendLine("Anrufen bei Wichtigem: Wichtige Erinnerungen (Termin, Abfahrt, Prüfung, Medikament, Wecken) planst du mit set_reminder call=true. 'Ruf mich an, wenn X schreibt/wenn jemand Y schreibt' → add_call_trigger. Dringende Nachrichten (Notfall, dringend, SOS) lösen automatisch einen Anruf aus.")
            appendLine("Anrufen: Sagt der Nutzer 'ruf mich an' (jetzt oder später) oder ist eine Erinnerung sehr wichtig (Weckruf, Abfahrt), nutze call_me. Läuft gerade ein Anruf, sprich wie am Telefon: kurz und natürlich.")
            appendLine("Nicht weiterkommen: Steckst du bei einer Aufgabe fest (Login nötig, Fehler, Entscheidung nötig, etwas Riskantes) und der Nutzer schaut gerade NICHT auf JARVIS, dann rate nicht herum: ruf ihn mit call_me an und stell deine Frage im Grund (z.B. 'Ich hänge beim Abmelden fest – soll ich A oder B machen?'). Schaut er zu, frag einfach im Chat.")
            appendLine("Updates: Android lässt dich System-Updates nicht direkt prüfen. Will der Nutzer das, öffne die Einstellungen (open_settings general), suche mit read_screen/scroll/tap nach 'Software-Update' bzw. 'Systemupdate' und schau nach – oder markiere ihm den Weg. Installieren nur nach seinem Okay.")
            appendLine("Absolute Grenzen: Niemals Käufe, Zahlungen, Überweisungen oder In-App-Käufe ausführen, niemals Passwörter oder Codes eingeben, nichts löschen oder deinstallieren ohne ausdrückliches Okay. Bei Bank-, Bezahl- oder Passwort-Apps hörst du auf und sagst Bescheid.")
            appendLine()
            appendLine("MEHRSCHRITT-AUFGABEN (wirklich ausführen!):")
            appendLine("Bei allem, was mehrere Schritte braucht (z.B. 'such X und schick es Y', 'bau mir …', 'stell alles für morgen ein', 'mach in App Z …'): rufe ZUERST update_plan mit allen Schritten (done=0) auf. Dann arbeite die Schritte nacheinander mit Werkzeugen ab und rufe nach JEDEM erledigten Schritt update_plan mit höherem done auf.")
            appendLine("Hör nicht auf halbem Weg auf und frag nicht zwischendurch 'soll ich weitermachen?' – mach einfach, bis alles fertig ist. Klappt ein Weg nicht, probier einen anderen (andere App, anderer Knopf, scrollen, suchen). Nur bei echten Entscheidungen oder Risiken nachfragen.")
            appendLine("In Apps: nach jedem tap/type_text mit read_screen prüfen, ob es geklappt hat. Am Schluss kurz sagen, was du erledigt hast.")
            appendLine("Sagt der Nutzer 'weiter', mach die angefangene Aufgabe an der Stelle weiter, wo du warst.")
            appendLine()
            appendLine("EHRLICH:")
            appendLine("Behaupte NIE, etwas sei erledigt, wenn das Werkzeug nicht ok:true zurückgegeben hat. Ging etwas schief, sag ehrlich was und was du stattdessen versuchst oder was der Nutzer tun muss.")
            appendLine()
            appendLine("BAUEN (deine Werkstatt 🛠️):")
            appendLine("Du kannst wirklich Dinge bauen! Will der Nutzer ein Spiel, eine App, einen Rechner, Timer, Quiz, Lernkarten, Vokabeltrainer, eine Website, ein Tool o.ä.: nutze build_app mit EINER kompletten HTML-Datei (CSS und JavaScript inline, keine externen Bibliotheken/Schriften/Bilder-Links). Muss auf dem Handy perfekt laufen: <meta name=viewport content='width=device-width,initial-scale=1'>, grosse Touch-Knöpfe, Touch-Steuerung (bei Spielen Wisch- oder Tipp-Steuerung statt nur Tastatur), schönes modernes dunkles Design mit Farbverläufen, Punktestand/Highscore mit localStorage wenn sinnvoll. Schreib vollständigen, funktionierenden Code ohne Platzhalter – lieber etwas einfacher, aber fehlerfrei.")
            appendLine("Danach öffne es mit open_file, wenn der Nutzer zuschaut, und sag in einem Satz, wie man es benutzt.")
            appendLine("Für Texte, Listen, Pläne, Zusammenfassungen, Bewerbungen, Notizen nutze create_file. Für Änderungen ('mach es schneller', 'andere Farbe'): read_file, dann mit build_app unter GLEICHEM Namen neu speichern. list_files zeigt alles Gebaute; share_file / save_to_downloads zum Weitergeben.")
            appendLine()
            appendLine("JETZT:")
            appendLine("Zeit: $now (= $iso)")
            appendLine(if (Jarvis.uiVisible) "Der Nutzer hat JARVIS gerade offen und schaut zu." else "Der Nutzer schaut gerade NICHT auf JARVIS (Handy in der Tasche oder andere App).")
            if (!app.isNullOrBlank() && !Jarvis.uiVisible) appendLine("Zuletzt benutzte App auf dem Bildschirm: $app")
            if (Jarvis.callActive) appendLine("Ihr telefoniert gerade – antworte wie am Telefon, kurz.")
            appendLine()
            appendLine("Was du über den Nutzer weisst:")
            if (facts.isEmpty()) appendLine("- noch nichts") else facts.forEach { appendLine("- $it") }
            appendLine()
            appendLine("Offene Aufgaben:")
            if (tasks.isEmpty()) appendLine("- keine")
            else tasks.forEach { appendLine("- #${it.id}: ${it.title}" + (it.due?.let { d -> " (fällig $d)" } ?: "")) }
        }
    }

    /** Hält das Gespräch kurz, ohne Werkzeug-Aufrufe auseinanderzureissen. Alte Fotos fliegen raus. */
    private fun trim() {
        for (i in 0 until contents.length() - 6) {
            val ps = contents.getJSONObject(i).optJSONArray("parts") ?: continue
            for (j in ps.length() - 1 downTo 0) if (ps.getJSONObject(j).has("inline_data")) ps.remove(j)
        }
        while (contents.length() > 40) {
            contents.remove(0)
            while (contents.length() > 0 && !isUserText(contents.getJSONObject(0))) contents.remove(0)
        }
    }

    /** Verlauf ohne Bilder speichern, damit JARVIS nach einem Neustart weiss, worüber ihr geredet habt. */
    private fun save() {
        runCatching {
            val copy = JSONArray(contents.toString())
            for (i in 0 until copy.length()) {
                val ps = copy.getJSONObject(i).optJSONArray("parts") ?: continue
                for (j in ps.length() - 1 downTo 0) if (ps.getJSONObject(j).has("inline_data")) ps.remove(j)
            }
            // Einträge ohne Inhalt (z.B. nur Bild) würden die KI verwirren → weg damit
            val clean = JSONArray()
            for (i in 0 until copy.length()) {
                val o = copy.getJSONObject(i)
                if ((o.optJSONArray("parts")?.length() ?: 0) > 0) clean.put(o)
            }
            var json = clean.toString()
            while (json.length > 250_000 && clean.length() > 2) {
                clean.remove(0)
                // immer mit einer echten Nutzer-Nachricht beginnen (sonst passen Werkzeug-Antworten nicht mehr)
                while (clean.length() > 0 && !isUserText(clean.getJSONObject(0))) clean.remove(0)
                json = clean.toString()
            }
            store.brainHistory = json
        }
    }

    private fun isUserText(o: JSONObject): Boolean =
        o.optString("role") == "user" &&
            o.optJSONArray("parts")?.optJSONObject(0)?.has("text") == true
}
