package ch.jarvis.app

import android.graphics.RectF
import android.provider.Settings
import org.json.JSONObject

/**
 * 🧭 Echter Anleitungs-Modus: JARVIS führt dich Schritt für Schritt zum Ziel.
 *   schauen → genau EINEN Knopf markieren + ansagen → warten, bis du's gemacht hast → wieder schauen …
 * Abbrechen: auf die JARVIS-Blase tippen oder die JARVIS-App öffnen.
 */
object Guide {
    @Volatile var cancelled = false
    @Volatile var running = false
        private set

    private fun ok(msg: String) = JSONObject().put("ok", true).put("result", msg)
    private fun err(msg: String) = JSONObject().put("ok", false).put("error", msg)

    fun run(store: Store, goal: String): JSONObject {
        if (ScreenAgent.instance == null) {
            return err("Für die Anleitung braucht JARVIS 'Apps bedienen & Bildschirm sehen' (🦾 Alles einrichten).")
        }
        if (!Settings.canDrawOverlays(Jarvis.app)) {
            return err("Zum Markieren braucht JARVIS 'Blase über anderen Apps' (🦾 Alles einrichten).")
        }
        cancelled = false
        running = true
        val history = mutableListOf<String>()
        try {
            var lastSay = ""
            var repeats = 0
            for (step in 1..20) {
                if (cancelled) return stop("Anleitung abgebrochen")

                // 1) Schauen: Bedienelemente + Bild
                Jarvis.clearHighlights()
                val elements = ScreenAgent.readScreen().optString("elements")
                Jarvis.hideOverlayForCapture()
                val shot = runCatching { CameraEye.encode(ScreenAgent.captureScreen()) }.getOrNull()
                val bmpSize = ScreenAgent.lastShotSize

                // 2) Nächsten Schritt bestimmen
                val plan = Web.guideStep(store, goal, history, elements, shot)
                val say = plan.optString("say").ifBlank { "Schau mal hier." }
                if (plan.optBoolean("done")) {
                    Jarvis.clearHighlights()
                    Jarvis.sayNow(say)
                    return stop("Ziel erreicht nach ${history.size} Schritten")
                }

                // Gleiche Anweisung zu oft? Dann stimmt wohl was nicht.
                repeats = if (say == lastSay) repeats + 1 else 0
                lastSay = say
                if (repeats >= 2) {
                    Jarvis.sayNow("Hier komme ich nicht weiter. Schau's dir kurz selbst an, oder frag mich nochmal anders.")
                    return stop("Feststeckt bei: $say")
                }

                // 3) Markieren: lieber exaktes Element, sonst Position aus dem Bild
                val label = plan.optString("label").ifBlank { "Hier" }
                var mark: Highlighter.Mark? = null
                if (plan.has("element") && !plan.isNull("element")) {
                    ScreenAgent.boundsOf(plan.optInt("element"))?.let { mark = Highlighter.Mark(RectF(it), label) }
                }
                val box = plan.optJSONArray("box_2d")
                if (mark == null && box != null && box.length() == 4 && bmpSize != null) {
                    val (w, h) = bmpSize
                    mark = Highlighter.Mark(RectF(
                        (box.optDouble(1) / 1000.0 * w).toFloat(), (box.optDouble(0) / 1000.0 * h).toFloat(),
                        (box.optDouble(3) / 1000.0 * w).toFloat(), (box.optDouble(2) / 1000.0 * h).toFloat(),
                    ), label)
                }
                mark?.let { Jarvis.highlight(listOf(it), 120) }

                // 4) Ansagen (Blase zeigt den Text zusätzlich)
                Jarvis.sayNow(say)
                history.add(say)

                // 5) Auf den Nutzer warten – einmal erinnern, dann pausieren
                if (!ScreenAgent.changedWithin(45) { cancelled }) {
                    if (cancelled) return stop("Anleitung abgebrochen")
                    Jarvis.sayNow("Ich warte noch auf dich. $say")
                    if (!ScreenAgent.changedWithin(60) { cancelled }) {
                        return stop(if (cancelled) "Anleitung abgebrochen" else "Nutzer hat nicht reagiert – Anleitung pausiert bei: $say")
                    }
                }
            }
            return stop("Viele Schritte geschafft – Rest kann der Nutzer selbst")
        } finally {
            running = false
            Jarvis.clearHighlights()
        }
    }

    private fun stop(msg: String): JSONObject {
        running = false
        Jarvis.clearHighlights()
        return ok(msg)
    }
}
