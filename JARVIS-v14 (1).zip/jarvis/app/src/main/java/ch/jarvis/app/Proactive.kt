package ch.jarvis.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * 🧠 Mitdenken: JARVIS schaut von selbst nach dir.
 *  - Tagsüber etwa alle 3 Stunden ein kurzer Check (ruft nur bei wirklich Wichtigem an)
 *  - Abends zur Wunschzeit ein Abend-Check ("Akku laden?", "Morgen früh Termin!", "Update?")
 */
object Proactive {
    private const val ACTION_DAY = "ch.jarvis.app.CHECK_DAY"
    private const val ACTION_EVENING = "ch.jarvis.app.CHECK_EVENING"
    private const val DAY_START = 8
    private const val DAY_END = 20

    private fun pending(ctx: Context, action: String, code: Int) = PendingIntent.getBroadcast(
        ctx, code, Intent(ctx, ProactiveReceiver::class.java).setAction(action),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    /** Plant die nächsten Checks (oder löscht sie, wenn Mitdenken aus ist). */
    fun schedule(ctx: Context) {
        val store = Store(ctx)
        val am = ctx.getSystemService(AlarmManager::class.java)
        val day = pending(ctx, ACTION_DAY, 6001)
        val evening = pending(ctx, ACTION_EVENING, 6002)
        am.cancel(day)
        am.cancel(evening)
        if (!store.proactiveEnabled) return

        // Abend-Check: täglich zur eingestellten Zeit
        val ev = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, store.eveningHour)
            set(Calendar.MINUTE, store.eveningMinute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis() + 5_000) add(Calendar.DAY_OF_YEAR, 1)
        }
        ReminderReceiver.scheduleAt(ctx, ev.timeInMillis, evening)

        // Tages-Check: in ~3 Stunden, aber nur zwischen 8 und 20 Uhr (ungenau reicht, spart Akku)
        val next = Calendar.getInstance().apply { add(Calendar.HOUR_OF_DAY, 3) }
        val h = next.get(Calendar.HOUR_OF_DAY)
        if (h < DAY_START || h >= DAY_END) {
            if (h >= DAY_END) next.add(Calendar.DAY_OF_YEAR, 1)
            next.set(Calendar.HOUR_OF_DAY, DAY_START)
            next.set(Calendar.MINUTE, 30)
        }
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.timeInMillis, day)
    }

    fun prompt(evening: Boolean): String {
        val now = SimpleDateFormat("EEEE HH:mm", Locale.GERMAN).format(Date())
        val visible = if (Jarvis.uiVisible) "Der Nutzer hat JARVIS gerade offen." else "Der Nutzer schaut gerade NICHT auf JARVIS."
        return if (evening) {
            "[Automatischer Abend-Check, $now. $visible Der Nutzer hat nichts gefragt.] " +
                "Er geht bald schlafen. Prüfe kurz: battery_status, get_calendar_events (days=2), list_tasks, read_notifications. " +
                "Gibt es etwas, das er HEUTE noch tun oder entscheiden sollte (Handy laden wenn Akku unter 40 % und nicht am Laden, " +
                "frühen Termin oder Schule morgen → Wecker?, Aufgabe morgen fällig, wichtige unbeantwortete Nachricht)? " +
                "Dann ruf ihn mit call_me an – der Grund kurz und konkret, gern auch die Frage, ob du nach Updates schauen sollst. " +
                "Wenn nichts Wichtiges ist, ruf NICHT an und antworte exakt: OK"
        } else {
            "[Automatischer Mitdenk-Check, $now. $visible Der Nutzer hat nichts gefragt.] " +
                "Prüfe kurz: battery_status, get_calendar_events (days=1), list_tasks, read_notifications. " +
                "Ruf NUR mit call_me an, wenn es wirklich wichtig und dringend ist: Termin in weniger als 90 Minuten, den er " +
                "vergessen könnte; Akku unter 15 % und bald ein Termin; dringende oder wichtige unbeantwortete Nachricht; " +
                "Aufgabe heute fällig und noch offen. Im Zweifel NICHT anrufen. Wenn nichts ist, antworte exakt: OK"
        }
    }

    fun isEvening(action: String?) = action == ACTION_EVENING
}

class ProactiveReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        Jarvis.init(ctx)
        Proactive.schedule(ctx) // nächste Checks planen
        val store = Jarvis.store
        if (!store.proactiveEnabled || store.apiKey.isBlank()) return
        // Nicht stören, wenn JARVIS gerade beschäftigt ist oder telefoniert
        if (Jarvis.phase != Phase.IDLE || Jarvis.callActive) return
        val result = goAsync()
        CoroutineScope(SupervisorJob() + Dispatchers.Main).launch {
            try {
                withTimeoutOrNull(55_000) { Jarvis.thinkInBackground(Proactive.prompt(Proactive.isEvening(intent.action))) }
            } finally {
                result.finish()
            }
        }
    }
}
