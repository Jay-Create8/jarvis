package ch.jarvis.app

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException

/** Google-Studio-Stimmen (z.B. "Charon") für JARVIS. Liefert rohes PCM-Audio (24 kHz, 16 Bit, mono). */
object GeminiTts {

    private val MODELS = listOf(
        "gemini-3.8-flash-tts", "gemini-3.8-flash-lite-tts",
        "gemini-3.1-flash-tts-preview", "gemini-2.5-flash-preview-tts",
    )

    /** Stimmen zur Auswahl: Name → Beschreibung */
    val VOICES = listOf(
        "Charon" to "sachlich, ruhig (JARVIS-Tipp)",
        "Orus" to "bestimmt, tief",
        "Iapetus" to "klar",
        "Algieba" to "sanft",
        "Sadaltager" to "wissend",
        "Gacrux" to "reif",
        "Fenrir" to "lebhaft",
        "Puck" to "fröhlich",
        "Kore" to "bestimmt, weiblich",
        "Aoede" to "locker, weiblich",
    )

    /** Nach einem harten Fehler (kein Gratis-Kontingent o.ä.) eine Weile direkt die Handy-Stimme nehmen. */
    @Volatile private var pauseUntil = 0L

    fun synthesize(store: Store, text: String): ByteArray {
        if (System.currentTimeMillis() < pauseUntil) throw IOException("KI-Stimme pausiert")
        val models = (listOf(store.ttsModel).filter { it.isNotBlank() } + MODELS).distinct()
        var last: Exception? = null
        for (m in models) {
            for (shape in 0..1) {
                try {
                    val pcm = request(store, m, text, shape)
                    if (store.ttsModel != m) store.ttsModel = m
                    return pcm
                } catch (e: Gemini.HttpFail) {
                    last = e
                    if (e.code == 400 && shape == 0) continue // andere Anfrage-Form probieren
                    break
                } catch (e: Exception) {
                    last = e
                    break
                }
            }
        }
        pauseUntil = System.currentTimeMillis() + 10 * 60_000L
        throw IOException("KI-Stimme nicht verfügbar: ${last?.message}")
    }

    private fun request(store: Store, model: String, text: String, shape: Int): ByteArray {
        val voiceConfig = if (shape == 0) {
            JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", store.aiVoice))
        } else {
            JSONObject().put("voice", store.aiVoice)
        }
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("role", "user")
                .put("parts", JSONArray().put(JSONObject().put("text", text)))))
            .put("generationConfig", JSONObject()
                .put("responseModalities", JSONArray().put("AUDIO"))
                .put("speechConfig", JSONObject().put("voiceConfig", voiceConfig)))
        val resp = JSONObject(Gemini.post(store, model, body))
        val parts = resp.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
            ?: throw IOException("Kein Audio erhalten")
        for (i in 0 until parts.length()) {
            val p = parts.getJSONObject(i)
            val data = (p.optJSONObject("inlineData") ?: p.optJSONObject("inline_data"))?.optString("data")
            if (!data.isNullOrBlank()) return stripWavHeader(Base64.decode(data, Base64.DEFAULT))
        }
        throw IOException("Kein Audio erhalten")
    }

    /** Neuere Modelle liefern WAV, ältere rohes PCM – wir brauchen rohes PCM. */
    private fun stripWavHeader(b: ByteArray): ByteArray {
        if (b.size < 44 || b[0] != 'R'.code.toByte() || b[1] != 'I'.code.toByte() ||
            b[2] != 'F'.code.toByte() || b[3] != 'F'.code.toByte()
        ) return b
        var i = 12
        while (i + 8 <= b.size) {
            val id = String(b, i, 4, Charsets.US_ASCII)
            val len = (b[i + 4].toInt() and 0xFF) or ((b[i + 5].toInt() and 0xFF) shl 8) or
                ((b[i + 6].toInt() and 0xFF) shl 16) or ((b[i + 7].toInt() and 0xFF) shl 24)
            if (id == "data") {
                val start = i + 8
                val end = if (len <= 0 || start + len > b.size) b.size else start + len
                return b.copyOfRange(start, end)
            }
            i += 8 + len
        }
        return b.copyOfRange(44, b.size)
    }
}
