package ch.jarvis.app

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

/**
 * 📞 JARVIS ruft dich an: klingelt mit Vollbild-Anruf (auch auf dem Sperrbildschirm).
 * Annehmen → JARVIS redet mit dir wie am Telefon.
 */
object JarvisCall {
    const val EXTRA_REASON = "reason"
    private const val NOTIF_ID = 5150

    fun canRingFullScreen(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 34 || ctx.getSystemService(NotificationManager::class.java).canUseFullScreenIntent()

    /** Klingelt jetzt. */
    fun ring(ctx: Context, reason: String) {
        Jarvis.init(ctx)
        val callIntent = Intent(ctx, CallActivity::class.java)
            .putExtra(EXTRA_REASON, reason)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)

        // App gerade offen? Dann direkt den Anruf-Bildschirm zeigen.
        if (Jarvis.uiVisible) {
            ctx.startActivity(callIntent)
            return
        }
        if (!Jarvis.canNotify()) return
        val full = PendingIntent.getActivity(ctx, 51, callIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = Notification.Builder(ctx, Jarvis.CH_CALL)
            .setSmallIcon(R.drawable.ic_notify)
            .setContentTitle("📞 JARVIS ruft an")
            .setContentText(reason)
            .setCategory(Notification.CATEGORY_CALL)
            .setFullScreenIntent(full, true)
            .setContentIntent(full)
            .setOngoing(true)
            .setAutoCancel(true)
            .setTimeoutAfter(60_000)
            .build()
        ctx.getSystemService(NotificationManager::class.java).notify(NOTIF_ID, n)
    }

    fun dismissNotification(ctx: Context) {
        ctx.getSystemService(NotificationManager::class.java).cancel(NOTIF_ID)
    }

    fun missed(ctx: Context, reason: String) {
        dismissNotification(ctx)
        if (!Jarvis.canNotify()) return
        val n = Notification.Builder(ctx, Jarvis.CH_REMINDER)
            .setSmallIcon(R.drawable.ic_notify)
            .setContentTitle("📵 Verpasster Anruf von JARVIS")
            .setContentText(reason)
            .setStyle(Notification.BigTextStyle().bigText(reason))
            .setContentIntent(Jarvis.openAppIntent())
            .setAutoCancel(true)
            .build()
        ctx.getSystemService(NotificationManager::class.java).notify(NOTIF_ID + 1, n)
    }

    /** Plant einen Anruf für später. */
    fun schedule(ctx: Context, time: Long, reason: String) {
        val pi = PendingIntent.getBroadcast(
            ctx, (time / 1000).toInt(),
            Intent(ctx, CallReceiver::class.java).putExtra(EXTRA_REASON, reason),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        ReminderReceiver.scheduleAt(ctx, time, pi)
    }
}

class CallReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        JarvisCall.ring(ctx, intent.getStringExtra(JarvisCall.EXTRA_REASON) ?: "Ich wollte mich kurz melden")
    }
}
