package ch.jarvis.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Internetwissen (Google-Suche über Gemini) und Wetter (Open-Meteo, gratis, ohne Key). */
object Web {

    private fun http(url: String, body: String? = null, headers: Map<String, String> = emptyMap()): String {
        val con = URL(url).openConnection() as HttpURLConnection
        con.connectTimeout = 15_000
        con.readTimeout = 60_000
        headers.forEach { (k, v) -> con.setRequestProperty(k, v) }
        if (body != null) {
            con.requestMethod = "POST"
            con.doOutput = true
            con.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            con.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        }
        val code = con.responseCode
        val txt = (if (code in 200..299) con.inputStream else con.errorStream)
            ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
        if (code !in 200..299) {
            val msg = runCatching { JSONObject(txt).getJSONObject("error").getString("message") }.getOrDefault(txt.take(200))
            throw IOException("HTTP $code: $msg")
        }
        return txt
    }

    /** Fragt Gemini mit eingeschalteter Google-Suche und gibt Antwort + Quellen zurück. */
    fun internetSearch(store: Store, query: String): JSONObject {
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(
                JSONObject().put("text", "Recherchiere aktuell im Internet und beantworte knapp und faktenbasiert auf Deutsch: $query")))))
            .put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
        val resp = Gemini.generate(store, body)
        val cand = resp.optJSONArray("candidates")?.optJSONObject(0)
            ?: return JSONObject().put("ok", false).put("error", "Keine Antwort von der Suche")
        val parts = cand.optJSONObject("content")?.optJSONArray("parts") ?: JSONArray()
        val text = buildString {
            for (i in 0 until parts.length()) {
                val p = parts.getJSONObject(i)
                if (!p.optBoolean("thought")) append(p.optString("text"))
            }
        }
        val sources = JSONArray()
        cand.optJSONObject("groundingMetadata")?.optJSONArray("groundingChunks")?.let { chunks ->
            for (i in 0 until minOf(chunks.length(), 5)) {
                chunks.optJSONObject(i)?.optJSONObject("web")?.let { sources.put(it.optString("title")) }
            }
        }
        return JSONObject().put("answer", text.trim()).put("sources", sources)
    }

    /** Zeigt der KI ein Bild und stellt eine Frage dazu ("Augen" von JARVIS). */
    fun describeImage(store: Store, jpegBase64: String, question: String, source: String): JSONObject {
        val prompt = "Du bist die Augen des Sprachassistenten JARVIS. Das Bild stammt von: $source. " +
            "Beantworte auf Deutsch, konkret und hilfreich (Text im Bild wörtlich lesen, Objekte/Pflanzen/Tiere/Produkte " +
            "benennen, bei Aufgaben den Lösungsweg erklären): $question"
        val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray()
            .put(JSONObject().put("text", prompt))
            .put(JSONObject().put("inline_data", JSONObject().put("mime_type", "image/jpeg").put("data", jpegBase64))))))
        val resp = Gemini.generate(store, body)
        val parts = resp.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
            ?: return JSONObject().put("ok", false).put("error", "Bild konnte nicht ausgewertet werden")
        val text = buildString {
            for (i in 0 until parts.length()) {
                val p = parts.getJSONObject(i)
                if (!p.optBoolean("thought")) append(p.optString("text"))
            }
        }
        return JSONObject().put("ok", true).put("seen", text.trim())
    }

    /**
     * Sucht Dinge auf einem Bild und gibt ihre Position zurück (für das Markieren).
     * Ergebnis: Liste von (ymin, xmin, ymax, xmax) normiert auf 0..1000 plus Beschriftung.
     */
    fun findBoxes(store: Store, jpegBase64: String, what: String): List<Pair<DoubleArray, String>> {
        val prompt = "Finde auf diesem Handy-Bildschirmfoto: $what\n" +
            "Antworte NUR mit einer JSON-Liste (höchstens 5 Einträge) in diesem Format: " +
            "[{\"box_2d\": [ymin, xmin, ymax, xmax], \"label\": \"kurze deutsche Beschriftung\"}] " +
            "mit Koordinaten normiert auf 0 bis 1000. Ist es nicht zu sehen, antworte mit []."
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray()
                .put(JSONObject().put("inline_data", JSONObject().put("mime_type", "image/jpeg").put("data", jpegBase64)))
                .put(JSONObject().put("text", prompt)))))
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
        val resp = Gemini.generate(store, body)
        val parts = resp.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
            ?: return emptyList()
        val raw = buildString {
            for (i in 0 until parts.length()) {
                val p = parts.getJSONObject(i)
                if (!p.optBoolean("thought")) append(p.optString("text"))
            }
        }.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val arr = runCatching {
            if (raw.startsWith("{")) JSONArray().put(JSONObject(raw)) else JSONArray(raw)
        }.getOrDefault(JSONArray())
        val out = mutableListOf<Pair<DoubleArray, String>>()
        for (i in 0 until minOf(arr.length(), 5)) {
            val o = arr.optJSONObject(i) ?: continue
            val b = o.optJSONArray("box_2d") ?: continue
            if (b.length() != 4) continue
            out.add(DoubleArray(4) { b.optDouble(it) } to o.optString("label"))
        }
        return out
    }

    /**
     * Anleitungs-Modus: Bestimmt den EINEN nächsten Schritt, den der Nutzer selbst machen soll.
     * Ergebnis-JSON: done, say, element, box_2d, label
     */
    fun guideStep(store: Store, goal: String, history: List<String>, elements: String, jpegBase64: String?): JSONObject {
        val prompt = buildString {
            append("Du bist JARVIS im ANLEITUNGS-MODUS. Du führst den Nutzer Schritt für Schritt – ER tippt selbst, du zeigst nur.\n")
            append("Ziel des Nutzers: $goal\n")
            if (history.isNotEmpty()) {
                append("Bisherige Anweisungen (wurden schon befolgt):\n")
                history.takeLast(8).forEachIndexed { i, h -> append("${i + 1}. $h\n") }
            }
            append("\nBedienelemente auf dem Bildschirm jetzt ([Nummer] Typ \"Beschriftung\"):\n")
            append(elements.take(7000))
            append("\n\nBestimme GENAU EINEN nächsten Schritt. Antworte NUR mit JSON:\n")
            append("{\"done\": false, \"say\": \"kurze Anweisung auf Deutsch, max. 15 Wörter, z.B. Tippe oben rechts auf das Zahnrad\", ")
            append("\"element\": Nummer aus der Liste oder null, ")
            append("\"box_2d\": [ymin, xmin, ymax, xmax] auf 0-1000 normiert, nur wenn kein passendes Element in der Liste ist, ")
            append("\"label\": \"1-3 Wörter für die Markierung\"}\n")
            append("done=true, wenn das Ziel schon erreicht ist (dann in say kurz loben). ")
            append("Muss etwas eingetippt werden, sag genau was. Muss gescrollt werden, sag wohin. ")
            append("Bei Passwörtern/Codes nur sagen, wo er sie eingeben soll.")
        }
        val parts = JSONArray().put(JSONObject().put("text", prompt))
        if (jpegBase64 != null) {
            parts.put(JSONObject().put("inline_data", JSONObject().put("mime_type", "image/jpeg").put("data", jpegBase64)))
        }
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
        val resp = Gemini.generate(store, body)
        val rp = resp.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
            ?: return JSONObject().put("say", "Ich sehe gerade nichts – versuch's gleich nochmal.")
        val raw = buildString {
            for (i in 0 until rp.length()) {
                val p = rp.getJSONObject(i)
                if (!p.optBoolean("thought")) append(p.optString("text"))
            }
        }.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        return runCatching {
            if (raw.startsWith("[")) JSONArray(raw).getJSONObject(0) else JSONObject(raw)
        }.getOrDefault(JSONObject().put("say", raw.take(120)))
    }

    @Suppress("MissingPermission")
    fun lastLocation(ctx: Context): Location? {
        val fine = ctx.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = ctx.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!fine && !coarse) return null
        val lm = ctx.getSystemService(LocationManager::class.java)
        return lm.getProviders(true).mapNotNull { runCatching { lm.getLastKnownLocation(it) }.getOrNull() }
            .maxByOrNull { it.time }
    }

    /** Ort → Koordinaten (Städte, Dörfer). */
    fun geocodeCity(name: String): Triple<Double, Double, String>? {
        val o = JSONObject(http("https://geocoding-api.open-meteo.com/v1/search?count=1&language=de&name=" + Uri.encode(name)))
        val r = o.optJSONArray("results")?.optJSONObject(0) ?: return null
        return Triple(r.getDouble("latitude"), r.getDouble("longitude"),
            r.optString("name") + (r.optString("country").takeIf { it.isNotBlank() }?.let { ", $it" } ?: ""))
    }

    fun weather(ctx: Context, place: String?): JSONObject {
        val (lat, lon, label) = if (!place.isNullOrBlank()) {
            geocodeCity(place) ?: return JSONObject().put("ok", false).put("error", "Ort '$place' nicht gefunden")
        } else {
            val loc = lastLocation(ctx)
                ?: return JSONObject().put("ok", false).put("error", "Standort unbekannt (Berechtigung fehlt?) – frag nach dem Ort")
            Triple(loc.latitude, loc.longitude, "aktueller Standort")
        }
        val o = JSONObject(http("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
            "&current=temperature_2m,apparent_temperature,weather_code,wind_speed_10m,precipitation" +
            "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,sunrise,sunset" +
            "&hourly=temperature_2m,precipitation_probability,weather_code&forecast_hours=12" +
            "&timezone=auto&forecast_days=3"))
        val cur = o.getJSONObject("current")
        val out = JSONObject().put("place", label)
            .put("now", JSONObject()
                .put("temp_c", cur.optDouble("temperature_2m"))
                .put("feels_like_c", cur.optDouble("apparent_temperature"))
                .put("condition", wmo(cur.optInt("weather_code")))
                .put("wind_kmh", cur.optDouble("wind_speed_10m"))
                .put("precipitation_mm", cur.optDouble("precipitation")))
        val d = o.getJSONObject("daily")
        val days = JSONArray()
        for (i in 0 until d.getJSONArray("time").length()) {
            days.put(JSONObject()
                .put("date", d.getJSONArray("time").getString(i))
                .put("condition", wmo(d.getJSONArray("weather_code").optInt(i)))
                .put("max_c", d.getJSONArray("temperature_2m_max").optDouble(i))
                .put("min_c", d.getJSONArray("temperature_2m_min").optDouble(i))
                .put("rain_chance_pct", d.getJSONArray("precipitation_probability_max").optInt(i))
                .put("sunset", d.getJSONArray("sunset").optString(i).substringAfter("T")))
        }
        out.put("days", days)
        val h = o.getJSONObject("hourly")
        val hours = JSONArray()
        val times = h.getJSONArray("time")
        for (i in 0 until times.length() step 2) {
            hours.put("${times.getString(i).substringAfter("T")}: ${h.getJSONArray("temperature_2m").optDouble(i)}°C, " +
                "Regen ${h.getJSONArray("precipitation_probability").optInt(i)}%, ${wmo(h.getJSONArray("weather_code").optInt(i))}")
        }
        return out.put("next_hours", hours)
    }

    private fun wmo(code: Int): String = when (code) {
        0 -> "klar"
        1 -> "überwiegend klar"
        2 -> "teilweise bewölkt"
        3 -> "bedeckt"
        45, 48 -> "Nebel"
        51, 53, 55 -> "Nieselregen"
        56, 57 -> "gefrierender Nieselregen"
        61 -> "leichter Regen"
        63 -> "Regen"
        65 -> "starker Regen"
        66, 67 -> "gefrierender Regen"
        71 -> "leichter Schneefall"
        73 -> "Schneefall"
        75 -> "starker Schneefall"
        77 -> "Schneegriesel"
        80, 81 -> "Regenschauer"
        82 -> "heftige Regenschauer"
        85, 86 -> "Schneeschauer"
        95 -> "Gewitter"
        96, 99 -> "Gewitter mit Hagel"
        else -> "Code $code"
    }
}
