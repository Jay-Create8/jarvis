package ch.jarvis.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Speichert Einstellungen, Gedächtnis (Fakten) und Aufgaben lokal auf dem Handy. */
class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("jarvis", Context.MODE_PRIVATE)

    companion object {
        const val DEFAULT_MODEL = "gemini-flash-latest"
    }

    var apiKey: String
        get() = p.getString("apiKey", "") ?: ""
        set(v) { p.edit().putString("apiKey", v.trim()).apply() }

    var model: String
        get() = (p.getString("model", DEFAULT_MODEL) ?: DEFAULT_MODEL).ifBlank { DEFAULT_MODEL }
        set(v) { p.edit().putString("model", v.trim()).apply() }

    var userName: String
        get() = p.getString("userName", "") ?: ""
        set(v) { p.edit().putString("userName", v.trim()).apply() }

    var conversationMode: Boolean
        get() = p.getBoolean("convo", false)
        set(v) { p.edit().putBoolean("convo", v).apply() }

    var muted: Boolean
        get() = p.getBoolean("muted", false)
        set(v) { p.edit().putBoolean("muted", v).apply() }

    var setupShown: Boolean
        get() = p.getBoolean("setupShown", false)
        set(v) { p.edit().putBoolean("setupShown", v).apply() }

    var lastBriefing: String
        get() = p.getString("lastBriefing", "") ?: ""
        set(v) { p.edit().putString("lastBriefing", v).apply() }

    // ---------- Wake-Word ----------
    var wakeEnabled: Boolean
        get() = p.getBoolean("wake", false)
        set(v) { p.edit().putBoolean("wake", v).apply() }

    var wakeSensitivity: Float
        get() = p.getFloat("wakeSens", 0.5f)
        set(v) { p.edit().putFloat("wakeSens", v.coerceIn(0.1f, 0.95f)).apply() }

    // ---------- Morgen-Briefing & Nachrichten ----------
    var briefingEnabled: Boolean
        get() = p.getBoolean("briefing", false)
        set(v) { p.edit().putBoolean("briefing", v).apply() }

    var briefingHour: Int
        get() = p.getInt("briefingHour", 7)
        set(v) { p.edit().putInt("briefingHour", v.coerceIn(0, 23)).apply() }

    var briefingMinute: Int
        get() = p.getInt("briefingMinute", 0)
        set(v) { p.edit().putInt("briefingMinute", v.coerceIn(0, 59)).apply() }

    var briefingSpeak: Boolean
        get() = p.getBoolean("briefingSpeak", false)
        set(v) { p.edit().putBoolean("briefingSpeak", v).apply() }

    var announceMessages: Boolean
        get() = p.getBoolean("announce", false)
        set(v) { p.edit().putBoolean("announce", v).apply() }

    // ---------- 🗣️ Stimme ----------
    /** "ai" = Google-Studio-Stimme (fällt automatisch auf die Handy-Stimme zurück), "phone" = Handy-Stimme */
    var voiceMode: String
        get() = p.getString("voiceMode", "ai") ?: "ai"
        set(v) { p.edit().putString("voiceMode", v).apply() }

    var aiVoice: String
        get() = p.getString("aiVoice", "Charon") ?: "Charon"
        set(v) { p.edit().putString("aiVoice", v).apply() }

    /** Welches TTS-Modell zuletzt funktioniert hat (wird automatisch gemerkt). */
    var ttsModel: String
        get() = p.getString("ttsModel", "") ?: ""
        set(v) { p.edit().putString("ttsModel", v).apply() }

    var phoneVoice: String
        get() = p.getString("phoneVoice", "") ?: ""
        set(v) { p.edit().putString("phoneVoice", v).apply() }

    var speechRate: Float
        get() = p.getFloat("speechRate", 1.05f)
        set(v) { p.edit().putFloat("speechRate", v.coerceIn(0.5f, 2f)).apply() }

    var speechPitch: Float
        get() = p.getFloat("speechPitch", 0.9f)
        set(v) { p.edit().putFloat("speechPitch", v.coerceIn(0.5f, 1.5f)).apply() }

    // ---------- 🧠 Mitdenken ----------
    var proactiveEnabled: Boolean
        get() = p.getBoolean("proactive", true)
        set(v) { p.edit().putBoolean("proactive", v).apply() }

    var eveningHour: Int
        get() = p.getInt("eveningHour", 21)
        set(v) { p.edit().putInt("eveningHour", v.coerceIn(0, 23)).apply() }

    var eveningMinute: Int
        get() = p.getInt("eveningMinute", 0)
        set(v) { p.edit().putInt("eveningMinute", v.coerceIn(0, 59)).apply() }

    // ---------- 📞 Wann JARVIS anrufen soll ----------
    var callOnUrgent: Boolean
        get() = p.getBoolean("callUrgent", true)
        set(v) { p.edit().putBoolean("callUrgent", v).apply() }

    /** Regel: anrufen, wenn eine Nachricht von [from] kommt und/oder [keyword] enthält. */
    data class CallTrigger(val id: Int, val from: String, val keyword: String)

    fun callTriggers(): List<CallTrigger> {
        val arr = JSONArray(p.getString("callTriggers", "[]"))
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            CallTrigger(o.getInt("id"), o.optString("from"), o.optString("keyword"))
        }
    }

    private fun saveCallTriggers(list: List<CallTrigger>) {
        p.edit().putString("callTriggers", JSONArray(list.map {
            JSONObject().put("id", it.id).put("from", it.from).put("keyword", it.keyword)
        }).toString()).apply()
    }

    fun addCallTrigger(from: String, keyword: String): CallTrigger {
        val list = callTriggers()
        val t = CallTrigger((list.maxOfOrNull { it.id } ?: 0) + 1, from.trim(), keyword.trim())
        saveCallTriggers(list + t)
        return t
    }

    fun removeCallTrigger(id: Int): Boolean {
        val list = callTriggers()
        if (list.none { it.id == id }) return false
        saveCallTriggers(list.filterNot { it.id == id })
        return true
    }

    // ---------- Orts-Erinnerungen ----------
    data class PlaceReminder(val id: String, val text: String, val place: String, val lat: Double, val lon: Double)

    fun placeReminders(): List<PlaceReminder> {
        val arr = JSONArray(p.getString("placeReminders", "[]"))
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            PlaceReminder(o.getString("id"), o.getString("text"), o.getString("place"), o.getDouble("lat"), o.getDouble("lon"))
        }
    }

    private fun savePlaceReminders(list: List<PlaceReminder>) {
        p.edit().putString("placeReminders", JSONArray(list.map {
            JSONObject().put("id", it.id).put("text", it.text).put("place", it.place).put("lat", it.lat).put("lon", it.lon)
        }).toString()).apply()
    }

    fun addPlaceReminder(r: PlaceReminder) = savePlaceReminders(placeReminders().filterNot { it.id == r.id } + r)

    fun removePlaceReminder(id: String) = savePlaceReminders(placeReminders().filterNot { it.id == id })

    // ---------- Erinnerungen (überleben Neustarts) ----------
    data class Reminder(val id: Int, val text: String, val time: Long, val call: Boolean = false)

    fun reminders(): List<Reminder> {
        val arr = JSONArray(p.getString("reminders", "[]"))
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Reminder(o.getInt("id"), o.getString("text"), o.getLong("time"), o.optBoolean("call"))
        }
    }

    private fun saveReminders(list: List<Reminder>) {
        p.edit().putString("reminders", JSONArray(list.map {
            JSONObject().put("id", it.id).put("text", it.text).put("time", it.time).put("call", it.call)
        }).toString()).apply()
    }

    fun addReminder(r: Reminder) = saveReminders(reminders().filterNot { it.id == r.id } + r)

    fun removeReminder(id: Int) = saveReminders(reminders().filterNot { it.id == id })

    fun nextReminderId(): Int {
        val id = p.getInt("reminderId", 100) + 1
        p.edit().putInt("reminderId", id).apply()
        return id
    }

    // ---------- Gedächtnis ----------
    fun facts(): List<String> {
        val arr = JSONArray(p.getString("facts", "[]"))
        return (0 until arr.length()).map { arr.getString(it) }
    }

    private fun saveFacts(list: List<String>) {
        p.edit().putString("facts", JSONArray(list).toString()).apply()
    }

    fun addFact(fact: String) {
        val list = facts().toMutableList()
        if (list.none { it.equals(fact, ignoreCase = true) }) list.add(fact.trim())
        saveFacts(list.takeLast(150))
    }

    fun removeFacts(about: String): Int {
        val list = facts()
        val keep = list.filterNot { it.contains(about, ignoreCase = true) }
        saveFacts(keep)
        return list.size - keep.size
    }

    fun clearFacts() = saveFacts(emptyList())

    // ---------- Aufgaben ----------
    data class Task(val id: Long, val title: String, val due: String?, val done: Boolean) {
        fun toJson(): JSONObject = JSONObject()
            .put("id", id).put("title", title).put("due", due ?: "").put("done", done)
    }

    fun tasks(): List<Task> {
        val arr = JSONArray(p.getString("tasks", "[]"))
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Task(o.getLong("id"), o.getString("title"), o.optString("due").ifBlank { null }, o.optBoolean("done"))
        }
    }

    private fun saveTasks(list: List<Task>) {
        p.edit().putString("tasks", JSONArray(list.map { it.toJson() }).toString()).apply()
    }

    fun addTask(title: String, due: String?): Task {
        val list = tasks().toMutableList()
        val id = (list.maxOfOrNull { it.id } ?: 0L) + 1
        val t = Task(id, title.trim(), due, false)
        list.add(t)
        saveTasks(list)
        return t
    }

    fun setDone(id: Long): Boolean {
        val list = tasks()
        if (list.none { it.id == id }) return false
        saveTasks(list.map { if (it.id == id) it.copy(done = true) else it })
        return true
    }

    fun deleteTask(id: Long): Boolean {
        val list = tasks()
        if (list.none { it.id == id }) return false
        saveTasks(list.filterNot { it.id == id })
        return true
    }
}
