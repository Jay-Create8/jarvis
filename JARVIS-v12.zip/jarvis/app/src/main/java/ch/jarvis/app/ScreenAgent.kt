package ch.jarvis.app

import android.accessibilityservice.AccessibilityService
import android.graphics.Bitmap
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import org.json.JSONObject
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Bedienungshilfe: lässt JARVIS den Bildschirm "sehen" und andere Apps bedienen
 * (tippen, schreiben, scrollen, zurück …) – wie ein Mensch.
 */
class ScreenAgent : AccessibilityService() {

    companion object {
        @Volatile var instance: ScreenAgent? = null
            private set

        /** Grösse des letzten Bildschirmfotos (Breite, Höhe) – zum Umrechnen von Positionen. */
        @Volatile var lastShotSize: Pair<Int, Int>? = null
            private set

        /** Zeitpunkt der letzten Änderung auf dem Bildschirm (für den Anleitungs-Modus). */
        @Volatile private var lastChange = 0L
        @Volatile private var lastWindowPkg = ""

        /** Ziffer → Element vom letzten read_screen */
        private val nodes = HashMap<Int, AccessibilityNodeInfo>()

        private val BLOCKED = listOf("bank", "twint", "paypal", "postfinance", "com.ubs", "raiffeisen", "revolut", "neon",
            "wallet", ".pay", "1password", "bitwarden", "authenticator", "lastpass", "keepass")

        private fun err(msg: String) = JSONObject().put("ok", false).put("error", msg)
        private fun ok(msg: String) = JSONObject().put("ok", true).put("result", msg)

        private fun notReady() = err("Handy-Steuerung ist aus. Der Nutzer muss sie in JARVIS ⚙️ → Superkräfte einschalten.")

        fun readScreen(): JSONObject {
            val svc = instance ?: return notReady()
            val root = svc.rootInActiveWindow ?: return err("Bildschirm gerade nicht lesbar (gesperrt?)")
            val pkg = root.packageName?.toString().orEmpty()
            if (BLOCKED.any { pkg.contains(it, ignoreCase = true) }) {
                return err("Aus Sicherheitsgründen bediene ich keine Bank-, Bezahl- oder Passwort-Apps.")
            }
            synchronized(nodes) { nodes.clear() }
            val lines = StringBuilder()
            var counter = 0
            fun walk(n: AccessibilityNodeInfo?, depth: Int) {
                if (n == null || depth > 40 || counter >= 180) return
                if (!n.isVisibleToUser) return
                val text = n.text?.toString()?.trim().orEmpty()
                val desc = n.contentDescription?.toString()?.trim().orEmpty()
                val hint = if (Build.VERSION.SDK_INT >= 26) n.hintText?.toString().orEmpty() else ""
                val label = listOf(text, desc, hint).filter { it.isNotBlank() }.distinct().joinToString(" | ").take(120)
                val interesting = label.isNotBlank() || n.isEditable || n.isScrollable || n.isCheckable
                if (interesting) {
                    counter++
                    synchronized(nodes) { nodes[counter] = n }
                    val kind = n.className?.toString()?.substringAfterLast('.') ?: "View"
                    val flags = buildList {
                        if (n.isClickable) add("klickbar")
                        if (n.isEditable) add("Eingabefeld")
                        if (n.isScrollable) add("scrollbar")
                        if (n.isCheckable) add(if (n.isChecked) "an" else "aus")
                        if (n.isFocused) add("fokussiert")
                    }
                    lines.append("[$counter] $kind \"$label\"")
                    if (flags.isNotEmpty()) lines.append(" (${flags.joinToString()})")
                    lines.append('\n')
                }
                for (i in 0 until n.childCount) walk(n.getChild(i), depth + 1)
            }
            walk(root, 0)
            return JSONObject().put("app", pkg).put("elements", lines.toString().ifBlank { "(nichts Lesbares)" })
        }

        private fun node(id: Int): AccessibilityNodeInfo? = synchronized(nodes) { nodes[id] }

        /**
         * Wartet bis zu [timeoutMs], bis ein Knopf mit einer dieser View-IDs oder Beschriftungen
         * sichtbar ist, und tippt drauf (z.B. den Senden-Knopf in WhatsApp).
         */
        fun clickWhenVisible(viewIds: List<String>, labels: List<String>, timeoutMs: Long): Boolean {
            val until = System.currentTimeMillis() + timeoutMs
            while (System.currentTimeMillis() < until) {
                val root = instance?.rootInActiveWindow
                if (root != null) {
                    val byId = viewIds.firstNotNullOfOrNull { id ->
                        root.findAccessibilityNodeInfosByViewId(id)?.firstOrNull { it.isVisibleToUser }
                    }
                    val target = byId ?: labels.firstNotNullOfOrNull { l ->
                        root.findAccessibilityNodeInfosByText(l)?.firstOrNull {
                            it.isVisibleToUser && (it.contentDescription?.toString()?.equals(l, true) == true ||
                                it.text?.toString()?.equals(l, true) == true)
                        }
                    }
                    if (target != null) {
                        var n: AccessibilityNodeInfo? = target
                        while (n != null && !n.isClickable) n = n.parent
                        if ((n ?: target).performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                            Thread.sleep(600)
                            return true
                        }
                    }
                }
                Thread.sleep(300)
            }
            return false
        }

        /** Position eines Elements vom letzten read_screen auf dem Bildschirm. */
        fun boundsOf(id: Int): Rect? = node(id)?.let { n -> Rect().also { n.getBoundsInScreen(it) } }

        fun tap(id: Int?, text: String?): JSONObject {
            val svc = instance ?: return notReady()
            var target: AccessibilityNodeInfo? = id?.let { node(it) }
            if (target == null && !text.isNullOrBlank()) {
                target = svc.rootInActiveWindow?.findAccessibilityNodeInfosByText(text)?.firstOrNull { it.isVisibleToUser }
            }
            target ?: return err("Element nicht gefunden – erst read_screen aufrufen")
            var n: AccessibilityNodeInfo? = target
            while (n != null && !n.isClickable) n = n.parent
            val done = (n ?: target).performAction(AccessibilityNodeInfo.ACTION_CLICK)
            if (!done) {
                // Notlösung: an die Position tippen
                val r = Rect().also { target.getBoundsInScreen(it) }
                svc.tapAt(r.exactCenterX(), r.exactCenterY())
            }
            Thread.sleep(900)
            return ok("getippt")
        }

        fun longPress(id: Int): JSONObject {
            instance ?: return notReady()
            val n = node(id) ?: return err("Element nicht gefunden – erst read_screen aufrufen")
            n.performAction(AccessibilityNodeInfo.ACTION_LONG_CLICK)
            Thread.sleep(800)
            return ok("lange gedrückt")
        }

        fun type(id: Int?, text: String): JSONObject {
            val svc = instance ?: return notReady()
            val target = id?.let { node(it) }
                ?: svc.rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
                ?: return err("Kein Eingabefeld gefunden – erst read_screen und die Nummer des Felds angeben")
            target.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            val args = Bundle().apply {
                putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
            }
            val done = target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
            Thread.sleep(400)
            return if (done) ok("Text eingegeben") else err("Konnte hier keinen Text eingeben")
        }

        fun scroll(id: Int?, forward: Boolean): JSONObject {
            val svc = instance ?: return notReady()
            val target = id?.let { node(it) } ?: findScrollable(svc.rootInActiveWindow)
                ?: return err("Nichts Scrollbares gefunden")
            val done = target.performAction(
                if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)
            Thread.sleep(700)
            return if (done) ok("gescrollt") else err("Weiter geht's nicht")
        }

        private fun findScrollable(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
            if (n == null) return null
            if (n.isScrollable && n.isVisibleToUser) return n
            for (i in 0 until n.childCount) findScrollable(n.getChild(i))?.let { return it }
            return null
        }

        /**
         * Schaut sich den Bildschirm an – ohne dass ein Screenshot in der Galerie landet.
         * Blockiert kurz, darf nicht auf dem Haupt-Thread laufen.
         */
        fun captureScreen(): Bitmap {
            val svc = instance ?: throw IllegalStateException(
                "Bildschirm sehen braucht die Superkraft 'Apps bedienen' (⚙️ → Superkräfte)")
            if (Build.VERSION.SDK_INT < 30) throw IllegalStateException("Bildschirm sehen geht erst ab Android 11")
            val pkg = svc.rootInActiveWindow?.packageName?.toString().orEmpty()
            if (BLOCKED.any { pkg.contains(it, ignoreCase = true) }) {
                throw IllegalStateException("Aus Sicherheitsgründen schaue ich nicht in Bank-, Bezahl- oder Passwort-Apps.")
            }
            val latch = CountDownLatch(1)
            var bmp: Bitmap? = null
            var error: String? = null
            svc.takeScreenshot(Display.DEFAULT_DISPLAY, svc.mainExecutor, object : AccessibilityService.TakeScreenshotCallback {
                override fun onSuccess(result: AccessibilityService.ScreenshotResult) {
                    try {
                        val hw = Bitmap.wrapHardwareBuffer(result.hardwareBuffer, result.colorSpace)
                        bmp = hw?.copy(Bitmap.Config.ARGB_8888, false)
                    } catch (e: Exception) {
                        error = e.message
                    } finally {
                        result.hardwareBuffer.close()
                        latch.countDown()
                    }
                }

                override fun onFailure(errorCode: Int) {
                    error = when (errorCode) {
                        AccessibilityService.ERROR_TAKE_SCREENSHOT_INTERVAL_TIME_SHORT -> "Zu schnell hintereinander, gleich nochmal versuchen"
                        AccessibilityService.ERROR_TAKE_SCREENSHOT_SECURE_WINDOW -> "Diese App erlaubt kein Mitschauen (geschützt)"
                        else -> "Bildschirm konnte nicht gelesen werden ($errorCode)"
                    }
                    latch.countDown()
                }
            })
            if (!latch.await(5, TimeUnit.SECONDS)) throw IllegalStateException("Bildschirm hat nicht geantwortet")
            val result = bmp ?: throw IllegalStateException(error ?: "Bildschirm konnte nicht gelesen werden")
            lastShotSize = result.width to result.height
            return result
        }

        /**
         * Wartet, bis sich der Bildschirm ändert (z.B. weil der Nutzer getippt hat).
         * Für den Anleitungs-Modus: markieren → warten → nächster Schritt.
         */
        /** Wie waitForChange, aber als Ja/Nein – für den Anleitungs-Modus. */
        fun changedWithin(timeoutSec: Int, cancelled: () -> Boolean): Boolean {
            if (instance == null) return false
            Thread.sleep(400)
            val baseline = System.currentTimeMillis()
            val until = baseline + timeoutSec * 1000L
            while (System.currentTimeMillis() < until && !cancelled()) {
                if (lastChange > baseline) {
                    Thread.sleep(900) // neue Ansicht fertig laden lassen
                    return true
                }
                Thread.sleep(200)
            }
            return false
        }

        fun waitForChange(timeoutSec: Int): JSONObject {
            instance ?: return notReady()
            val start = System.currentTimeMillis()
            val until = start + timeoutSec.coerceIn(3, 120) * 1000L
            Thread.sleep(500)
            val baseline = System.currentTimeMillis()
            while (System.currentTimeMillis() < until) {
                if (lastChange > baseline) {
                    Thread.sleep(800) // kurz warten, bis die neue Ansicht fertig geladen ist
                    return ok("Bildschirm hat sich geändert (App: $lastWindowPkg). Jetzt read_screen oder look_at_screen.")
                }
                Thread.sleep(250)
            }
            return ok("Keine Änderung nach $timeoutSec Sekunden – Nutzer hat wohl noch nicht getippt.")
        }

        fun press(button: String): JSONObject {
            val svc = instance ?: return notReady()
            val action = when (button.lowercase()) {
                "previous_app", "last_app" -> {
                    // zweimal "Zuletzt verwendet" = zurück zur vorherigen App
                    svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_RECENTS)
                    Thread.sleep(450)
                    svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_RECENTS)
                    Thread.sleep(900)
                    return ok("zurück zur vorherigen App")
                }
                "back", "zurück" -> AccessibilityService.GLOBAL_ACTION_BACK
                "home" -> AccessibilityService.GLOBAL_ACTION_HOME
                "recents", "apps" -> AccessibilityService.GLOBAL_ACTION_RECENTS
                "notifications" -> AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS
                "quick_settings" -> AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS
                "lock" -> if (Build.VERSION.SDK_INT >= 28) AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN else return err("Sperren geht erst ab Android 9")
                "screenshot" -> if (Build.VERSION.SDK_INT >= 28) AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT else return err("Screenshot geht erst ab Android 9")
                else -> return err("Unbekannter Knopf: $button")
            }
            svc.performGlobalAction(action)
            Thread.sleep(700)
            return ok("$button gedrückt")
        }
    }

    private fun tapAt(x: Float, y: Float) {
        val path = android.graphics.Path().apply { moveTo(x, y) }
        val gesture = android.accessibilityservice.GestureDescription.Builder()
            .addStroke(android.accessibilityservice.GestureDescription.StrokeDescription(path, 0, 60))
            .build()
        dispatchGesture(gesture, null, null)
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val e = event ?: return
        val pkg = e.packageName?.toString().orEmpty()
        // eigene Blase/Rahmen und die Statusleiste (Uhr usw.) ignorieren
        if (pkg == packageName || pkg == "com.android.systemui") return
        // nur echte Nutzer-Aktionen zählen: neues Fenster, Tippen, Schreiben, Scrollen
        if (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
            e.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED ||
            e.eventType == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED ||
            e.eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED
        ) {
            lastChange = System.currentTimeMillis()
            e.packageName?.let { lastWindowPkg = it.toString() }
        }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }
}
