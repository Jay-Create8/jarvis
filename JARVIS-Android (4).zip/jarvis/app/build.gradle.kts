plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "ch.jarvis.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "ch.jarvis.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 8
        versionName = "8.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    // Offline-Wake-Word "Hey Jarvis" (openWakeWord-Modelle laufen über ONNX Runtime)
    implementation("com.microsoft.onnxruntime:onnxruntime-android:1.20.0")
    // Unsichtbare Kamera im Hintergrund
    implementation("androidx.camera:camera-core:1.4.1")
    implementation("androidx.camera:camera-camera2:1.4.1")
    implementation("androidx.camera:camera-lifecycle:1.4.1")
    // Orts-Erinnerungen (Geofencing)
    implementation("com.google.android.gms:play-services-location:21.3.0")
}
