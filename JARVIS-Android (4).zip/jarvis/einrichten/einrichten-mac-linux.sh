#!/bin/sh
# JARVIS: alle Superkräfte mit einem Befehl freischalten (per USB/ADB)
# Vorher: Handy per USB, USB-Debugging an, JARVIS installiert.
P=ch.jarvis.app
command -v adb >/dev/null || { echo "adb fehlt – 'SDK Platform-Tools' von Google installieren"; exit 1; }
adb devices

echo "[1/6] Eingeschränkte Einstellungen freigeben …"
adb shell appops set $P ACCESS_RESTRICTED_SETTINGS allow 2>/dev/null

echo "[2/6] Berechtigungen …"
for X in RECORD_AUDIO CAMERA READ_CALENDAR READ_CONTACTS POST_NOTIFICATIONS \
         ACCESS_FINE_LOCATION ACCESS_COARSE_LOCATION ACCESS_BACKGROUND_LOCATION; do
  adb shell pm grant $P android.permission.$X 2>/dev/null
done

echo "[3/6] Blase über anderen Apps + pünktliche Erinnerungen …"
adb shell appops set $P SYSTEM_ALERT_WINDOW allow
adb shell appops set $P SCHEDULE_EXACT_ALARM allow 2>/dev/null
adb shell appops set $P USE_FULL_SCREEN_INTENT allow 2>/dev/null

echo "[4/6] Akku-Optimierung aus …"
adb shell dumpsys deviceidle whitelist +$P

echo "[5/6] Nachrichten lesen …"
adb shell cmd notification allow_listener $P/$P.NotificationWatcher

echo "[6/6] Apps bedienen + Bildschirm sehen …"
CUR=$(adb shell settings get secure enabled_accessibility_services | tr -d '\r')
SVC="$P/$P.ScreenAgent"
case "$CUR" in
  *"$SVC"*) NEW="$CUR" ;;
  ""|null)  NEW="$SVC" ;;
  *)        NEW="$CUR:$SVC" ;;   # andere Bedienungshilfen bleiben an
esac
adb shell settings put secure enabled_accessibility_services "$NEW"
adb shell settings put secure accessibility_enabled 1

echo "FERTIG! 🎉 Öffne JARVIS und schalte \"Hey Jarvis\" an."
