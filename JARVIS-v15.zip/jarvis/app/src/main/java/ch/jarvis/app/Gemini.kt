package ch.jarvis.app

import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * Spricht mit Google Gemini – robust:
 *  - bei Überlastung (503) automatisch kurz warten und nochmal versuchen
 *  - klappt's dann immer noch nicht (oder Gratis-Limit erreicht), auf ein anderes Modell ausweichen
 */
object Gemini {

    /** Ausweich-Modelle, falls das eingestellte gerade überlastet ist (jedes hat sein eigenes Gratis-Limit). */
    private val FALLBACKS = listOf(
        "gemini-3.5-flash", "gemini-3.6-flash", "gemini-3.5-flash-lite", "gemini-flash-latest", "gemini-flash-lite-latest",
    )

    /** Modelle, die gerade ihr Limit erreicht haben oder überlastet sind, eine Weile überspringen (spart Wartezeit). */
    private val coolDown = java.util.concurrent.ConcurrentHashMap<String, Long>()

    /** Von Google abgefragt: welche Modelle es für diesen Key WIRKLICH gibt (beste zuerst). */
    @Volatile private var discovered: List<String> = emptyList()
    @Volatile private var discoveredAt = 0L

    private fun available(model: String) = (coolDown[model] ?: 0L) < System.currentTimeMillis()

    internal class HttpFail(val code: Int, msg: String) : IOException(msg)

    /** Versionsnummer aus dem Namen, z.B. gemini-3.5-flash → 3.5 */
    private fun version(name: String) =
        Regex("gemini-(\\d+(?:\\.\\d+)?)").find(name)?.groupValues?.get(1)?.toDoubleOrNull() ?: 0.0

    /** Fragt Google nach der aktuellen Modell-Liste – so bleibt JARVIS auch bei neuen Modellen am Laufen. */
    private fun discover(store: Store): List<String> {
        if (discovered.isNotEmpty() && System.currentTimeMillis() - discoveredAt < 6 * 3600_000L) return discovered
        return runCatching {
            val con = URL("https://generativelanguage.googleapis.com/v1beta/models?pageSize=200")
                .openConnection() as HttpURLConnection
            con.connectTimeout = 15_000
            con.readTimeout = 20_000
            con.setRequestProperty("x-goog-api-key", store.apiKey)
            if (con.responseCode !in 200..299) return emptyList()
            val arr = JSONObject(con.inputStream.bufferedReader().use { it.readText() }).optJSONArray("models")
                ?: return emptyList()
            val bad = listOf("tts", "image", "embedding", "live", "audio", "aqa", "vision", "robotics", "computer", "gemma", "learnlm", "exp", "thinking")
            val names = (0 until arr.length()).map { arr.getJSONObject(it) }.filter { m ->
                val methods = m.optJSONArray("supportedGenerationMethods")?.toString().orEmpty()
                methods.contains("generateContent")
            }.map { it.getString("name").removePrefix("models/") }
                .filter { n -> n.startsWith("gemini-") && bad.none { n.contains(it) } }
            // Reihenfolge: normale Flash (schlau + schnell) → Flash-Lite → Pro; jeweils neueste zuerst, stabile vor Preview
            fun rank(n: String) = when {
                n.contains("flash") && !n.contains("lite") -> 0
                n.contains("flash-lite") -> 1
                else -> 2
            }
            names.sortedWith(compareBy<String>({ rank(it) }, { -version(it) }, { if (it.contains("preview")) 1 else 0 }, { it.length }))
                .take(8)
        }.getOrDefault(emptyList()).also {
            if (it.isNotEmpty()) { discovered = it; discoveredAt = System.currentTimeMillis() }
        }
    }

    fun generate(store: Store, body: JSONObject): JSONObject {
        var models = (listOf(store.model) + FALLBACKS + discovered).distinct().filter { available(it) }
        var first: HttpFail? = null
        var last: HttpFail? = null
        var discoveredNow = false
        var i = 0
        while (i < models.size) {
            val model = models[i]
            i++
            for (attempt in 1..2) {
                try {
                    return JSONObject(post(store, model, body))
                } catch (e: HttpFail) {
                    last = e
                    val m = e.message.orEmpty()
                    if (m.contains("API key", true) || m.contains("API_KEY", true))
                        throw IOException("API-Key ungültig 🔑 (${e.message})")
                    when (e.code) {
                        500, 502, 503, 504 -> {
                            if (first == null) first = e
                            if (attempt == 1) {
                                Thread.sleep(1500) // kurz durchatmen, dann nochmal
                            } else {
                                coolDown[model] = System.currentTimeMillis() + 2 * 60_000L
                                break // immer noch überlastet → nächstes Modell
                            }
                        }
                        429 -> {
                            if (first == null) first = e
                            coolDown[model] = System.currentTimeMillis() + 10 * 60_000L
                            break
                        }
                        else -> {
                            // 404/400: Modell gibt's nicht (mehr) für diesen Key → einen Tag überspringen
                            coolDown[model] = System.currentTimeMillis() + 24 * 3600_000L
                            break
                        }
                    }
                }
            }
            // Alle bekannten Modelle durch? → bei Google nachfragen, welche es aktuell gibt
            if (i >= models.size && !discoveredNow) {
                discoveredNow = true
                val extra = discover(store).filter { it !in models && available(it) }
                if (extra.isNotEmpty()) models = models + extra
            }
        }
        val e = first ?: last ?: throw IOException("Keine Antwort von Google")
        throw IOException(when (e.code) {
            429 -> "Gratis-Limit erreicht ⏳ Versuch's in ein paar Minuten nochmal."
            500, 502, 503, 504 -> "Google ist gerade überlastet 😵 Versuch's in ein paar Minuten nochmal."
            400, 404 -> "Kein passendes KI-Modell gefunden 😕 (${e.message})"
            else -> "HTTP ${e.code}: ${e.message}"
        })
    }

    internal fun post(store: Store, model: String, body: JSONObject): String {
        val con = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .openConnection() as HttpURLConnection
        con.requestMethod = "POST"
        con.connectTimeout = 20_000
        con.readTimeout = 180_000
        con.doOutput = true
        con.setRequestProperty("Content-Type", "application/json; charset=utf-8")
        con.setRequestProperty("x-goog-api-key", store.apiKey)
        con.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = con.responseCode
        val txt = (if (code in 200..299) con.inputStream else con.errorStream)
            ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
        if (code !in 200..299) {
            val msg = runCatching { JSONObject(txt).getJSONObject("error").getString("message") }
                .getOrDefault(txt.take(200))
            throw HttpFail(code, msg)
        }
        return txt
    }
}
