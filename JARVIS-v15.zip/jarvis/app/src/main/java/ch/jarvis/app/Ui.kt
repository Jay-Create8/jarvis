package ch.jarvis.app

import android.os.BatteryManager
import androidx.compose.foundation.Image
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.runtime.produceState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Farben im Iron-Man-HUD-Stil. */
internal object JarvisColors {
    val Cyan = Color(0xFF29E6FF)
    val Gold = Color(0xFFFFC857)
    val Red = Color(0xFFFF4D6D)
    val Green = Color(0xFF7CFFB2)
    val Bg = Color(0xFF02060D)
    val Panel = Color(0xFF0A1A2A)
}

private val Cyan = JarvisColors.Cyan
private val Bg = JarvisColors.Bg

@Composable
fun JarvisScreen(a: MainActivity) {
    var showSettings by remember { mutableStateOf(false) }
    var input by remember { mutableStateOf("") }
    var viewer by remember { mutableStateOf<String?>(null) }
    var showWorks by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    val thinking = Jarvis.phase == Phase.THINKING

    LaunchedEffect(Jarvis.messages.size, thinking) {
        val n = Jarvis.messages.size + if (thinking) 1 else 0
        if (n > 0) listState.animateScrollToItem(n - 1)
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Bg, surface = JarvisColors.Panel)) {
        Column(
            Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(Bg, Color(0xFF061423))))
                .safeDrawingPadding(),
        ) {
            ChatHeader(a, onSettings = { showSettings = true }, onWorks = { showWorks = true })

            LazyColumn(
                state = listState,
                modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(vertical = 12.dp),
            ) {
                items(Jarvis.messages) { m -> Bubble(m, Modifier.animateItem(), onFile = { a.openCreation(it) }) { viewer = it } }
                if (thinking) item { ThinkingBubble() }
            }

            // Vorschläge nur am Anfang – danach bleibt es ein ganz normaler Chat
            if (Jarvis.messages.size <= 1 && !thinking) Suggestions()

            InputBar(
                a = a,
                value = input,
                onChange = { input = it },
                onSend = { if (a.send(input)) input = "" },
            )
        }

        if (showSettings) SettingsDialog(a) { showSettings = false }
        if (showWorks) WorksDialog(a) { showWorks = false }
        if (a.showSetup) SetupDialog(a)
        viewer?.let { path -> ImageViewer(path, a) { viewer = null } }
    }
}

/** Kopfzeile wie bei WhatsApp: Bild, Name, und darunter was JARVIS gerade macht. */
@Composable
private fun ChatHeader(a: MainActivity, onSettings: () -> Unit, onWorks: () -> Unit) {
    val subtitle = when (Jarvis.phase) {
        Phase.LISTENING -> "hört zu …"
        Phase.THINKING -> Jarvis.status.ifBlank { "denkt nach …" }
        Phase.SPEAKING -> "spricht …"
        Phase.IDLE -> if (Jarvis.wakeActive) "online · sag \"Hey Jarvis\"" else "online"
    }
    Row(
        Modifier
            .fillMaxWidth()
            .background(JarvisColors.Panel)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Reactor(Jarvis.phase, Jarvis.level, size = 44.dp) { Jarvis.toggleListening() }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text("JARVIS", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text(subtitle, color = Cyan.copy(alpha = 0.85f), fontSize = 13.sp, maxLines = 1)
        }
        HeaderButton("🛠️", onWorks)
        HeaderButton("🦾") { a.showSetup = true }
        HeaderButton("⚙️", onSettings)
    }
}

@Composable
private fun HeaderButton(icon: String, onClick: () -> Unit) {
    Box(
        Modifier.padding(start = 4.dp).size(40.dp).clip(CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text(icon, fontSize = 20.sp) }
}

@Composable
private fun Bubble(m: ChatMsg, modifier: Modifier = Modifier, onFile: (String) -> Unit = {}, onImage: (String) -> Unit) {
    val shape = if (m.user) RoundedCornerShape(18.dp, 18.dp, 4.dp, 18.dp) else RoundedCornerShape(18.dp, 18.dp, 18.dp, 4.dp)
    Row(modifier.fillMaxWidth(), horizontalArrangement = if (m.user) Arrangement.End else Arrangement.Start) {
        Column(
            Modifier
                .widthIn(max = 300.dp)
                .background(if (m.user) Color(0xFF145374) else JarvisColors.Panel, shape)
                .then(if (m.user) Modifier else Modifier.border(1.dp, Cyan.copy(alpha = 0.35f), shape))
                .padding(if (m.images.isEmpty()) 0.dp else 4.dp),
        ) {
            if (m.images.isNotEmpty()) ImageGrid(m.images, onImage)
            if (m.text.isNotBlank()) {
                Text(
                    m.text, color = Color.White, fontSize = 15.sp, lineHeight = 21.sp,
                    modifier = Modifier.padding(horizontal = if (m.images.isEmpty()) 14.dp else 10.dp, vertical = 9.dp),
                )
            }
            m.file?.let { FileCard(it, onFile) }
        }
    }
}

/** Karte für etwas, das JARVIS gebaut hat – antippen = öffnen/spielen. */
@Composable
private fun FileCard(path: String, onOpen: (String) -> Unit) {
    val f = java.io.File(path)
    val exists = f.exists()
    Row(
        Modifier
            .padding(start = 8.dp, end = 8.dp, bottom = 8.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Brush.horizontalGradient(listOf(Color(0xFF0F3550), Color(0xFF13294B))))
            .clickable(enabled = exists) { onOpen(path) }
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(Creations.icon(path), fontSize = 26.sp)
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(f.nameWithoutExtension.replace('_', ' '), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1)
            Text(if (!exists) "gelöscht" else if (Creations.isApp(path)) "App · antippen zum Starten" else f.extension.uppercase() + " · antippen zum Öffnen",
                color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
        }
        if (exists) Text("Öffnen ▶", color = Cyan, fontWeight = FontWeight.Bold, fontSize = 14.sp)
    }
}

/** 🛠️ Meine Werke: alles, was JARVIS gebaut hat. */
@Composable
private fun WorksDialog(a: MainActivity, onClose: () -> Unit) {
    var version by remember { mutableIntStateOf(0) }
    val files = remember(version) { Creations.list(a) }
    AlertDialog(
        onDismissRequest = onClose,
        confirmButton = { TextButton(onClick = onClose) { Text("Schliessen") } },
        title = { Text("🛠️ Meine Werke") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                if (files.isEmpty()) {
                    Text("Noch nichts gebaut 🙂\n\nSag z.B. \"Bau mir ein Snake-Spiel\", \"Mach mir Lernkarten für Französisch\" oder \"Schreib mir eine Einkaufsliste\".",
                        color = Color.White.copy(alpha = 0.8f))
                }
                files.forEach { f ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Row(
                            Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).clickable { a.openCreation(f.absolutePath) }.padding(6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(Creations.icon(f.path), fontSize = 22.sp)
                            Spacer(Modifier.width(8.dp))
                            Text(f.nameWithoutExtension.replace('_', ' '), color = Color.White, maxLines = 1)
                        }
                        HeaderButton("📤") { runCatching { Creations.share(a, f.absolutePath) } }
                        HeaderButton("🗑️") { Creations.delete(f.absolutePath); version++ }
                    }
                }
            }
        },
    )
}

/** Bilder im Chat: eins gross, mehrere als 2er-Raster. Antippen = Vollbild. */
@Composable
private fun ImageGrid(paths: List<String>, onImage: (String) -> Unit) {
    if (paths.size == 1) {
        ChatThumb(paths[0], Modifier.width(260.dp).height(200.dp)) { onImage(paths[0]) }
        return
    }
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        paths.chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                row.forEach { p -> ChatThumb(p, Modifier.size(128.dp)) { onImage(p) } }
            }
        }
    }
}

@Composable
private fun ChatThumb(path: String, modifier: Modifier, onClick: () -> Unit) {
    val bmp by produceState<ImageBitmap?>(null, path) {
        value = withContext(Dispatchers.IO) { ChatImages.thumbnail(path, 640)?.asImageBitmap() }
    }
    Box(
        modifier.clip(RoundedCornerShape(14.dp)).background(Color(0xFF0E2233)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        val b = bmp
        if (b != null) {
            Image(bitmap = b, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        } else {
            Text("🖼️", fontSize = 22.sp)
        }
    }
}

/** Vollbild-Ansicht mit Speichern-Knopf. */
@Composable
private fun ImageViewer(path: String, a: MainActivity, onClose: () -> Unit) {
    val bmp by produceState<ImageBitmap?>(null, path) {
        value = withContext(Dispatchers.IO) { ChatImages.thumbnail(path, 2048)?.asImageBitmap() }
    }
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().background(Color.Black).clickable(onClick = onClose)) {
            val b = bmp
            if (b != null) {
                Image(bitmap = b, contentDescription = null, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize())
            }
            Row(
                Modifier.align(Alignment.BottomCenter).padding(32.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                ViewerButton("💾 Speichern") { a.saveImage(path) }
                ViewerButton("✕ Schliessen", onClose)
            }
        }
    }
}

@Composable
private fun ViewerButton(label: String, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Text(
        label, color = Color.White, fontSize = 15.sp,
        modifier = Modifier.clip(shape).background(JarvisColors.Panel)
            .border(1.dp, Cyan.copy(alpha = 0.5f), shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 10.dp),
    )
}

@Composable
private fun ThinkingBubble() {
    val inf = rememberInfiniteTransition(label = "dots")
    val t by inf.animateFloat(0f, 3f, infiniteRepeatable(tween(900, easing = LinearEasing)), label = "t")
    Row(
        Modifier
            .background(JarvisColors.Panel, RoundedCornerShape(18.dp, 18.dp, 18.dp, 4.dp))
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        for (i in 0 until 3) {
            val on = t.toInt() == i
            Box(Modifier.padding(horizontal = 3.dp).size(8.dp).clip(CircleShape)
                .background(Cyan.copy(alpha = if (on) 1f else 0.3f)))
        }
    }
}

private val suggestions = listOf(
    "📋 Plane meinen Tag" to DAYPLAN_PROMPT,
    "👁️ Was ist das?" to "Was ist gerade auf meinem Bildschirm zu sehen? Erklär's mir kurz.",
    "📬 Neue Nachrichten?" to "Was gibt's Neues bei meinen Nachrichten?",
    "🌦️ Wetter" to "Wie wird das Wetter heute?",
    "📞 Ruf mich an" to "Ruf mich jetzt an.",
)

@Composable
private fun Suggestions() {
    LazyRow(
        Modifier.fillMaxWidth().padding(bottom = 6.dp),
        contentPadding = PaddingValues(horizontal = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        items(suggestions) { (label, prompt) ->
            val shape = RoundedCornerShape(50)
            Text(
                label, fontSize = 13.sp, color = Color.White,
                modifier = Modifier.clip(shape).background(JarvisColors.Panel)
                    .border(1.dp, Cyan.copy(alpha = 0.4f), shape)
                    .clickable { Jarvis.handleInput(prompt) }
                    .padding(horizontal = 14.dp, vertical = 8.dp),
            )
        }
    }
}

/** Eingabe wie bei WhatsApp: Anhänge-Vorschau, Textfeld, Galerie, Kamera, und rechts Mikrofon (leer) oder Senden. */
@Composable
private fun InputBar(a: MainActivity, value: String, onChange: (String) -> Unit, onSend: () -> Unit) {
    val listening = Jarvis.phase == Phase.LISTENING
    val inf = rememberInfiniteTransition(label = "mic")
    val pulse by inf.animateFloat(1f, 1.15f, infiniteRepeatable(tween(600), RepeatMode.Reverse), label = "p")
    val hasImages = a.pendingImages.isNotEmpty()
    Column(Modifier.fillMaxWidth()) {
        if (hasImages) {
            LazyRow(
                Modifier.fillMaxWidth().padding(start = 12.dp, end = 12.dp, top = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(a.pendingImages.toList()) { p ->
                    Box(Modifier.size(72.dp)) {
                        ChatThumb(p, Modifier.fillMaxSize()) {}
                        Box(
                            Modifier.align(Alignment.TopEnd).padding(3.dp).size(22.dp).clip(CircleShape)
                                .background(Color.Black.copy(alpha = 0.7f)).clickable { a.removePending(p) },
                            contentAlignment = Alignment.Center,
                        ) { Text("✕", color = Color.White, fontSize = 12.sp) }
                    }
                }
            }
        }
        Row(
            Modifier.fillMaxWidth().padding(start = 8.dp, end = 8.dp, top = 4.dp, bottom = 8.dp),
            verticalAlignment = Alignment.Bottom,
        ) {
            val shape = RoundedCornerShape(24.dp)
            Row(
                Modifier
                    .weight(1f)
                    .clip(shape)
                    .background(JarvisColors.Panel)
                    .padding(start = 16.dp, end = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(Modifier.weight(1f).padding(vertical = 13.dp)) {
                    if (value.isEmpty()) {
                        Text(
                            when {
                                listening -> "Ich höre zu …"
                                hasImages -> "Frag was zu den Bildern …"
                                else -> "Nachricht"
                            },
                            color = Color.White.copy(alpha = 0.4f), fontSize = 16.sp,
                        )
                    }
                    BasicTextField(
                        value = value,
                        onValueChange = onChange,
                        textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
                        cursorBrush = SolidColor(Cyan),
                        maxLines = 5,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
                Box(Modifier.size(40.dp).clip(CircleShape).clickable { a.pickImages() }, contentAlignment = Alignment.Center) {
                    Text("🖼️", fontSize = 19.sp)
                }
                Box(Modifier.size(40.dp).clip(CircleShape).clickable { a.takePhoto() }, contentAlignment = Alignment.Center) {
                    Text("📷", fontSize = 19.sp)
                }
            }
            Spacer(Modifier.width(6.dp))
            val sendMode = value.isNotBlank() || hasImages
            val stopMode = !sendMode && Jarvis.phase == Phase.THINKING
            val btn = if (listening && !sendMode) (48 * pulse).dp else 48.dp
            Box(
                Modifier
                    .size(btn)
                    .clip(CircleShape)
                    .background(if ((listening || stopMode) && !sendMode) JarvisColors.Red else Cyan)
                    .clickable { if (sendMode) onSend() else Jarvis.toggleListening() },
                contentAlignment = Alignment.Center,
            ) {
                Text(if (sendMode) "➤" else if (stopMode) "⏹" else "🎙️", fontSize = 20.sp, color = if (stopMode) Color.White else Bg, fontWeight = FontWeight.Bold)
            }
        }
    }
}

/** Der Arc-Reactor: pulsiert, dreht sich, reagiert auf deine Stimme. */
@Composable
internal fun Reactor(phase: Phase, level: Float, size: Dp = 150.dp, onClick: () -> Unit) {
    val inf = rememberInfiniteTransition(label = "reactor")
    val thinking = phase == Phase.THINKING
    val pulse by inf.animateFloat(0.92f, 1.08f,
        infiniteRepeatable(tween(if (thinking) 400 else 1600), RepeatMode.Reverse), label = "pulse")
    val rot by inf.animateFloat(0f, 360f,
        infiniteRepeatable(tween(if (thinking) 1200 else 7000, easing = LinearEasing)), label = "rot")
    val rot2 by inf.animateFloat(360f, 0f,
        infiniteRepeatable(tween(if (thinking) 2000 else 11000, easing = LinearEasing)), label = "rot2")
    val lvl by animateFloatAsState(level, label = "lvl")
    val color = when (phase) {
        Phase.LISTENING -> JarvisColors.Red
        Phase.SPEAKING -> JarvisColors.Green
        Phase.THINKING -> JarvisColors.Gold
        else -> Cyan
    }

    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(size).clip(CircleShape).clickable(onClick = onClick)) {
            val r = this.size.minDimension / 2
            val k = r / 200f // Linien skalieren mit der Grösse
            val s = pulse + lvl * 0.3f
            drawCircle(Brush.radialGradient(listOf(color.copy(alpha = 0.5f), Color.Transparent), radius = r), radius = r)
            drawCircle(color.copy(alpha = 0.6f), radius = r * 0.96f, style = Stroke(6f * k))
            // äusserer Skalen-Ring
            rotate(rot2) {
                for (i in 0 until 48) {
                    val len = if (i % 4 == 0) 0.08f else 0.04f
                    val ang = Math.toRadians(i * 7.5).toFloat()
                    val c = Offset(this.size.width / 2, this.size.height / 2)
                    val o1 = Offset(c.x + kotlin.math.cos(ang) * r * 0.9f, c.y + kotlin.math.sin(ang) * r * 0.9f)
                    val o2 = Offset(c.x + kotlin.math.cos(ang) * r * (0.9f - len), c.y + kotlin.math.sin(ang) * r * (0.9f - len))
                    drawLine(color.copy(alpha = 0.55f), o1, o2, 5f * k)
                }
            }
            // drehende Segmente
            rotate(rot) {
                for (i in 0 until 8) {
                    drawArc(color, startAngle = i * 45f, sweepAngle = 28f, useCenter = false,
                        topLeft = Offset(this.size.width * 0.17f, this.size.height * 0.17f),
                        size = Size(this.size.width * 0.66f, this.size.height * 0.66f),
                        style = Stroke(width = 18f * k, cap = StrokeCap.Round))
                }
            }
            drawCircle(color, radius = r * 0.28f * s)
            drawCircle(Color.White.copy(alpha = 0.85f), radius = r * 0.13f * s)
        }
    }
}

@Composable
private fun SettingsDialog(a: MainActivity, onClose: () -> Unit) {
    val store = Jarvis.store
    var key by remember { mutableStateOf(store.apiKey) }
    var model by remember { mutableStateOf(store.model) }
    var name by remember { mutableStateOf(store.userName) }
    var sens by remember { mutableFloatStateOf(store.wakeSensitivity) }
    val facts = remember { store.facts() }
    val overlayOk = remember { a.hasOverlay() }
    val notifOk = remember { a.hasNotificationAccess() }
    val screenOk = remember { a.hasScreenControl() }
    val camOk = remember { a.hasCamera() }
    val locState = remember { a.locationState() }
    var briefOn by remember { mutableStateOf(store.briefingEnabled) }
    var briefHour by remember { mutableIntStateOf(store.briefingHour) }
    var briefMin by remember { mutableIntStateOf(store.briefingMinute) }
    var briefSpeak by remember { mutableStateOf(store.briefingSpeak) }
    var announce by remember { mutableStateOf(store.announceMessages) }
    var urgentCall by remember { mutableStateOf(store.callOnUrgent) }
    var proactive by remember { mutableStateOf(store.proactiveEnabled) }
    var eveHour by remember { mutableIntStateOf(store.eveningHour) }
    val batteryOk = remember { a.ignoresBatteryOptimizations() }

    AlertDialog(
        onDismissRequest = onClose,
        confirmButton = { TextButton(onClick = {
            a.saveSettings(key, model, name, sens)
            a.setBriefing(briefOn, briefHour, briefMin, briefSpeak)
            store.announceMessages = announce
            store.callOnUrgent = urgentCall
            a.setProactive(proactive, eveHour)
            onClose()
        }) { Text("Speichern") } },
        dismissButton = { TextButton(onClick = onClose) { Text("Abbrechen") } },
        title = { Text("⚙️ Einstellungen") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text("🧠 Gehirn", fontWeight = FontWeight.Bold)
                OutlinedTextField(key, { key = it }, label = { Text("Gemini API-Key") }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation())
                Text("Gratis holen: aistudio.google.com → \"Get API key\"", fontSize = 12.sp)
                Spacer(Modifier.height(6.dp))
                Text("🧠 Intelligenz", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(vertical = 4.dp)) {
                    listOf(
                        "⚡ Schnell" to "gemini-3.5-flash-lite",
                        "🧠 Schlau" to "gemini-3.5-flash",
                        "🧪 Genie" to "gemini-pro-latest",
                    ).forEach { (label, m) -> VoiceChip(label, model == m) { model = m } }
                }
                Text(
                    when (model) {
                        "gemini-pro-latest" -> "Am schlausten, aber langsamer und nur wenige Gratis-Anfragen pro Tag – danach nimmt JARVIS automatisch \"Schlau\"."
                        "gemini-3.5-flash-lite" -> "Am schnellsten, aber nicht ganz so schlau."
                        else -> "Beste Mischung aus schlau und schnell (empfohlen)."
                    },
                    fontSize = 12.sp,
                )
                OutlinedTextField(model, { model = it }, label = { Text("KI-Modell (für Profis)") }, singleLine = true)
                Spacer(Modifier.height(6.dp))
                OutlinedTextField(name, { name = it }, label = { Text("Wie soll ich dich nennen?") }, singleLine = true)

                Spacer(Modifier.height(14.dp))
                Text("🎛️ Allgemein", fontWeight = FontWeight.Bold)
                SwitchRow("👂 \"Hey Jarvis\" (hört immer zu)", Jarvis.wakeActive) { a.setWake(it) }
                SwitchRow("🔁 Gesprächsmodus (hört nach Antwort weiter zu)", Jarvis.convoMode) { Jarvis.setConvo(it) }
                SwitchRow("🔊 Mit Stimme antworten", !Jarvis.muted) { Jarvis.toggleMute() }
                SwitchRow("📞 Anrufen bei dringenden Nachrichten", urgentCall) { urgentCall = it }
                if (Jarvis.wakeInfo.isNotBlank()) Text(Jarvis.wakeInfo, fontSize = 12.sp, color = Cyan)

                Spacer(Modifier.height(14.dp))
                VoiceSettings()

                Spacer(Modifier.height(14.dp))
                Text("🧠 Mitdenken", fontWeight = FontWeight.Bold)
                SwitchRow("Von selbst nachschauen & bei Wichtigem anrufen", proactive) { proactive = it }
                if (proactive) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("🌙 Abend-Check um", fontSize = 14.sp, modifier = Modifier.weight(1f))
                        TextButton(onClick = { eveHour = (eveHour + 23) % 24 }) { Text("−") }
                        Text("%02d:00".format(eveHour), fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        TextButton(onClick = { eveHour = (eveHour + 1) % 24 }) { Text("+") }
                    }
                    Text("Tagsüber schaut er etwa alle 3 Stunden kurz nach und ruft nur an, wenn's wirklich wichtig ist.",
                        fontSize = 12.sp)
                }

                Spacer(Modifier.height(14.dp))
                Text("👂 \"Hey JARVIS\"", fontWeight = FontWeight.Bold)
                Text("Läuft komplett offline auf deinem Handy. Sag \"Hey Jarvis\" und warte kurz auf den Piep.",
                    fontSize = 12.sp)
                Text("Empfindlichkeit: ${(sens * 100).toInt()} %", fontSize = 13.sp)
                Slider(value = sens, onValueChange = { sens = it }, valueRange = 0.2f..0.8f)
                Text("Höher = reagiert leichter, aber auch öfter aus Versehen.", fontSize = 12.sp)
                TextButton(onClick = { a.openOverlaySettings() }) {
                    Text(if (overlayOk) "✅ Blase über anderen Apps erlaubt" else "⚠️ Blase über anderen Apps erlauben")
                }
                TextButton(onClick = { a.openBatterySettings() }) {
                    Text(if (batteryOk) "✅ Akku-Optimierung aus" else "⚠️ Akku-Optimierung ausschalten")
                }

                Spacer(Modifier.height(14.dp))
                Text("☀️ Morgen-Briefing", fontWeight = FontWeight.Bold)
                SwitchRow("Jeden Tag automatisch", briefOn) { briefOn = it }
                if (briefOn) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        TextButton(onClick = { briefHour = (briefHour + 23) % 24 }) { Text("−") }
                        Text("%02d:%02d".format(briefHour, briefMin), fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        TextButton(onClick = { briefHour = (briefHour + 1) % 24 }) { Text("+") }
                        TextButton(onClick = { briefMin = (briefMin + 15) % 60 }) { Text("+15 Min") }
                    }
                    SwitchRow("Laut vorlesen", briefSpeak) { briefSpeak = it }
                }

                Spacer(Modifier.height(14.dp))
                Text("🦾 Superkräfte", fontWeight = FontWeight.Bold)
                Button(onClick = { onClose(); a.showSetup = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("🦾 Alles auf einmal einrichten")
                }
                Text("Oder einzeln:", fontSize = 12.sp)
                Text("Jede einzeln erlauben. Ist ein Schalter ausgegraut: zuerst unten \"App-Info\" → ⋮ → " +
                    "\"Eingeschränkte Einstellungen zulassen\".", fontSize = 12.sp)
                TextButton(onClick = { a.openNotificationAccess() }) {
                    Text(if (notifOk) "✅ Nachrichten lesen & beantworten" else "⚠️ Nachrichten lesen & beantworten")
                }
                SwitchRow("📢 Neue Nachrichten laut ansagen", announce) { announce = it }
                TextButton(onClick = { a.openAccessibility() }) {
                    Text(if (screenOk) "✅ Apps bedienen (Bedienungshilfe)" else "⚠️ Apps bedienen → \"JARVIS\" einschalten")
                }
                Text("👁️ \"Was ist das?\" (Bildschirm sehen) nutzt die Bedienungshilfe, Android 11+.", fontSize = 12.sp)
                TextButton(onClick = { a.requestCamera() }) {
                    Text(if (camOk) "✅ Kamera (auch im Hintergrund bei \"Hey Jarvis\" an)" else "⚠️ Kamera erlauben")
                }
                TextButton(onClick = { a.requestLocation() }) {
                    Text(when (locState) {
                        2 -> "✅ Standort (Wetter & Orts-Erinnerungen)"
                        1 -> "⚠️ Standort \"Immer erlauben\" für Orts-Erinnerungen"
                        else -> "⚠️ Standort erlauben"
                    })
                }
                TextButton(onClick = { a.openAppInfo() }) { Text("ℹ️ App-Info öffnen") }

                Spacer(Modifier.height(10.dp))
                Text("🧠 Gedächtnis (${facts.size})", fontWeight = FontWeight.Bold)
                if (facts.isEmpty()) Text("Noch nichts gemerkt.", fontSize = 12.sp)
                facts.forEach { Text("• $it", fontSize = 12.sp) }
                Row {
                    TextButton(onClick = { Jarvis.clearMemory(); onClose() }) { Text("Gedächtnis löschen") }
                    TextButton(onClick = { Jarvis.newChat(); onClose() }) { Text("Neuer Chat") }
                }
            }
        },
    )
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, fontSize = 14.sp, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

/** Ein-Knopf-Einrichtung: Checkliste aller Superkräfte, führt automatisch durch alles. */
@Composable
private fun SetupDialog(a: MainActivity) {
    @Suppress("UNUSED_VARIABLE") val tick = a.setupTick // neu zeichnen, wenn du aus den Einstellungen zurückkommst
    val items = a.setupItems()
    val done = items.count { it.done }
    AlertDialog(
        onDismissRequest = { a.closeSetup() },
        title = { Text("🦾 Alles einrichten") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text(
                    if (done == items.size) "Alles bereit! 🎉" else
                        "Ein Knopf – ich führe dich automatisch durch alles. Du tippst nur jeweils \"Erlauben\" " +
                            "und gehst zurück, den Rest mache ich.",
                    fontSize = 13.sp,
                )
                Spacer(Modifier.height(8.dp))
                Text("$done von ${items.size} erledigt", fontWeight = FontWeight.Bold, color = Cyan)
                Spacer(Modifier.height(4.dp))
                items.forEach { item ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable(enabled = !item.done) { a.runSetupStep(item.id) }
                            .padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(if (item.done) "✅" else "⬜", fontSize = 18.sp)
                        Spacer(Modifier.width(8.dp))
                        Text(item.label, fontSize = 14.sp,
                            color = if (item.done) Color.White.copy(alpha = 0.6f) else Color.White)
                    }
                }
                if (a.setupHint.isNotBlank()) {
                    Spacer(Modifier.height(8.dp))
                    Text(a.setupHint, fontSize = 13.sp, color = Cyan)
                }
                TextButton(onClick = { a.openAppInfo() }) { Text("ℹ️ App-Info (bei ausgegrauten Schaltern)") }
            }
        },
        confirmButton = {
            if (done < items.size) {
                Button(onClick = { a.startSetup() }, enabled = !a.setupRunning) {
                    Text(if (a.setupRunning) "Läuft … ⏳" else "🚀 Alles einrichten")
                }
            }
        },
        dismissButton = { TextButton(onClick = { a.closeSetup() }) { Text(if (done == items.size) "Fertig" else "Später") } },
    )
}

/** 🗣️ Stimmen-Auswahl: KI-Studio-Stimme oder Handy-Stimme, Tempo, Tonhöhe, Probehören. */
@Composable
private fun VoiceSettings() {
    val store = Jarvis.store
    var mode by remember { mutableStateOf(store.voiceMode) }
    var aiVoice by remember { mutableStateOf(store.aiVoice) }
    var phoneVoice by remember { mutableStateOf(store.phoneVoice) }
    var rate by remember { mutableFloatStateOf(store.speechRate) }
    var pitch by remember { mutableFloatStateOf(store.speechPitch) }
    val phoneVoices = remember { Jarvis.phoneVoices() }

    Text("🗣️ Stimme", fontWeight = FontWeight.Bold)
    SwitchRow("✨ KI-Studio-Stimme (klingt am echtesten)", mode == "ai") {
        mode = if (it) "ai" else "phone"; store.voiceMode = mode
    }
    if (mode == "ai") {
        Text("Falls die KI-Stimme mal nicht geht, spricht automatisch die Handy-Stimme.", fontSize = 12.sp)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(vertical = 6.dp)) {
            items(GeminiTts.VOICES) { (name, desc) ->
                VoiceChip("$name · $desc", aiVoice == name) { aiVoice = name; store.aiVoice = name; Jarvis.previewVoice() }
            }
        }
    } else {
        if (phoneVoices.isEmpty()) {
            Text("Keine deutschen Handy-Stimmen gefunden – in den Android-Einstellungen unter \"Sprachausgabe\" " +
                "kannst du weitere herunterladen.", fontSize = 12.sp)
        } else {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(vertical = 6.dp)) {
                items(phoneVoices) { (name, label) ->
                    VoiceChip(label, phoneVoice == name) { phoneVoice = name; store.phoneVoice = name; Jarvis.previewVoice() }
                }
            }
        }
        Text("Tempo: ${"%.1f".format(rate)}x", fontSize = 13.sp)
        Slider(value = rate, onValueChange = { rate = it }, valueRange = 0.6f..1.6f,
            onValueChangeFinished = { store.speechRate = rate; Jarvis.previewVoice() })
        Text("Tonhöhe: ${"%.1f".format(pitch)} (tiefer = mehr JARVIS)", fontSize = 13.sp)
        Slider(value = pitch, onValueChange = { pitch = it }, valueRange = 0.6f..1.4f,
            onValueChangeFinished = { store.speechPitch = pitch; Jarvis.previewVoice() })
    }
    TextButton(onClick = { Jarvis.previewVoice() }) { Text("🔊 Probehören") }
}

@Composable
private fun VoiceChip(label: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Text(
        label, fontSize = 12.sp,
        color = if (selected) Bg else Color.White,
        modifier = Modifier.clip(shape)
            .background(if (selected) Cyan else JarvisColors.Panel)
            .border(1.dp, Cyan.copy(alpha = 0.4f), shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 7.dp),
    )
}
