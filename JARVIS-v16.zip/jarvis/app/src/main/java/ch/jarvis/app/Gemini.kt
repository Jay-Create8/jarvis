package ch.jarvis.app

import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * Spricht mit Google Gemini – robust:
 *  - bei Überlastung (503) automatisch kurz warten und nochmal versuchen
 *  - klappt's dann immer noch nicht (oder Gratis-Limit erreicht), auf ein anderes Modell ausweichen
 */
object Gemini {

    /** Ausweich-Modelle, falls das eingestellte gerade überlastet ist (jedes hat sein eigenes Gratis-Limit). */
    private val FALLBACKS = listOf(
        "gemini-3.5-flash", "gemini-3.6-flash", "gemini-3.5-flash-lite", "gemini-flash-latest", "gemini-flash-lite-latest",
    )

    /** Modelle, die gerade ihr Limit erreicht haben oder überlastet sind, eine Weile überspringen (spart Wartezeit). */
    private val coolDown = java.util.concurrent.ConcurrentHashMap<String, Long>()

    /** Von Google abgefragt: welche Modelle es für diesen Key WIRKLICH gibt (beste zuerst). */
    @Volatile private var discovered: List<String> = emptyList()
    @Volatile private var discoveredAt = 0L

    private fun available(model: String) = (coolDown[model] ?: 0L) < System.currentTimeMillis()

    internal class HttpFail(val code: Int, msg: String) : IOException(msg)

    /** Versionsnummer aus dem Namen, z.B. gemini-3.5-flash → 3.5 */
    private fun version(name: String) =
        Regex("gemini-(\\d+(?:\\.\\d+)?)").find(name)?.groupValues?.get(1)?.toDoubleOrNull() ?: 0.0

    /** Fragt Google nach der aktuellen Modell-Liste – so bleibt JARVIS auch bei neuen Modellen am Laufen. */
    private fun discover(store: Store): List<String> {
        if (discovered.isNotEmpty() && System.currentTimeMillis() - discoveredAt < 6 * 3600_000L) return discovered
        return runCatching {
            val con = URL("https://generativelanguage.googleapis.com/v1beta/models?pageSize=200")
                .openConnection() as HttpURLConnection
            con.connectTimeout = 15_000
            con.readTimeout = 20_000
            con.setRequestProperty("x-goog-api-key", store.apiKey)
            if (con.responseCode !in 200..299) return emptyList()
            val arr = JSONObject(con.inputStream.bufferedReader().use { it.readText() }).optJSONArray("models")
                ?: return emptyList()
            val bad = listOf("tts", "image", "embedding", "live", "audio", "aqa", "vision", "robotics", "computer", "gemma", "learnlm", "exp", "thinking")
            val names = (0 until arr.length()).map { arr.getJSONObject(it) }.filter { m ->
                val methods = m.optJSONArray("supportedGenerationMethods")?.toString().orEmpty()
                methods.contains("generateContent")
            }.map { it.getString("name").removePrefix("models/") }
                .filter { n -> n.startsWith("gemini-") && bad.none { n.contains(it) } }
            // Reihenfolge: normale Flash (schlau + schnell) → Flash-Lite → Pro; jeweils neueste zuerst, stabile vor Preview
            fun rank(n: String) = when {
                n.contains("flash") && !n.contains("lite") -> 0
                n.contains("flash-lite") -> 1
                else -> 2
            }
            names.sortedWith(compareBy<String>({ rank(it) }, { -version(it) }, { if (it.contains("preview")) 1 else 0 }, { it.length }))
                .take(8)
        }.getOrDefault(emptyList()).also {
            if (it.isNotEmpty()) { discovered = it; discoveredAt = System.currentTimeMillis() }
        }
    }

    /** Heisst die Fehlermeldung "dieses Modell gibt's (für dich) nicht"? */
    private fun modelGone(e: HttpFail): Boolean {
        val m = e.message.orEmpty().lowercase()
        return e.code == 404 || m.contains("no longer available") || m.contains("not found") ||
            m.contains("is not supported") || m.contains("not available") || m.contains("deprecated")
    }

    /** Gemini 3 will bei alten Werkzeug-Aufrufen eine "Gedanken-Signatur" – fehlt sie, setzen wir den offiziellen Platzhalter. */
    private fun patchSignatures(body: JSONObject) {
        val contents = body.optJSONArray("contents") ?: return
        for (i in 0 until contents.length()) {
            val c = contents.optJSONObject(i) ?: continue
            if (c.optString("role") != "model") continue
            val parts = c.optJSONArray("parts") ?: continue
            var first = true
            for (j in 0 until parts.length()) {
                val p = parts.optJSONObject(j) ?: continue
                if (p.has("functionCall")) {
                    if (first && !p.has("thoughtSignature")) p.put("thoughtSignature", "skip_thought_signature_validator")
                    first = false
                }
            }
        }
    }

    fun generate(store: Store, body: JSONObject): JSONObject {
        patchSignatures(body)
        val all = (listOf(store.model) + FALLBACKS + discovered).distinct()
        var models = all.filter { available(it) }
        if (models.isEmpty()) { coolDown.clear(); models = all }
        var important: HttpFail? = null // Fehler, der dem Nutzer wirklich was sagt
        var last: HttpFail? = null
        var lastModel = ""
        var discoveredNow = false
        var i = 0
        while (true) {
            if (i >= models.size) {
                // Alle bekannten Modelle durch? → bei Google nachfragen, welche es für diesen Key aktuell gibt
                if (discoveredNow) break
                discoveredNow = true
                val extra = discover(store).filter { it !in models && available(it) }
                if (extra.isEmpty()) break
                models = models + extra
            }
            val model = models[i]
            i++
            for (attempt in 1..2) {
                try {
                    return JSONObject(post(store, model, body))
                } catch (e: HttpFail) {
                    last = e
                    lastModel = model
                    val m = e.message.orEmpty()
                    if (m.contains("API key", true) || m.contains("API_KEY", true))
                        throw IOException("API-Key ungültig 🔑 ($m)")
                    when (e.code) {
                        500, 502, 503, 504 -> {
                            if (important == null) important = e
                            if (attempt == 1) {
                                Thread.sleep(1500) // kurz durchatmen, dann nochmal
                            } else {
                                coolDown[model] = System.currentTimeMillis() + 2 * 60_000L
                                break // immer noch überlastet → nächstes Modell
                            }
                        }
                        429 -> {
                            if (important == null) important = e
                            coolDown[model] = System.currentTimeMillis() + 10 * 60_000L
                            break
                        }
                        else -> {
                            if (modelGone(e)) {
                                // Modell gibt's für diesen Key nicht (mehr) → eine Weile überspringen
                                coolDown[model] = System.currentTimeMillis() + 6 * 3600_000L
                            } else if (important == null || important.code >= 500 || important.code == 429) {
                                important = e // echter Anfrage-Fehler – der ist am aussagekräftigsten
                                lastModel = model
                            }
                            break
                        }
                    }
                }
            }
        }
        val e = important ?: last ?: throw IOException("Keine Antwort von Google (kein Modell erreichbar – Internet ok?)")
        throw IOException(when {
            e.code == 429 -> "Gratis-Limit erreicht ⏳ Versuch's in ein paar Minuten nochmal."
            e.code >= 500 -> "Google ist gerade überlastet 😵 Versuch's in ein paar Minuten nochmal."
            else -> "Google meldet Fehler ${e.code} bei $lastModel: ${e.message}"
        })
    }

    internal fun post(store: Store, model: String, body: JSONObject): String {
        val con = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .openConnection() as HttpURLConnection
        con.requestMethod = "POST"
        con.connectTimeout = 20_000
        con.readTimeout = 180_000
        con.doOutput = true
        con.setRequestProperty("Content-Type", "application/json; charset=utf-8")
        con.setRequestProperty("x-goog-api-key", store.apiKey)
        con.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = con.responseCode
        val txt = (if (code in 200..299) con.inputStream else con.errorStream)
            ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
        if (code !in 200..299) {
            val msg = runCatching { JSONObject(txt).getJSONObject("error").getString("message") }
                .getOrDefault(txt.take(200))
            throw HttpFail(code, msg)
        }
        return txt
    }
}
